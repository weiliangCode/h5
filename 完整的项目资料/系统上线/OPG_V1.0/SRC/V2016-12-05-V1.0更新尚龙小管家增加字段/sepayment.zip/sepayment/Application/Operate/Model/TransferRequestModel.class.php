<?php
namespace Operate\Model;
/**
 * Class TransferRequestModel 对应数据表 transfer_request
 * @package Operate\Model
 * @author  tengyuan
 */
class TransferRequestModel extends OperateModel {
    public function searchData( array $key = array(), array $where = array(), $order = '',$limit=''){
        $re = $this
            ->field($key)
            ->join('merchant ON merchant.merchant_id=transfer_request.merchant_id')
            ->where($where)
            ->limit($limit)
            ->order($order)
            ->select();
//                echo $this->getlastsql();
//                var_dump($re);exit;
        return $re;
    }
    public function getCount(array $where = array()){
        $re = $this
            ->field('count(*) as a')
            ->join('merchant ON merchant.merchant_id=transfer_request.merchant_id')
            ->where($where)
            ->select();
        //        echo $this->getlastsql();
        //        var_dump($re);exit;
        if($re)
            return $re[0]['a'];
        return 0;
    }
    // 由转账号,获取出账的账号信息(支付渠道配置信息)
    public function getPaymentInfoWithTransferNo($transfer_no){
        $re = $this
            ->where([
                'transfer_request.transfer_no'=>$transfer_no
            ])
            ->join('payment_parameter_define ON transfer_request.payment_type_id=payment_parameter_define.payment_type_id AND transfer_request.scenary_id=payment_parameter_define.scenary_id ')
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id=transfer_request.auth_app_id','LEFT')

            ->field([
                'payment_parameter_define.*',
                'merchant_payment_config.para_value'
            ])
            ->select();
        //        echo $this->getLastSql();
        //        var_dump($re);exit;
        $arr = [];
//        $vrr = [];
        if(!is_null($re)){
            foreach($re as $k =>$v){
                $arr[$v['para_name']] = $v['para_value'];
            }
//            switch($re[0]['payment_type_id']){
//                case '1':
//                    $vrr['pay_account'] = $arr['alipay_seller'];
//                    $vrr['pay_name'] = $arr['alipay_seller'];
//                    break;
//                case '2':
//                    $vrr['pay_account'] = $arr['merid'];
//                    $vrr['pay_name'] = $arr['merid'];
//                    break;
//                case '3':
//                    $vrr['pay_account'] = $arr['mchid'];
//                    $vrr['pay_name'] = $arr['name'];
//                    break;
//                case '4':
//                    $vrr['pay_account'] = $arr['mchid'];
//                    $vrr['pay_name'] = $arr['merid'];
//                    break;
//            }
        }
        return $arr;
    }

    // 获取支付渠道配置信息
    public function getList($payment_type_id, $scenary_id, $merchant_app_id){
        $res = $this
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id="'.$merchant_app_id.'"','LEFT')
            ->where([
                'payment_parameter_define.payment_type_id' => $payment_type_id,
                'payment_parameter_define.scenary_id' => $scenary_id
            ])
            ->field(['payment_parameter_define.*','merchant_payment_config.para_value'])
            ->select();
        $arr = [];
        foreach($res as $k=>$v){
            $arr[$v['para_name']] = $v['para_value'];
        }
        return $arr;
    }
}