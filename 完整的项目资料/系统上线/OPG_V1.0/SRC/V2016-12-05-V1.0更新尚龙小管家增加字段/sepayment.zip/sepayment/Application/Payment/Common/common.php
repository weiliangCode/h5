<?php
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */

/**
 * 载入payment类库
 * 注意: 载入类可以跟路径,不要跟类文件后缀.php
 *
 * @params string 类路径
 * @params boolean 是否仅仅加载
 */
function load_pm_lib($cls_path, $just_require = false, $params = ''){
    static $_libs;

    if(isset($_libs[ $cls_path ])){
        return $_libs[ $cls_path ];
    }

    if(empty($cls_path)){
        return false;
    }

    $cls_paths = explode('/', $cls_path);
    $cls_name = $cls_paths[ count($cls_paths) - 1 ];

    $app_prefix_path = APP_PATH.MODULE_NAME;

    $lib_cls_path = '';
    if(strpos($cls_path, $app_prefix_path) !== false){
        $lib_cls_path = $cls_path.'.php';
    }
    else{
        $lib_cls_path = APP_PATH.MODULE_NAME.'/Lib/'.$cls_path.'.php';
    }

    require_once($lib_cls_path);

    if($just_require){
        return;
    }

    if(isset($params)){
        $cls = new $cls_name($params);
    }
    else{
        $cls = new $cls_name();
    }
    $_libs[ $cls_path ] = $cls;
    return $_libs[ $cls_path ];
}

/**
 * 得到模块URL
 *
 * @params boolean is_site 是否站点地址
 *
 * @return 得到url的地址
 */
function get_module_url(){
    $server = think_server();
    switch( $server ){
        case 'DEV':
            $host = 'http://opgdev.weilian.cn/payment';
            break;
        case 'TEST':
            $host = 'http://opgtest.weilian.cn/payment';
            break;
        case 'PROD':
            $host = 'http://pay.weilian.cn/payment';
            break;
        default:
            $host = 'http://opgdev.weilian.cn/payment';
            break;
    }
    return $host;
    //    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    //    $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    //
    //    $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    //    $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
    //
    //    //sepayment/index.php/payment
    //    $module_name = strtolower(MODULE_NAME);
    //    $i = strpos($relate_url, '/'.$module_name.'/');
    //    $module_url = $relate_url;
    //
    //    if($i!==FALSE)
    //    {
    //    	$module_url = substr($relate_url, 0, $i) . '/' . $module_name;
    //    }
    //    return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$module_url;
}

/**
 * 得到当前环境
 * 默认为开发环境

 */
function get_cur_env(){

    if(isset($_SERVER['OPG_ENV'])){
        return $_SERVER['OPG_ENV'];
    }
    else{
        return 'DEV';
    }
}

/**
 * 得到当前环境配置
 */
function get_cur_env_conf(){
    return C('ENV.'.get_cur_env());
}

/**
 *  判断应用访问场景
 *  pc，wap,ios,android
 */
function checkScene(){
    $mobile = new \Think\Mobile();
    //移动设备
    if($mobile->isMobile()){
        //		$scene = 'Wap';

        if($mobile->isTablet()){
            //平板设备 Tablet
            $scene = 'Tablet ';
        }
        if($mobile->isiOS()){
            //ios
            $scene = 'Ios';
        }
        if($mobile->isAndroidOS()){
            //Android
            $scene = 'Android';
        }
        if($mobile->isWindowsPhoneOS()){
            //WindowsPhone
            $scene = 'WindowsPhone';
        }
    }
    else{
        $scene = 'PC';
    }
    return $scene;
}

/**
 * 检查是否是手机访问
 */
function is_mobile(){
    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
    if(isset ($_SERVER['HTTP_X_WAP_PROFILE'])){
        return true;
    }
    // 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
    if(isset ($_SERVER['HTTP_VIA'])){
        // 找不到为flase,否则为true
        return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
    }
    // 判断手机发送的客户端标志,兼容性有待提高
    $browser = isset($_SERVER['HTTP_USER_AGENT']) ? trim($_SERVER['HTTP_USER_AGENT']) : '';
    if(empty($browser))
        return true;

    $clientkeywords = array('nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-', 'philips', 'panasonic', 'alcatel', 'lenovo', 'iphone', 'ipod', 'blackberry', 'meizu', 'android', 'netfront', 'symbian', 'ucweb', 'windowsce', 'palm', 'operamini', 'operamobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 'mobile');
    // 从HTTP_USER_AGENT中查找手机浏览器的关键字
    if(preg_match("/(".implode('|', $clientkeywords).")/i", strtolower($_SERVER['HTTP_USER_AGENT']))){
        return true;
    }

    // 协议法，因为有可能不准确，放到最后判断
    if(isset ($_SERVER['HTTP_ACCEPT'])){
        // 如果只支持wml并且不支持html那一定是移动设备
        // 如果支持wml和html但是wml在html之前则是移动设备
        if((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))){
            return true;
        }
    }
    return false;
}

/**
 * curl请求提交模式
 *
 * @params string 提交地址
 * @params array 需要提交的参数
 *
 * @parmas string 提交方式 post/get
 *         提交到客户端都需要用 sign 签名字段
 */
function curl($url, $params = array(), $type = 'POST', $proxy = false){
    $is_ssl = false;
    $port = false;
    if(preg_match('/^(http|https):\/\/([\w\.]+)(:(\d+))?\//', $url, $m)){
        $is_ssl = true;
        //$port = (isset($m[4]) && !empty($m[4])) ? $m[4] :  FALSE;
        //$proxy = ($port!=FALSE) ? $m[2].$m[3] : $m[2];
    }
    else{
        die('curl error['.$type.']: invalid url => '.$url);
    }
    //print_r($m);
    //print_r($proxy);
    //exit;
    $ch = curl_init();

    if($port){
        curl_setopt($ch, CURLOPT_PORT, $port);
    }

    //指定以非2进制(multipart/form-data)头部格式传送
    $this_header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);

    if(isset($_SERVER['HTTP_USER_AGENT'])){
        //Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0
        //curl_setopt($c, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727;http://www.9qc.com)');
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    }
    $opts = array(CURLOPT_TIMEOUT => 60, CURLOPT_RETURNTRANSFER => 1, //CURLOPT_SSL_VERIFYPEER => false,
        //CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $this_header, CURLOPT_ENCODING => 'gzip,deflate',);

    /*	if($proxy){
            $opts[CURLOPT_PROXY] = '10.0.0.122:80';
        }*/

    if($is_ssl){
        $opts[ CURLOPT_SSL_VERIFYHOST ] = true;
        $opts[ CURLOPT_SSL_VERIFYPEER ] = false;
    }

    //--设置post类型参数
    switch( $type ){
        case 'POST' :
            //curl_setopt($ch, CURLOPT_URL,$opts[CURLOPT_URL]);
            //curl_setopt($ch, CURLOPT_POST,1);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

            $opts[ CURLOPT_URL ] = $url;
            $opts[ CURLOPT_POST ] = 1;
            $opts[ CURLOPT_POSTFIELDS ] = http_build_query($params); // 貌似这类参数会报错: 'a=1&b=1';
            break;

        case 'GET':
            $get_params_str = '';
            if($params){
                $get_params_str = '&';
                if(strpos($url, '?') === false){
                    $get_params_str = '?';
                }
                $get_params_str = $get_params_str.http_build_query($params);
            }

            //--设置URL和返回类型
            $opts[ CURLOPT_URL ] = $url.$get_params_str;
            break;

    }
    //curl请求
    curl_setopt_array($ch, $opts);
    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    curl_setopt($ch, CURLOPT_URL, $opts[ CURLOPT_URL ]);
    //curl_setopt($ch, CURLOPT_URL,'http://localhost/');
    $output = curl_exec($ch);
    $error = curl_error($ch);
    if($error){
        die('curl error['.$type.']: '.$error.' | '.$opts[ CURLOPT_URL ]);
    }
    curl_close($ch);

    return $output;

}

/**
 * curl请求提交模式
 *
 * @params string 提交地址
 * @params array 需要提交的参数
 *
 * @parmas string 提交方式 post/get
 *         提交到客户端都需要用 sign 签名字段
 */
function curl_icbank($url, $data, $this_header = array()){
    /*	$strlen = strlen($data);
        $this_header = array(
            "Content-type: INFOSEC_SIGN/1.0
             Content-Length: $strlen");*/

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_HTTPHEADER, $this_header);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_URL, $url);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    $response = curl_exec($curl);
    $error = curl_error($curl);
    if($error){
        die($error);
    }
    curl_close($curl);

    return $response;
}




 