<?php

namespace Payment\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;

/**
 * 支付控制器
 * 
 * 这是支付的入口
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
 */
class ProcessPayController extends PaymentController {

    /**
     * 支付号, 商户第二次回调请求会带支付号过来。
     * 
     * @type string
     */
    protected $pay_no = '';

    /**
     * 支付请求id
     */
    protected $pay_request_id = '';

    /**
     * 支付的入口方法
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * 支付的入口
     * 
     * a. 商户站点请求的入口
     * b. 得到支付号再次请求
     * c. 商户响应一个支付页面
     */
    public function index() {
        //1. 检查参数合法性, 第一次支付请求未入库, 第二次才入库
        $this->check_params();
        //2.更新流水状态
        $this->update_status('PayRequest', $this->pay_no, 21, 22, array('payment_type_id' => $this->param['payment_type_id'])); //支付类型验证成功, 支付类型验证失败

        if ($this->has_err()) {
            $this->errlog('Invalid params for process pay controller');
        }
        //3. 请求支付网关
        $this->request_third_pay();
        exit;
    }

    /**
     * FLOW 校验处理支付类型的参数
     * 
     * @return bool
     */
    protected function check_params() {
        if ($this->param) {
            $this->pay_no = $this->param['pay_no'];
            $this->pay_request_data = $this->get_pay_info($this->pay_no);

            //验证第一次请求(检查没有包含支付号的请求,以及支付方式)
            if (!$this->pay_no || !$this->param['payment_type_id']) {
                $this->set_status('EMPTY_PARAMS', 'this is invalid pay_no or payment_type_id for process pay');
                return FALSE;
            }
            //定义配置
            $pconf = C('pay')['merchat_to_se_pay'];

            $this->param['se_payment_code'] = $this->pay_request_data['se_payment_code'];   //获取商户编码
            $this->param['app_code'] = $this->get_app_id(intval($this->pay_request_data['auth_app_id']), $this->pay_request_data['merchant_id']);  //获取应用编码
            //校验数据格式是否合法
            $r = $this->verify_all_params($this->param, $pconf);

            if ($r === FALSE) {
                return false;
            }
            $this->return_url = $this->pay_request_data['return_url'];

            //获取商户信息
            $this->pay_merchant_data = $this->get_merchant_info($this->param['se_payment_code']);

            //校验商户信息
            if (!$this->pay_merchant_data['se_private_key'] || !$this->param['se_payment_code']) {
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $this->param['se_payment_code']);
                return FALSE;
            }
            //校验支付方式是否合法
            $this->pay_type_data = D('PaymentType')->get_data_by_id($this->param['payment_type_id']);

            if (!$this->pay_type_data) {
                $this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $this->pay_type_data);
                return FALSE;
            }
            //签名验证
            $se_sign = $this->build_sign($this->param, $pconf, $this->pay_merchant_data['se_private_key']);
            if (!$se_sign || $this->param['se_sign'] != $se_sign) {
                $this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $this->param['se_sign']);
                return FALSE;
            }
            return true;
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 -----------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//

    /**
     * 请求第三方支付
     * 
     * @return void
     */
    protected function request_third_pay() {
        if ($this->param) {
            //验证商户信息  //$merchantInfo = $this->get_merchant_info($this->param['se_payment_code']);
            if ($this->pay_merchant_data) {
                //获取场景
                /* 				$scene = checkScene();
                  //如果非sdk且PC，就是WAP
                  if(!$is_sdk && $scene != 'PC')
                  {
                  $scene = 'WAP';
                  } */
                $merchant_app_id = $this->get_app_id($this->param['app_code'], $this->pay_merchant_data['merchant_id']);

                //获取对应支付场景的支付渠道配置信息
                /*                if(isset($this->param['scenary_id']) && !empty($this->param['scenary_id']))
                  $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($this->param['scenary_id'],$merchant_app_id,$this->param['payment_type_id']);
                  else
                  $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info($scene,$merchant_app_id,$this->param['payment_type_id']); */
                $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($this->pay_request_data['scenary_id'], $merchant_app_id, $this->param['payment_type_id']);

                if ($merchant_payment_info) {
                    //处理场景 $scene === 'PC'?'web':'wap';
                    $scene = $this->get_scene_type($this->pay_request_data['scenary_id']);

                    //组装交易参数
                    $payData = array();
                    $payData['payment_type'] = $this->pay_type_data;  //支付渠道类型信息
                    $payData['client_type'] = $scene;                   //支付场景
                    $payData['pay_merchant_data'] = $this->pay_merchant_data;      //商户信息
                    $payData['pay_request_data'] = $this->pay_request_data; //支付流水
                    //$payData['merchant_data_ctype_path'] = $this->pay_type_data;
                    $payData['merchant_payment_info'] = $merchant_payment_info;  //商户支付配置信息

                    $att = [
                        'pay_account' => isset($merchant_payment_info['account']) ? $merchant_payment_info['account'] : '商户暂未配置该支付渠道下的account,' . $this->pay_request_data['scenary_id']
                    ];
                    //加载指定第三方支付类
                    $pay = load_pm_lib("payment/{$this->pay_type_data['code']}/{$scene}/{$this->pay_type_data['code']}", FALSE, $payData);

                    $this->update_status('PayRequest', $this->pay_no, 30, 32, $att);
                    //调用第三方支付
                    $pay->pay();

                    /*
                      return array(
                      //SE支付网关交易号
                      'pay_no' => 'xxx',
                      //第三方交易号
                      'third_trade_no' => 'xxx',
                      //SE支付网关的状态
                      'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
                      //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
                      'status_msg' => '签名错误'
                      );
                     */

                    /**
                     *  以下代码根据实际支付渠道调整。
                     */
                    /* $this->result=$pay->pay();
                      $this->check_third_return_val($this->result);

                      //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
                      //返回data值
                      $pay_no = $this->result['pay_no'];
                      $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
                      $this->update_status('PayRequest', $pay_no, 31, 32, $update_data);	//得到成功的支付结果, 得到失败的支付结果

                      //4. 如果有错误,则返回到错误页面
                      if($this->has_err())
                      {
                      $pay_data = D('Merchant')->get_merchant_pay_data_by_pay_no($pay_no);
                      //在SE支付平台显示错误信息
                      if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
                      {
                      $this->errlog();
                      }
                      //把错误信息返回到第三方平台
                      else
                      {
                      $this->pay_data = $pay_data;
                      $return_result = $this->get_return_result();
                      header('Location:'.$pay_data['return_url'].'?'.http_build_query($return_result));
                      }
                      }

                      //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
                      $result = $pay->notify_result();
                      $this->check_third_return_val($result);
                      $this->update_status('PayRequest', $pay_no, 51, 52);

                      //6. 回调商户的同步回调return_url
                      //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
                      $pay_data = D('Merchant')->get_merchant_pay_data_by_pay_no($pay_no);

                      if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
                      {
                      $this->assign('pay_data', $pay_data);
                      if(is_mobile()){
                      $this->display('wap_success');
                      }else{
                      $this->display('web_success');
                      }
                      exit;
                      } */
                } else {
                    echo 'no configuration files for this payment scene';
                    $this->errlog('no configuration files for this payment scene');
                    return FALSE;
                }
            }
        }
    }

    /**
     * @param $payment_type_id
     * @return mixed
     * 根据支付类型ID获取支付类型详细信息
     */
    protected function get_payment_type($payment_type_id) {
        if ($payment_type_id) {
            return D('PaymentType')->get_data_by_id($payment_type_id);
        }
    }
}
