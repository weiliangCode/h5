<?php
namespace Operate\Model;


class RegUserModel extends OperateModel {

	/**
	 * 构造,继承父类
	 */	
	public function __construct()
	{
		parent::__construct();	
	}

	/**
	 * 验证用户是否存在
	 * 
	 * @params String $account,$passwd
	 * 
	 * @return array/FALSE 当前1行数据
	 */

	public function verifyUser($data){

		$wmap['account'] = $data['account'];
		$wmap['passwd'] = $data['passwd'];
		$where['status'] = array('neq',2); //状态：0 未激活, 1 已经激活, 2 停用

		$r = $this
			->field('reg_user_id, account')
			->where($wmap)
			->where($where)
			->find();		

		return $r;
	}

	/**
	 * 保存用户相关信息
	 * 
	 * @params array $data 商户请求数据
	 * 
	 * @return bool
	 */
	public function saveData($data,$merchant_id)
	{
		if(!empty($merchant_id))
		{
			//更新
			return $this->where('merchant_id='.$merchant_id)->save($data); 
		}
	}

	/**
	 * 检测所修改账户是否存在
	 * 
	 * @params array $data 编辑商户信息
	 * 
	 * @return bool
	 */
	public function accountVerify($account)
	{	
		if(empty($account))
		{
			return FALSE;
		}
		
		$r = $this->where('account = \''.$account.'\'')->find();
		
		return $r;
	}

}