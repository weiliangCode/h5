<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class AppPayStatisticsController extends HomeController{
    static $status = [
        '处理中' => [1,2,4,6,7,9,10,12,13],
        '失败' => [3,5,8,11,14,16],
        '成功' => [15,17,18]
    ];
    public function __construct(){
        parent::__construct();
        if(is_null($this->param->created_ts))
            $this->param->created_ts = date('Y-m-d',$_SERVER['REQUEST_TIME'] );
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
    }
    // 指定应用单日交易订单统计
    //{"act":"2","method":"AppPayStatistics","op":"getInfoOneDay","data":{"merchant_app_id":"1","created_ts":"2016-05-01"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getInfoOneDay(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->created_ts)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id or created_ts ';
            exit(json_encode($this->returnData));
        }
        $where['pay_request.auth_app_id'] = $this->param->merchant_app_id;

        if($t = strtotime($this->param->created_ts)){
            $t2 = $t+3600*24;
            $where['pay_request.created_ts'][] = ['EGT',$this->param->created_ts ];
            $where['pay_request.created_ts'][] = ['LT', date('Y-m-d',$t2) ];
        }else{
            $this->returnData['message'] = 'created_ts 不合法';
            exit(json_encode($this->returnData));
        }

        $array = D('PayRequest')->getOneDayById($where);
//        var_dump($array);exit;
        // 开始统计
        $data = [
            'totle_num'=>0,
            'success_num'=>0,
            'totle_money'=>0
        ];
        if(!is_null($array)){
            foreach($array as $k=>$v){
                $data['totle_num'] ++;
                if( in_array($v['status_id'], self::$status['成功']))
                    $data['success_num'] ++;
                $data['totle_money'] += $v['amount'];
            }
        }

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $data;

        exit(json_encode($this->returnData));
    }
    // 指定应用单周交易订单统计 (区分支付渠道)
    // {"act":"2","method":"AppPayStatistics","op":"getInfoOneWeek","data":{"merchant_app_id":"1","created_ts":"2016-05-01"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getInfoOneWeek(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->created_ts)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id or created_ts ';
            exit(json_encode($this->returnData));
        }

        if($time = strtotime($this->param->created_ts)){
            for($i=0 ;$i<7; $i++){
                $t2 = $time + (3600 * 24);
                $where['pay_request.auth_app_id'] = $this->param->merchant_app_id;
                $where['pay_request.merchant_id'] = $this->sessionId->merchant_id;
                $where['pay_request.status_id'] = ['in',self::$status['成功']];
                $where['pay_request.created_ts'][] = ['EGT',date('Y-m-d', $time)];
                $where['pay_request.created_ts'][] = ['LT', date('Y-m-d', $t2)];

                $data[date('Y-m-d', $time)] = D('PayRequest')->getInfoByIdEvevyPaymenttype($where);
                $where = [];
//                if($i==6){
//                    echo date('Y-m-d', $time);
//                    echo D('PayRequest')->getLastSql();
//                }
//                var_dump($data[date('Y-m-d', $time)]);exit;
                $time = $t2;
            }
        }else{
            $this->returnData['message'] = 'created_ts 不合法';
            exit(json_encode($this->returnData));
        }

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $data;

        exit(json_encode($this->returnData));
    }
}
