<?php
namespace Operate\Model;
/**
 * Class AbnormalRequestModel 对应数据表 Abnormal_Request
 * @package Operate\Model
 * @author  tengyuan
 */
class ExcelModel extends OperateModel {
    private $temp = false;
    private $tempFileName = '';
    public function exportExcel($data, $key='key'){
        import('Vendor.phpExcel.PHPExcel');
        $name='Excel';
        $objPHPExcel = new \PHPExcel();

        /*以下是一些设置 ，什么作者  标题啊之类的*/
        $objPHPExcel->getProperties()->setCreator("数据EXCEL导出")
            ->setLastModifiedBy("数据EXCEL导出")
            ->setTitle("数据EXCEL导出")
            ->setSubject("数据EXCEL导出")
            ->setDescription("数据EXCEL导出")
            ->setKeywords("excel")
            ->setCategory("result file");
        // 确定标题
        $func = function($data){
            $arr = [];
            $A_Z = 'A';
            foreach($data[0] as $k => $v){
                $arr[$A_Z] = $k;
                $A_Z++;
            }
            return $arr;
        };
        $arr = $func($data);
        /*以下就是对处理Excel里的数据， 横着取数据，主要是这一步，其他基本都不要改*/
        // 设置标题
        $objPHPExcel->setActiveSheetIndex(0);
        foreach($arr as $k=>$v){
            $objPHPExcel
                ->getActiveSheet()
                ->setCellValue($k.'1', $v)
                ->getColumnDimension($k)
                ->setWidth( strlen($v) *1.5);
        }
        // 设置内容
        foreach($data as $k => $v){
            $num=$k+2;
            foreach($arr as $k2 => $v2){
                $objPHPExcel
                    ->getActiveSheet()
                    ->setCellValue($k2.$num, ' '.$v[$v2]); // 防止数字化
            }
        }
        $objPHPExcel->getActiveSheet()->setTitle('User');
        $objPHPExcel->setActiveSheetIndex(0);

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $xls = date('Y-m-d_H:i:s',$_SERVER['REQUEST_TIME']);

        ob_end_clean();//清除缓冲区,避免乱码
        header('pragma:public');
        header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xls.'.xls"');
        header("Content-Disposition:attachment;filename=$xls.xls");//attachment新窗口打印inline本窗口打印
        $objWriter->save('php://output');
        exit;
    }
    // Excel文件 to 2维数组
    function importExcel($filePath='', $key=0, $sheet=0){
        import('Vendor.phpExcel.PHPExcel');
        $filePath = $this->tempFileForExcel($filePath, $key);
        if(empty($filePath) or !file_exists($filePath)){die('file not exists');}
        $PHPReader = new \PHPExcel_Reader_Excel2007();        //建立reader对象
        if(!$PHPReader->canRead($filePath)){
            $PHPReader = new \PHPExcel_Reader_Excel5();
            if(!$PHPReader->canRead($filePath)){
                throw new \Exception('no Excel');
            }
        }
        $PHPExcel = $PHPReader->load($filePath);        //建立excel对象
        $currentSheet = $PHPExcel->getSheet($sheet);        //**读取excel文件中的指定工作表*/
        $allColumn = $currentSheet->getHighestColumn();        //**取得最大的列号*/
        $allRow = $currentSheet->getHighestRow();        //**取得一共有多少行*/
        $data = array();
        for($rowIndex=1;$rowIndex<=$allRow;$rowIndex++){        //循环读取每个单元格的内容。注意行从1开始，列从A开始
            for($colIndex='A';$colIndex<=$allColumn;$colIndex++){
                $addr = $colIndex.$rowIndex;
                $cell = $currentSheet->getCell($addr)->getValue();
                if($cell instanceof \PHPExcel_RichText){ //富文本转换字符串
                    $cell = $cell->__toString();
                }
                $data[$rowIndex][$colIndex] = $cell;
            }
        }
        $this->destruct();
        return $data;
    }
    /**
     * 将网路形式的excel文件生成本地缓存文件再读取
     * 之后注意删除
     * @param string $filePath   文件路径 or 网路地址
     * @param int $key    防止重名键
     *
     * @return string 本地文件路径
     */
    private function tempFileForExcel($filePath, $key=0){
        if(file_exists($filePath)) {
            $this->temp = false;
            return $filePath;
        }
        else if($data = file_get_contents($filePath)){
            $ext = pathinfo($filePath, PATHINFO_EXTENSION);
            $dir = TEMP_PATH;
            $tempName = $this->makeFilename($dir, $ext, $key);
            file_put_contents($tempName, $data);
            $this->temp = true;
            $this->tempFileName = $tempName;
            return $tempName;
        }
    }
    // 随机文件名
    private function makeFilename($dir='', $ext='', $id=123){
        $ext = trim($ext,'.');
        $dir .= uniqid($id);
        $dir .='.'.$ext;
        return $dir;
    }
    // 删除本地缓存文件
    private function destruct(){
        if($this->temp == true){
            unlink($this->tempFileName);
        }
    }
}