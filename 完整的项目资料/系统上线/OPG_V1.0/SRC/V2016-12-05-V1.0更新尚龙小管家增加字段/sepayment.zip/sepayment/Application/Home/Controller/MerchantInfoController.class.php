<?php
namespace Home\Controller;
use Think\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->zhouer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class MerchantInfoController extends HomeController{
    // 企业资料修改历史记录, 分页参数
    private $limit = '';
    /**
     * 我的资料展示
     * {"act":"2","method":"MerchantInfo","op":"getMerchantInfo","data":{"sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function getMerchantInfo(){
        $merchant_id = $this->sessionId->merchant_id;//当前用户账号ID
        $re = D('MerchantInfo')
            ->join('merchant ON merchant.merchant_id=merchant_info.merchant_id')
            ->join('reg_user ON reg_user.merchant_id=merchant_info.merchant_id')
            ->where([
                'merchant.merchant_id'=>$merchant_id,
                'audit_status' => 2
            ])
            ->field([
                'merchant.name as merchant_name',
                'reg_user.account',
                'merchant_info.*'
            ])
            ->find();
        $this->returnData['data']['list']['livekey'] = $re ? $re : [];

        $re = D('MerchantInfoAction')->where(['merchant_id'=>$merchant_id])->order('apply_ts desc')->find();
        $this->returnData['data']['list']['livekey_new'] = is_null($re) ? [] : $re;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }

    /**
     * 企业资料修改历史记录
     */
    public function getMerchantLog(){
        $merchant_id = $this->sessionId->merchant_id;
        $this->pageSql();
        $obj = D('MerchantInfoLog');
        $this->returnData['data']['pages']['total_count'] = $obj->getCountByMerchantId($merchant_id);
        $temp = $obj->getLogByMerchantId($merchant_id, $this->limit);
        $this->returnData['data']['list'] = $temp;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }

    /**
     * 我的资料更新
     */
    public function merchantInfoUpdate(){
        $res = D('MerchantInfo')->where([
            'merchant_id' => $this->sessionId->merchant_id,
            'audit_status' => 2,
        ])->find();
        if(!$res){
            $this->returnData['message'] = 'liveKey未曾审核通过,无权操作';
            exit(json_encode($this->returnData));
        }
        $ress = D('MerchantInfoAction')->where([
            'merchant_id' => $this->sessionId->merchant_id,
            'audit_status' => 1,
        ])->find();
        if($ress){
            $this->returnData['message'] = '存在正在审核的资料,无权操作';
            exit(json_encode($this->returnData));
        }
        //表单提交
        $di['merchant_name'] = $this->param->merchant_name;
        $di['merchant_id'] = $this->sessionId->merchant_id;
        $di['reg_address'] = $this->param->reg_address; //注册地址
        $di['work_address'] = $this->param->work_address; //办公地址
        $di['lisence_image'] = $this->param->lisence_image; //企业营业执照副本
        $di['org_image'] = $this->param->org_image; //组织机构代码
        $di['contact_name'] = $this->param->contact_name; //联系人姓名
        $di['contact_mail'] = $this->param->contact_mail; //联系人邮箱
        $di['contact_mobile'] = $this->param->contact_mobile; //联系人手机号码
        $di['apply_user'] = $this->sessionId->account;
        $di['apply_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
        $di['audit_status'] = 1;    //1 资料已提交，待审核
        $di['account'] = $this->sessionId->account;    // 登入账号
        $di['admin_op'] = 0;    // 是否管理员操作


        $e = D('MerchantInfoAction')->where([
            'merchant_id' => $this->sessionId->merchant_id,
            'admin_op' => 0
        ])->find();
        if($e)
            $res = D('MerchantInfoAction')->data($di)->where('merchant_id='.$this->sessionId->merchant_id)->save();
        else
            $res = D('MerchantInfoAction')->add($di);
        D('MerchantInfoLog')->add($di);
        if($res){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
}