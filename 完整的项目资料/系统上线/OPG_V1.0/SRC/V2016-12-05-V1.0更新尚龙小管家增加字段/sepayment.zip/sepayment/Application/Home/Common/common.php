<?php
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */

/**
 * 载入payment类库
 * 注意: 载入类可以跟路径,不要跟类文件后缀.php
 *
 * @params string 类路径
 * @params boolean 是否仅仅加载
 */
function load_pm_lib($cls_path, $just_require = false, $params = ''){
    static $_libs;

    if(isset($_libs[ $cls_path ])){
        return $_libs[ $cls_path ];
    }

    if(empty($cls_path)){
        return false;
    }

    $cls_paths = explode('/', $cls_path);
    $cls_name = $cls_paths[ count($cls_paths) - 1 ];

    $app_prefix_path = APP_PATH.MODULE_NAME;

    $lib_cls_path = '';
    if(strpos($cls_path, $app_prefix_path) !== false){
        $lib_cls_path = $cls_path.'.php';
    }
    else{
        $lib_cls_path = APP_PATH.MODULE_NAME.'/Lib/'.$cls_path.'.php';
    }

    require_once($lib_cls_path);

    if($just_require){
        return;
    }

    if(isset($params)){
        $cls = new $cls_name($params);
    }
    else{
        $cls = new $cls_name();
    }
    $_libs[ $cls_path ] = $cls;
    return $_libs[ $cls_path ];
}

/**
 * 验证码检测
 *
 * @params 用户输入的验证码字符串 $code
 * @params unkonw $id
 */

function check_verify($code, $id = ''){
    $verify = new \Think\Verify();
    return $verify->check($code, $id);
}



 