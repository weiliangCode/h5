<?php
namespace Home\Model;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team->zhuoer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */

class RegUserModel extends HomeModel{
    /**
     * 根据用户id获取用户信息
     * @params $reg_user_id  
     * @return bool
     */
    public function getDataById($reg_user_id){
        if(empty($reg_user_id) || !is_numeric($reg_user_id)){
            return false;
        }
        $wmap['reg_user_id'] = $reg_user_id;

        return $this->where($wmap)->find();
    }
    /**
     * 验证用户是否存在,并更新登入时间
     * @params String $account,$passwd
     * @return array/FALSE 当前1行数据
     */
    public function verifyUser($data){
        $wmap['account'] = $data['account'];
        $wmap['passwd'] = $data['passwd'];
        $where['status'] = array('eq', 1); //状态：0 未激活, 1 已经激活, 2 停用
        $r = $this->field('account,passwd,status,login_ts,reg_user_id,merchant_id')->where($wmap)->where($where)->find();
        return $r;
    }

    /**
     * 保存注册请求记录
     * @params array $data 注册请求数据
     * @return bool
     */
    public function saveData($data, $account = ''){
        if(isset($account) && !empty($account))
            return $this->where('account = \''.$account.'\'')->save($data);
        else{
            return $this->add($data);
        }
    }
    public function savePasswd($passwd, $account = '',$merchant_id){
        return $this->execute('UPDATE `reg_user` SET `merchant_id`=`reg_user_id`,`passwd`="'.$passwd.'",`merchant_id`="'.$merchant_id.'",`status`="1",`active_ts`="'.date('Y-m-d',$_SERVER['REQUEST_TIME'] ).'" WHERE `account`="'.$account.'"');
    }

    /**
     * 保存注册请求记录
     * @params array $data 注册请求数据
     * @return bool
     */
    public function saveDataById($data, $reg_user_id = ''){
        if(isset($reg_user_id) && !empty($reg_user_id)){
            //更新
            return $this->where('reg_user_id = \''.$reg_user_id.'\'')->save($data);
        }
        else{
            //创建
            return $this->add($data);
        }
    }

    /**
     * 检测账户是否存在
     * @params array $data 注册请求数据
     * @return bool
     */
    public function accountVerify($account){
        if(empty($account)){
            return false;
        }
        $r = $this->where('account = \''.$account.'\' and `passwd`!=""')->find();
        return $r;
    }

    /**
     * 获取商户相关信息
     *
     * @params array $data 商户请求数据
     *
     * @return bool
     */
    public function getUserInfo($reg_user_id){
        if(empty($reg_user_id) || !is_numeric($reg_user_id)){
            return false;
        }
        $wmap['reg_user.reg_user_id'] = $reg_user_id;
        $r = $this
            ->join('merchant ON reg_user.merchant_id = merchant.merchant_id')
            ->join('merchant_info ON reg_user.merchant_id = merchant_info.merchant_id')
            ->field('reg_user.reg_user_id, merchant.merchant_id, merchant.name, merchant_info.reg_address, merchant_info.work_address, merchant_info.lisence_image, merchant_info.org_image, merchant_info.contact_name, merchant_info.contact_mail, merchant_info.contact_mobile')
            ->where($wmap)
            ->find();
        return $r;
    }
    
    /**
     * 效验用户sessionId(实现包括 单用户登入,账号密码修改后的退出等)
     * @param $sessionId
     *
     * @return bool
     */
//    public function singleSign($sessionId,$session_id_str){
//        $sessionId_in_redis = self::$cache->get('SESSION'.$sessionId->account);
//        return ($sessionId_in_redis == $session_id_str);
//        $re = $this->where([
//            'account'=>$sessionId->account,
//            'passwd'=>$sessionId->passwd,
//            'status'=>$sessionId->status,
//            'login_ts'=>$sessionId->login_ts
//        ])->find();
//        echo $this->getLastSql();
//        return !is_null($re);
//    }

    /**
     * 检测短信验证码是否正确
     *
     * @params array $data 编辑商户信息
     *
     * @return bool
     */
//    public function shortMessageVerify($data){
//        $wmap['reg_user_id'] = $data['reg_user_id'];
//        $wmap['short_message'] = $data['short_message'];
//
//        $result = $this->field('*')->where($wmap)->select();
//        return $result;
//    }

}