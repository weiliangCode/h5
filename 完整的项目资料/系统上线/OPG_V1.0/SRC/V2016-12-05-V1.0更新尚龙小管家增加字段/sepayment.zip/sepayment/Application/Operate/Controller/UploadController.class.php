<?php
namespace Operate\Controller;
use Operate\Controller\OperateController;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package     suneee
 * @author      SunEEE PHP Team -> zhuoer
 * @interface   商户接口
 * @describe    接口描述
 * @input       借口参数示例
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */

class UploadController extends OperateController {

    /**
     * 图片上传地址
     * 
     * @type string
     */
    // protected $url = 'http://vr.weilian.cn/file-service/demo1.html';//外网地址
/*    protected $url = 'http://10.0.0.144:8081/file-service/';  //内网地址 
    protected $uploadUrl = 'file-api.upload?domain=OPG&type=user';
    protected $downloadUrl = 'file-api.download?domain=OPG&type=user';*/

    public function __construct()
    {
        parent::__construct();
    }
    /**
     * 上传图片
     * Enter description here ...
     *  {"act":"1","method":"upload","op":"index","data":{"user":"awen","password":"e10adc3949ba59abbe56e057f20f883e"},"sign":"456678wewqesa45d64sa56wqe45"}
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function index()
    {
        // print_r($this->param);
        $files = $_FILES['file'];
        if($files['tmp_name']){

            $file_url = './Public/upload/'.time().$files['name'];

            if(@move_uploaded_file($files['tmp_name'],$file_url)){
                $data['file'] = '@'.$file_url;
                $url = D('Operate/SysConfig')->UPLOAD_URL;
                $result = curl_post($url,$data);
                if($result)
                {
                    $result = json_decode($result);                     
                    if($result->status == 1){
                        //删除本地图片 
                        @unlink($file_url);

                        $this->returnData['code'] = 200 ; 
                        $this->returnData['message'] = '文件上传成功' ;
                        $this->returnData['data']['file_name'] = $result->data->fileName;    
                        $this->returnData['data']['file_url']   =  D('Operate/SysConfig')->URL.'image/OPG/user/'.$result->data->fileName;
                    }
                }

            }
            else
            {
                $this->returnData['code'] = 2211 ; 
                $this->returnData['message'] = '文件上传失败，请重试' ;                
            }
        }
        echo json_encode($this->returnData);
    }
}