<?php
namespace Payment\Controller;


/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;

/**
 * 商家DEMO
 * 
 * 商户调用SUNEEE支付网关的支付和转账接口
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
class InterfaceController extends PaymentController {

	//配置
	public $conf = array(
		//支付URL
		'pay_url' => 'http://dev.opg.suneee.com/opg/payment/pay',
		
		//同步回调页面
		'pay_return_url' => 'http://dev.opg.suneee.com/opg/payment/demo/pay_return_url',
		
		//异步回调页面
		'pay_notify_url' => 'http://dev.opg.suneee.com/opg/payment/demo/pay_notice_url',		

	    //支付宝返回页面
	    'pay_show_url' => 'http://www.baidu.com',
	    
		//退款URL
		'refund_url' => 'http://dev.opg.suneee.com/opg/payment/refund',

		//同步回调页面
		'refund_return_url' => 'http://dev.opg.suneee.com/opg/payment/demo/refund_return_url',
		
		//异步回调页面
		'refund_notify_url' => 'http://dev.opg.suneee.com/opg/payment/demo/refund_notice_url',	

        //转账URL
        'transfer_url' => 'http://dev.opg.suneee.com/opg/payment/transfer',

		//商家授权号
		'se_payment_code' => 'af70891aa4b8cc068dfd2af60c6270d7',

		//商家秘钥
		'se_payment_key' => '2f5cc53277fcf5f24c8ecb93c366b9a1',

		//无账户的商家授权号 (测试数据)
		'se_payment_code3' => 'eccbc87e4b5ce2fe28308fd9f2a7baf3',
		'se_payment_key3' => '3631578538a2d6ba5879b31a9a42f290',		
		
    );
	
	/**
	 * 商户调用SUNEEE支付的入口
	 */
    public function __construct()
    {
        parent::__construct(); 
    }

     /**
     * 支付接口
     */      
    public function pay_api()
    {

        $post = $_REQUEST;

        if(empty($post['payment_type_id'])){
            return FALSE;
        }
        //支付类型
        $this->payment_type_id = $post['payment_type_id'];
        //判断支付方式是否存在
        $m_pay_type = D('PaymentType');
        $payment_type = $m_pay_type->get_data_by_id($post['payment_type_id']);

        if($payment_type){
            $this->payment_type = $payment_type;
            //切换测试用户
            if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
            {
                $this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
                $this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
            }
            //1. 组装参数请求
            $params = array(
                'se_payment_code' => $this->conf['se_payment_code'],
                'payment_type_id'=>$this->payment_type_id,
                'bill_id'=>time(),
                'bill_type_id'=>'订单',
                'amount' => '0.01',
                'created_ts' => time(),
                'return_url' => $this->conf['pay_return_url'],
                'notify_url' => $this->conf['pay_notify_url'],
                'show_url' => $this->conf['pay_show_url'],
            );

    		$params['subject'] = '测试订单';
    		$params['description'] = '订单明细, a商品, b商品';
          
    		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['bill_id'].$params['bill_type_id'].$params['amount'].$params['created_ts']).$this->conf['se_payment_key']);
            
            if( $params['se_sign'] === FALSE )
            {
                die('sign failed!');
            }
            
            $response = $this->curl($this->conf['pay_url'], $params,'POST',true);
            
        	//2. 得到支付号并验证
        	if(isset($response) && (empty($response) || !preg_match('/^\w+$/', $response)))
        	{
        		die($response);
        	}
        	$pay_no = $response;
        	
        	//3. 商家应该保存当前交易号
        	//save_pay_no();
        	
        	//4. 重新封装交易号请求
        	$params = array(
        	    'se_payment_code' => $this->conf['se_payment_code'],
        	    'pay_no'=>$pay_no,
        	    'created_ts' => time()
        	);
        	$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['created_ts']).$this->conf['se_payment_key']);
        	//5. 从$params参数数组中移除不需要的商家授权号参数
        	unset($params['se_payment_code']);  
        	
        	// 检查参数合法性
        	$this->check_params_pay($params);        	

        	//6. 更新状态为  13, 14  //支付号请求验证成功, 支付号请求验证失败
        	$d['merchant_account_id'] = $this->pay_data['merchant_account_id'];
        	$r = $this->update_status('PayRequest', $this->pay_no, 13, 14, $d);

        	if(!$r || $this->has_err())
        	{
        	    $this->errlog('verify params failed for second pay request');
        	}
        	
        	//3. 请求支付网关
/*         	$ProcessPay = A('ProcessPay');
        	$ProcessPay->request_third_pay(); */
        	
        	$this->request_third_pay();
        	
        	exit;
        }else{
            return json_encode(array('code'=>'200','message'=>'不支持该支付方式','data'=>array()));
        }

    }
    //校验参数
    protected function check_params_pay($params=array())
    {
        //得到支付的配置
        $conf = C('pay');
        //定义配置
        $pconf = '';
        
		//赋值交易号给当前类
		$this->pay_no = $params['pay_no'];
		//得到参数格式配置
		$pconf = $conf['merchat_to_se_payno'];
		//验证参数的合法性
		$r = $this->verify_all_params($params, $pconf);
		if($r === FALSE)
		{
		    //如果验证不合法则报错
		    return FALSE;
		}
		//验证授权号
		$m_mer = D('Merchant');
		$pay_data = $m_mer->get_merchant_pay_data_by_pay_no($params['pay_no'],$this->payment_type_id);
// 		echo "<pre>";var_dump($pay_data);exit;
		//得到返回url,供返回使用
		$this->return_url = isset($pay_data['return_url']) ? $pay_data['return_url'] : '';
		
		//如果没有账号则报错
		if(empty($pay_data['merchant_account_id']) || empty($pay_data['se_payment_key']) || empty($pay_data['se_payment_code']))
		{
		    //如果验证不合法则输入错误状态并报错
		    $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $params['se_payment_code'] . '(' . $this->pay_no . ')');
		    return FALSE;
		}
		
		//验证签名
		$params['se_payment_code'] = $pay_data['se_payment_code'];
		$se_sign = $this->build_sign($params, $pconf, $pay_data['se_payment_key']);
		if(!$se_sign || $params['se_sign'] != $se_sign)
		{
		    $this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $params['se_sign'] . '(' . $this->pay_no . ')');
		    return FALSE;
		}
		//得到商家信息
		$this->pay_data = $pay_data;
	
		return TRUE;
    }
    
    /**
     * 请求第三方支付
     * @return void
     */
    protected function request_third_pay()
    {      
        //1. 检查是否是wap/web请求
        $data['client_type'] = is_mobile()===TRUE ? 'wap' : 'web';
    
        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['payment_type'] = $this->payment_type;
        $data['pay_data'] = $this->pay_data;
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/';

        //2.1 组合账户数据目录
        if(!isset($data['pay_data']['account_mer_id']) || empty($data['pay_data']['account_mer_id']))
        {
            $this->set_status('EMPTY_PARAMS', 'this is empty account_mer_id for request third pay: ' . json_encode($data['pay_data']));
            $this->errlog();
            return FALSE;
        }
        $data['merchant_data_path'] = MER_DATA_PATH.$data['pay_data']['account_mer_id'].'/'.$data['payment_type']['code'].'/';
        //2.2 组合账户数据的客户端目录
        $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$data['client_type'].'/';
//             echo '<pre>';var_dump($data);exit;
        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$this->payment_type['code'].'/'.$data['client_type'].'/'.$this->payment_type['code'], FALSE, $data);
        //调用第三方支付,并得到结果
        /*
         return array(
         //SE支付网关交易号
         'pay_no' => 'xxx',
         //第三方交易号
         'third_trade_no' => 'xxx',
         //SE支付网关的状态
         'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
         //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
         'status_msg' => '签名错误'
         );
        */
        $this->result = $cls->pay();
        $this->check_third_return_val($this->result);
    
        //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
        //返回data值
        $pay_no = $this->result['pay_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('PayRequest', $pay_no, 31, 32, $update_data);	//得到成功的支付结果, 得到失败的支付结果
    
        //4. 如果有错误,则返回到错误页面
        if($this->has_err())
        {
            $pay_data = D('Merchant')->get_merchant_pay_data_by_pay_no($pay_no);
            //在SE支付平台显示错误信息
            if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
            {
                $this->errlog();
            }
            //把错误信息返回到第三方平台
            else
            {
                $this->pay_data = $pay_data;
                $return_result = $this->get_return_result();
                header('Location:'.$pay_data['return_url'].'?'.http_build_query($return_result));
            }
        }
    
        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('PayRequest', $pay_no, 51, 52);
    
        //6. 回调商户的同步回调return_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        $pay_data = D('Merchant')->get_merchant_pay_data_by_pay_no($pay_no);
    
        if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
        {
            $this->assign('pay_data', $pay_data);
            if(is_mobile()){
                $this->display('wap_success');
            }else{
                $this->display('web_success');
            }
            exit;
        }
    
    }

    /**
     * 转账接口
     */
    public function transfer_api()
    {
        $post = $_REQUEST;
        
        if(empty($post['payment_type_id'])){
            return FALSE;
        }
        //支付类型
        $this->payment_type_id = $post['payment_type_id'];
        //判断支付方式是否存在
        $m_pay_type = D('PaymentType');
        $payment_type = $m_pay_type->get_data_by_id($post['payment_type_id']);

        //判断改支付方式是否支持转账
        if($payment_type['is_transfer']){
             $this->payment_type = $payment_type;
             //切换测试用户
             if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
             {
                 $this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
                 $this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
             }
             //1. 组装参数请求
             $params = array(
                 'se_payment_code' => $this->conf['se_payment_code'],
                 'payment_type_id'=>$this->payment_type_id,
                 'rec_account_no'=>'6222024000072983949',//对方账号
                 'rec_account_name'=>'汪伟',//姓名
                 'amount' => '0.01',//转账金额
                 'created_ts' => time(),
                 'return_url' => $this->conf['transfer_return_url'],
                 'notify_url' => $this->conf['transfer_notify_url'],
             );
             $params['subject'] = '测试标题';//标题
             $params['description'] = '测试详情';//详情
             $params['se_sign'] = md5(md5($params['se_payment_code'].$params['rec_account_no'].$params['amount'].$params['created_ts']).$this->conf['se_payment_key']);
             
             if(!$params['se_sign'])
             {
                 die('sign failed!');
             }

             //2. 请求转账
             $response = $this->curl($this->conf['transfer_url'], $params);

             //3. 得到转账号并验证
             if(isset($response) && (empty($response) || !preg_match('/^\w+$/', $response)))
             {
                 die($response);
             }
             $transfer_no = $response;
             
             //3. 商家应该保存当前交易号
             //save_transfer_no();
              
            //4. 重新封装转账号请求
            $params = array(
                'se_payment_code' => $this->conf['se_payment_code'],
                'transfer_no'=>$transfer_no,
                'created_ts' => time()
            );
            $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no'].$params['created_ts']).$this->conf['se_payment_key']);
            //5. 从$params参数数组中移除不需要的商家授权号参数
            unset($params['se_payment_code']);      
             
            // 检查参数合法性
            $this->check_params_transfer($params);
       
            //6. 更新状态为  13, 14  //支付号请求验证成功, 支付号请求验证失败
            $d['merchant_account_id'] = $this->transfer_data['merchant_account_id'];
            $r = $this->update_status('TransferRequest', $this->transfer_no, 13, 14, $d);
            
            if(!$r || $this->has_err())
            {
                $this->errlog('verify params failed for second transfer request');
            }
            
            $this->request_third_transfer();
             
            exit;
             
        }else{
            echo json_encode(array('code'=>'200','message'=>'不支持该转账方式','data'=>array()));
        }
    }
    //校验参数
    protected function check_params_transfer($params=array())
    {
        //得到转账的配置
        $conf = C('transfer');
        //定义配置
        $pconf = '';
    
        //赋值交易号给当前类
        $this->transfer_no = $params['transfer_no'];
        //得到参数格式配置
        $pconf = $conf['merchat_to_se_payno'];
        //验证参数的合法性
        $r = $this->verify_all_params($params, $pconf);
        if($r === FALSE)
        {
            //如果验证不合法则报错
            return FALSE;
        }
        //验证授权号
        $m_mer = D('Merchant');
        $transfer_data = $m_mer->get_merchant_transfer_data_by_transfer_no($params['transfer_no'],$this->payment_type_id);
        // 		echo "<pre>";var_dump($transfer_data);exit;
        //得到返回url,供返回使用
        $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';
    
        //如果没有账号则报错
        if(empty($transfer_data['merchant_account_id']) || empty($transfer_data['se_payment_key']) || empty($transfer_data['se_payment_code']))
        {
            //如果验证不合法则输入错误状态并报错
            $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $p['se_payment_code'] . '(' . $this->transfer_no . ')');
            return FALSE;
        }
    
        //验证签名
        $params['se_payment_code'] = $transfer_data['se_payment_code'];
        $se_sign = $this->build_sign($params, $pconf, $transfer_data['se_payment_key']);
        if(!$se_sign || $params['se_sign'] != $se_sign)
        {
            $this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $params['se_sign'] . '(' . $this->transfer_no . ')');
            return FALSE;
        }
        //得到商家信息
        $this->transfer_data = $transfer_data;
    
        return TRUE;
    }
    
    /**
     * 请求第三方转账
     * @return void
     */
    protected function request_third_transfer()
    {
        //1. 检查是否是wap/web请求
        $data['client_type'] = is_mobile()===TRUE ? 'wap' : 'web';
    
        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['payment_type'] = $this->payment_type;
        $data['transfer_data'] = $this->transfer_data;
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/';
    
        //2.1 组合账户数据目录
        if(!isset($data['transfer_data']['account_mer_id']) || empty($data['transfer_data']['account_mer_id']))
        {
            $this->set_status('EMPTY_PARAMS', 'this is empty account_mer_id for request third pay: ' . json_encode($data['transfer_data']));
            $this->errlog();
            return FALSE;
        }
        $data['merchant_data_path'] = MER_DATA_PATH.$data['transfer_data']['account_mer_id'].'/'.$data['payment_type']['code'].'/';
        //2.2 组合账户数据的客户端目录
        $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$data['client_type'].'/';
        //             echo '<pre>';var_dump($data);exit;
        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$this->payment_type['code'].'/'.$data['client_type'].'/'.$this->payment_type['code'], FALSE, $data);
        //调用第三方支付,并得到结果

        $this->result = $cls->transfer();
        $this->check_third_return_val($this->result);
    
        //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
        //返回data值
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);	//得到成功的支付结果, 得到失败的支付结果
    
        //4. 如果有错误,则返回到错误页面
        if($this->has_err())
        {
            $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);
            //在SE支付平台显示错误信息
            if(!isset($transfer_data['return_url']) || empty($transfer_data['return_url']))
            {
                $this->errlog();
            }
            //把错误信息返回到第三方平台
            else
            {
                $this->transfer_data = $transfer_data;
                $return_result = $this->get_return_result();
                header('Location:'.$transfer_data['return_url'].'?'.http_build_query($return_result));
            }
        }
    
        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('TransferRequest', $transfer_no, 51, 52);
    
        //6. 回调商户的同步回调return_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);
    
        if(!isset($transfer_data['return_url']) || empty($transfer_data['return_url']))
        {
            $this->assign('transfer_data', $transfer_data);
            if(is_mobile()){
                $this->display('Transfer/wap_success');
            }else{
                $this->display('Transfer/web_success');
            }
            exit;
        }
    
    }   













































}

?>