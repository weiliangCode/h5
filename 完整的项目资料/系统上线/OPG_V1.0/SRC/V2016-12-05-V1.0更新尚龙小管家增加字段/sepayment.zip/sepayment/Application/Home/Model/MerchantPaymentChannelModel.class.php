<?php
namespace Home\Model;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
/**
 * 商户支付渠道表模型
 * 用来操作支付类型数据模型
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
 */
class MerchantPaymentChannelModel extends HomeModel{
    /**
     * 根据查询条件,返回2维数组,用于企业支付渠道
     * @param array  $key
     * @param array  $where
     * @param string  $whereStr
     * @param string $order
     * @param string $limit
     * @return mixed 2维数组
     */
    public function searchData(array $key = array(), array $where = array(), $whereStr='',  $order = '', $limit = ''){
//        var_dump(func_get_args());
        $re = $this
//            ->join('merchant on merchant_payment_channel.merchant_id=merchant.merchant_id')
            ->join('payment_type on merchant_payment_channel.payment_type_id=payment_type.payment_type_id')
            ->field($key)
            ->where($where)
            ->where($whereStr)
            ->limit($limit)
            ->order($order)
            ->select();
//        echo $this->getlastsql();
        return $re;
    }

    /**
     * 返回数据总数
     * @return int
     */
    public function getCount(array $where = array(), $whereStr=''){
        $re = $this->field('count(*) as a')
            ->join('payment_type on merchant_payment_channel.payment_type_id=payment_type.payment_type_id')
            ->where($where)
            ->where($whereStr)
            ->select();
        //        echo $this->getlastsql();
        //        var_dump($re);exit;
        return $re[0]['a'];
    }
    /**
     * 保存渠道相关信息
     * @params array $data
     * @return bool
     */
    public function saveData($data, $payment_type_id, $merchant_id){
        if(!empty($payment_type_id)){
            //更新
            return $this
                ->where([
                    'payment_type_id'=>$payment_type_id,
                    'merchant_id' => $merchant_id
                ])
                ->save($data);
        }
    }
}