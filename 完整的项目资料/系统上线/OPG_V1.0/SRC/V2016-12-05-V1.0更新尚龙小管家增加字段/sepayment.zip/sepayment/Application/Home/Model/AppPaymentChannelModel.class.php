<?php
namespace Home\Model;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
/**
 * 应用支付渠道表模型
 * 用来操作支付类型数据模型
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class AppPaymentChannelModel extends HomeModel{
    /**
     * 保存渠道相关信息
     * @params array $data
     * @return bool
     */
    public function saveData($data, $payment_type_id, $merchant_app_id=false,$scenary_id=null){
        if($merchant_app_id ===false){
            echo '模型方法已更新,请更新调用控制器';exit;
        }
        $where = [
            'payment_type_id'=>$payment_type_id,
            'merchant_app_id'=>$merchant_app_id,
        ];
        if(!is_null($scenary_id))
            $where['scenary_id'] = $scenary_id;
        if(!empty($payment_type_id)){
            //更新
            return $this
                ->where($where)
                ->save($data);
        }
    }

    /**
     * 由应用id 返回该应用开通过的 支付渠道
     * @param $merchant_app_id
     *
     * @return array 一维数组
     */
    public function getPaymentsByAppId($merchant_app_id){
        $re = $this
//            ->join('merchant_app on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id ')
//            ->join('merchant_payment_channel on merchant_app.merchant_id=merchant_payment_channel.merchant_id AND merchant_payment_channel.payment_type_id = app_payment_channel.payment_type_id')
            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id ') // AND payment_type.active=1
            ->where([
//                'app_payment_channel.active_status'=> 3,
//                'merchant_payment_channel.active_status'=> 3,
                'app_payment_channel.merchant_app_id'=> $merchant_app_id,
            ])
            ->field('payment_type.`name`')
            ->group('payment_type.payment_type_id')
            ->select();
//        echo $this->getLastSql();exit;
//        var_dump($re);
        $arr = [];
        foreach($re as $v){
            $arr[] = $v['name'];
        }
        return $arr;
    }
}



























