<?php
namespace Operate\Model;
class PaymentTypeModel extends OperateModel{
    /**
     * 获取列表
     *
     * @params String
     *
     * @return array/FALSE 当前1行数据
     */
    public function getPaymentList($search = array(), $order = '', $offset, $pageSize){

        $r = $this
            ->field('payment_type_id,type,code,name,active,op_reason,op_user,op_ts')
            ->where($search)
            ->limit($offset, $pageSize)
            ->order($order)
            ->select();
        return $r;
    }

    /**
     * 获取数据总数
     *
     * @params String
     *
     * @return array/FALSE 当前1行数据
     */
    public function getCount($search = array()){
        $count = $this
            ->where($search)
            ->count();
        return $count;
    }

    /**
     * 保存渠道相关信息
     *
     * @params array $data 渠道请求数据
     *
     * @return bool
     */
    public function saveData($data, $payment_type_id){
        if(!empty($payment_type_id)){
            //更新
            return $this
                ->where('payment_type_id='.$payment_type_id)
                ->save($data);
        }
    }

    public function get($where){
        $r = $this
            ->field('active')
            ->where($where)
            ->select();
        foreach( $r as $key => $value ){
            $data[ $key ] = $value['active'];
        }
        return $data[0];
    }
}