<?php
namespace Home\Model;
/**
 * Class AbnormalRequestModel 对应数据表 Abnormal_Request
 * @package Operate\Model
 * @author  tengyuan
 */
class AbnormalRequestModel extends HomeModel {
    // 查询存在异常反馈的订单的 反馈信息
    public function getAbnormalByPayRequestId($PayRequestId){
        $re = $this
            ->join('pay_request on pay_request.pay_request_id=abnormal_request.pay_request_id','right')
            ->field('abnormal_request.*')
            ->where([
                'pay_request.pay_request_id' => $PayRequestId,
                'pay_request.abnormal_status' => ['NEQ',0],
            ])
            ->find();
        return $re;
    }
    // 将订单标记为异常
    public function createAbnormalWithPayRequestId($data){
        $this->startTrans();
        $a = D('PayRequest')->where([
            'pay_request_id'=> $data['pay_request_id'],
            'abnormal_status'=> 0
        ])->save(['abnormal_status'=>1]);
        $b = $this->add($data);
//        var_dump($a);
//        var_dump($b);
//        exit;
        if( ($a == 1) && ($b !== false)){
            return $this->commit();
        }else $this->rollback();
        return false;
    }
}