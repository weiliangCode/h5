<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->zhuoer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class PaymentTypeController extends OperateController{

    /**
     * 获取网关支付渠道列表
     * Enter description here ...
     * {"act":"1","method":"paymentType","op":"paymentsList","data":{"type":"","payment_type_id":"","active":"1","page_no":"1","page_size":"5"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function paymentsList(){
        $payment = D('PaymentType');
        //搜索
        $search = array();
        //渠道类型
        if(!is_null($this->param->type)){
            $search['type'] = $this->param->type;
        }
        //渠道名称（传payment_type_id）1--支付宝，2--银联支付,3--微信支付...
        if(!is_null($this->param->payment_type_id)){
            $search['payment_type_id'] = $this->param->payment_type_id;
        }
        //渠道状态
        if(!is_null($this->param->active)){
            $search['active'] = $this->param->active;
        }
        //排序
        $ser = '`type` ASC,created_ts ASC';

        $page = intval($this->param->page_no) < 1 ? 1 : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size);
        $pageSize = empty($pageSize) ? 5 : $pageSize;
        $offset = ($page - 1) * $pageSize;

        $data = array();
        //总条数
        $count = $payment->getCount($search);
        //商户列表
        $data = $payment->getPaymentList($search, $ser, $offset, $pageSize);

        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize, 'total_count' => $count);
        $this->returnData['data']['list'] = $data;

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';

        echo json_encode($this->returnData);

    }

    /**
     * 支付渠道禁用/启用
     * {"act":"1","method":"payment_type","op":"paymentsOp","data":{"payment_type_id":"1","active":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $list
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function paymentsOp(){
        $payment_type_id = $this->param->payment_type_id;

        if($payment_type_id > 0){
            $payment = D('PaymentType');
            $d['active'] = $this->param->active;
            $d['op_reason'] = $this->param->op_reason;
            $d['op_user'] = $this->sessionId->account;
            $d['op_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );

            $r = $payment->saveData($d, $payment_type_id);
            if($r === 1){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '渠道状态更新为 : '.$d['active'];
            }elseif($r === 0){
                $this->returnData['code'] = 201;
                $this->returnData['message'] = '渠道状态保持为 : '.$d['active'];
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        echo json_encode($this->returnData);
    }
    public function getPaymenttypeByAppId(){
        $payment_type_name = D('Operate/SysConfig')->PAYMENT_TYPE_NAME;
        if(!is_null($this->param->merchant_app_id)){
            $data = D('PaymentType')
                ->join('merchant_app ON merchant_app.merchant_app_id = "'.$this->param->merchant_app_id.'"')
                ->join('merchant_payment_channel ON payment_type.payment_type_id = merchant_payment_channel.payment_type_id AND merchant_payment_channel.merchant_id=merchant_app.merchant_id AND merchant_payment_channel.active_status = 3')
                ->join('app_payment_channel ON payment_type.payment_type_id = app_payment_channel.payment_type_id AND app_payment_channel.merchant_app_id ="'.$this->param->merchant_app_id.'" AND app_payment_channel.active_status = 3','LEFT')
                ->field([
                    'payment_type.payment_type_id',
                    'payment_type.name',
                    'payment_type.code',
                    'payment_type.active',
                    'payment_type.is_transfer',
                    'payment_type.type'
                ])
                ->where(['payment_type.active'=>1])
                ->select();
        }elseif(!is_null($this->param->active)){
            $data = D('PaymentType')
                ->field([
                    'payment_type.payment_type_id',
                    'payment_type.name',
                    'payment_type.code',
                    'payment_type.active',
                    'payment_type.is_transfer',
                    'payment_type.type'
                ])
                ->where(['payment_type.active'=>1])
                ->select();
        }
        else $data = D('PaymentType')->select();
        foreach($data as $k => $v){
            $data[$k]['type_name'] = $payment_type_name[$v['type']];
        }
        $this->returnData['data']['list'] = $data;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        //        echo D('PaymentType')->getLastSql();exit;
        //        var_dump($this->returnData['data']['list']);exit;
        exit(json_encode($this->returnData));
    }
    // 查询所有的植物渠道的is_transfer
    // {"act":"1","method":"payment_type","op":"getTransferPayment","data":{},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getTransferPayment(){
        $obj = D('paymentType');
        if(!is_null($this->param->payment_type_id) ){
            $obj->where(['payment_type_id' => $this->param->payment_type_id]);
        }
        $re = $obj->field([
            'payment_type_id',
            'name',
            'code',
            'is_transfer'
        ])->select();
        $this->returnData['data'] = $re;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }

    // 查询所有的植物渠道的is_transfer
    // {"act":"1","method":"payment_type","op":"is_transfer_op","data":{"payment_type_id":"1","is_transfer":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function is_transfer_op(){
        if(is_null($this->param->payment_type_id) || is_null($this->param->is_transfer)){
            $this->returnData['message'] = '缺少必要的参数 payment_type_id || is_transfer';
            exit(json_encode($this->returnData));
        }
        $re = D('paymentType')
            ->where([
                'payment_type_id' => $this->param->payment_type_id
            ])
           ->save(['is_transfer' => $this->param->is_transfer]);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }
}