<?php
namespace Home\Model;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class MerchantAppModel extends HomeModel{
    public function setCreateData(array $create = array()){
        $up = $this
            ->data($create)
            ->add();
//        echo $this->getlastsql();
        return $up;
    }

    /**
     * 根据查询条件,返回字符串值
     * @param  $where
     * @author binqian
     * @return mixed 2维数组
     */
    public function getByMerchantId($MerchantId,$limit=''){
        $wmap['merchant_app.merchant_id'] = $MerchantId;
        $wmap['merchant_app.status_del'] = 0;

        $r = $this
//            ->join('app_payment_channel on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id AND app_payment_channel.active_status=3', 'LEFT')
//            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id AND payment_type.active=1', 'LEFT')
            ->field('status_del,merchant_app.merchant_app_id,merchant_app.app_name,merchant_app.app_image,merchant_app.app_code')
            ->where($wmap)
            ->order('merchant_app.merchant_app_id')
            ->limit($limit)
            ->select();
//        		echo $this->getlastsql();
        return $r;
    }

    /**
     * 删除app (将指定app的status_del = 1)
     * @param array $where
     * @return bool
     */
    public function delApp(array $where){
        return $this->where($where)->save(['status_del' => 1]);
    }

    public function getCount($MerchantId){
        $wmap['merchant_app.merchant_id'] = $MerchantId;
        $wmap['merchant_app.status_del'] = 0;
        $r = $this
//            ->join('app_payment_channel on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id', 'LEFT')
//            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id', 'LEFT')
            ->field('count(*) as a')
            ->where($wmap)
            ->select();
//        		echo $this->getlastsql();exit;
        if($r)
            return $r[0]['a'];
        //		echo $this->getlastsql();
        return 0;
    }
//
//    public function getAppCodeById($app_id){
//        $re = $this->where(['merchant_app_id'=>$app_id])->field(['app_code'])->find();
//        return is_null($re) ? false : $re['app_code'];
//    }
}