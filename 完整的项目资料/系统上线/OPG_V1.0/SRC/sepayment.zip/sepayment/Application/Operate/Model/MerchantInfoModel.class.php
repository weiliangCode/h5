<?php
namespace Operate\Model;
class MerchantInfoModel extends OperateModel {
    /**
     * 保存商户相关信息
     * @params array $data 商户请求数据
     * @return bool
     */
    public function saveData($data, $merchant_id){
        if(!empty($merchant_id)){
            //更新
            return $this->where('merchant_id='.$merchant_id)->save($data);
        }
    }
}