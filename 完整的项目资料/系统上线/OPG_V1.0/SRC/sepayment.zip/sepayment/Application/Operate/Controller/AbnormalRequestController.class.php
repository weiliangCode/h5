<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package     suneee
 * @author      SunEEE PHP Team -> tengyuan
 * @interface   流水列表接口
 * @describe    前端输入bill_id/created_ts/status_id/payment_type_id/amount/Merchant_id，通过“流水列表接口”获取后台数据库中取出满足搜索条件的所有订单信息，然后将数据以JSON格式传输给前端
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */
class AbnormalRequestController extends OperateController{
    static $status = [
        '处理中' => [1, 2, 4, 6, 7, 9, 10, 12, 13],
        '失败' => [3, 5, 8, 11, 14, 16],
        '成功' => [15, 17, 18]
    ];
    static $AbnormalStatus = [
        ['abnormal_id' => '0', 'abnormal_name' => '其他'],
        ['abnormal_id' => '1', 'abnormal_name' => '支付状态正常未收到款'],
        ['abnormal_id' => '2', 'abnormal_name' => '退款状态正常未退回客户款项']
    ];
    // 查询条件数组
    private $search = array();
    // 排序标准
    private $order = '`created_ts` DESC';
    // 分页标准
    private $limit = '';
    // 需要返回的字段
    private $key = array(
        'pay_request.pay_request_id',
        'payment_type.name as payment_type_name',
        'pay_request.pay_no',
        'pay_request.bill_id',
        'pay_request.third_trade_no',
        'merchant.`name`',
        'pay_request.created_ts',
        'pay_request.amount',
        'pay_request.payment_type_id',
        'pay_request.status_id',
        'pay_request.description',
        'pay_request.se_payment_code',
        'pay_request.abnormal_status'
    );

    public function __construct(){
        parent::__construct();
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
    }

    // 管理平台异常类型查询
    // 返回”异常类型”选项的代号及中文释义
    public function getAbnormalType(){
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = self::$AbnormalStatus;
        exit(json_encode($this->returnData));
    }

    // 管理平台订单的异常处理与查询
    public function dealAbnormal(){
        if(is_null($this->param->pay_request_id)){
            $this->returnData['message'] = '参数不合法, pay_request_id';
            exit(json_encode($this->returnData));
        }
        // 查询
        if(is_null($this->param->abnormal_status) || is_null($this->param->reply)){
            $re = $this->returnData['data'] = D('AbnormalRequest')->getAbnormalByPayRequestId($this->param->pay_request_id);
        }
        // 处理
        else{
            $data = [
                'pay_request_id' => $this->param->pay_request_id,
                'audit_user' => $this->sessionId->account,
                'audit_ts' => date('Y-m-d', $_SERVER['REQUEST_TIME']),
                'audit_reason' => $this->param->reply,
                'abnormal_status' => $this->param->abnormal_status
            ];
            $re = D('AbnormalRequest')->dealAbnormalWithPayRequestId($data);
        }
        if($re){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    // 异常订单到处到Excel
    public function exportExcel(){
        $data = $this->getList(true);
        // 汉化字段
        if(isset($data[0])){
            $arr = [
                'payment_type_name' => '支付渠道名称',
                'bill_id' => '订单ID',
                'pay_no' => '支付流水号',
                'pay_request_id' => '翌支付内部ID',
                'created_ts' => '支付时间',
                'amount' => '订单金额',
                'description' => '备注',
//                'status_id' => '交易状态码',
//                'payment_type_id' => '支付渠道ID',
//                'se_payment_code' => '商户code',
                'third_trade_no' => '第三方流水号',
//                'abnormal_status' => '异常状态码',
                'status' => '交易状态',
                'enableRefund' => '可否退款(1可以,0不可以)',
                'note' => '不可退款原因',
                'name' => '企业名称',
            ];
            foreach($data as $k => $v){
                $new = [];
                foreach($v as $k1=>$v1){
                    if(key_exists($k1, $arr)){
                        $new[$arr[$k1]] = $v1;
                    }else $new[$k1] = $v1;
                }
                $data2[] = $new;
            }
            $data = $data2;
        }
        return D('Operate/Excel')->exportExcel($data);
    }

    /**
     * main
     * 获取订单列表
     * {"act":"1","method":"AbnormalRequest","op":"getList","data":{"sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
     */
    public function getList($export = false){
        if($this->searchSql() && $this->pageSql() && $this->getData($export)){
            if($export)
                return $this->returnData['data']['list'];
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        //        echo $this->returnData;exit;
        exit(json_encode($this->returnData));
    }

    /**
     * 根据查询条件,
     * @return $this->search
     */
    private function searchSql(){
        if(!is_null($this->param->bill_id))
            $this->search['pay_request.bill_id'] = $this->param->bill_id;
        if(!is_null($this->param->pay_no))
            $this->search['pay_request.pay_no'] = $this->param->pay_no;
        if(!is_null($this->param->status))
            $this->search['pay_request.status_id'] = ['IN', self::$status[ $this->param->status ]];
        if(!is_null($this->param->payment_type_id))
            $this->search['pay_request.payment_type_id'] = $this->param->payment_type_id;
        if(!is_null($this->param->se_payment_code))
            $this->search['pay_request.se_payment_code'] = $this->param->se_payment_code;
        if(!is_null($this->param->merchant_name))
            $this->search['merchant.name'] = ['LIKE', '%'.$this->param->merchant_name.'%'];
        if(!is_null($this->param->third_trade_no))
            $this->search['pay_request.third_trade_no'] = $this->param->third_trade_no;
        if(!is_null($this->param->amount_min))
            $this->search['pay_request.amount'][] = array('EGT', $this->param->amount_min);
        if(!is_null($this->param->amount_max))
            $this->search['pay_request.amount'][] = array('ELT', $this->param->amount_max);
        if(!is_null($this->param->created_ts_min))
            $this->search['pay_request.created_ts'][] = array('EGT', $this->param->created_ts_min);
        if(!is_null($this->param->created_ts_max))
            $this->search['pay_request.created_ts'][] = array('ELT', $this->param->created_ts_max);
        $this->search['pay_request.abnormal_status'] = ['NEQ', 0];
        return true;
    }

    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize);
        return true;
    }

    /**
     * 数据操作
     * @return $this->returnData
     */
    private function getData($export = false){
        if($export)
            $this->limit = '';
        $obj = D('PayRequest');
        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search);
        $temp = $obj->searchData($this->key, $this->search, $this->order, $this->limit);
        //        echo $obj->getLastSql();exit;
        foreach( $temp as $k => $v ){
            foreach( self::$status as $k2 => $v2 ){
                if(in_array($v['status_id'], $v2)){
                    $temp[ $k ]['status'] = $k2;
                    continue;
                }
            }
        }
        $this->returnData['data']['list'] = $temp;
        return true;
    }
}