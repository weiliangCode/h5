<?php
namespace Operate\Model;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class MerchantInfoActionModel extends OperateModel {
    public function getInfoById($mer_id, $admin_op){
        $r = $this
            ->field('merchant_info_action.merchant_id,
            merchant_info_action.merchant_name as name,
            merchant_info_action.account,
            merchant_info_action.admin_op,
            merchant_info_action.reg_address,
            merchant_info_action.work_address,
            merchant_info_action.lisence_image,
            merchant_info_action.org_image,
            merchant_info_action.contact_name,
            merchant_info_action.contact_mail,
            merchant_info_action.contact_mobile,
            merchant_info_action.apply_ts')
            ->where([
                'merchant_info_action.merchant_id'=> $mer_id,
                'merchant_info_action.admin_op'=> $admin_op
            ])
            ->find();
        return $r;
    }
    // 企业资料修改审核通过
    public function VerifySuccess($merchant_id,$admin_op,$account,$reason){
        $this->startTrans();
        $r = $this
            ->execute(
'UPDATE merchant_info_action
INNER JOIN merchant_info ON merchant_info.merchant_id=merchant_info_action.merchant_id
INNER JOIN merchant ON merchant.merchant_id=merchant_info_action.merchant_id
INNER JOIN reg_user ON reg_user.merchant_id=merchant_info_action.merchant_id
set merchant.name=merchant_info_action.merchant_name,
reg_user.account=merchant_info_action.account,
merchant_info.merchant_id=merchant_info_action.merchant_id,
merchant_info.area_id=merchant_info_action.area_id,
merchant_info.member_id=merchant_info_action.member_id,
merchant_info.actual_name=merchant_info_action.actual_name,
merchant_info.company_type=merchant_info_action.company_type,
merchant_info.reg_address=merchant_info_action.reg_address,
merchant_info.work_address=merchant_info_action.work_address,
merchant_info.lisence_image=merchant_info_action.lisence_image,
merchant_info.org_image=merchant_info_action.org_image,
merchant_info.contact_name=merchant_info_action.contact_name,
merchant_info.contact_mail=merchant_info_action.contact_mail,
merchant_info.contact_mobile=merchant_info_action.contact_mobile,
merchant_info.contact_telphone=merchant_info_action.contact_telphone,
merchant_info.apply_user=merchant_info_action.apply_user,
merchant_info.apply_ts=merchant_info_action.apply_ts,
merchant_info.audit_status="2",
merchant_info.audit_ts="'.date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] ).'",
merchant_info.audit_reason="'.$reason.'",
merchant_info.audit_user="'.$account.'"'.' where  merchant_info_action.merchant_id="'.$merchant_id.'" AND merchant_info_action.admin_op="'.$admin_op.'"'
            );
        $del = $this->where([
            'merchant_id'=> $merchant_id,
            'admin_op'=> $admin_op
        ])->delete();
        if( ($r!==false) && ($del!==false)){
            $this->commit();
            return true;
        }else  {
            $this->rollback();
            return false;
        }
    }
}