<?php
namespace Operate\Controller;
use Operate\Controller\OperateController;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package     suneee
 * @author      SunEEE PHP Team -> binqian
 * @interface   应用支付渠道列表接口
 * @describe    前端输入merchant_app_id/App_name/merchant_id/name/active，通过“应用支付渠道列表接口”获取后台数据库中取出满足搜索条件的所有应用支付渠道信息，然后将数据以JSON格式传输给前端
 * @input       post:{"act":"1","method":"Payments","op":"paymentslist","data":{"sessionId":"UzBCRGFoY1NVUk52VVZjTlUwZFJWVk1OUUYwU0R3SUZWUXBh","merchant_app_id":"1","App_name":"应用1","merchant_id":"1","name":"支付宝","active_status":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
 * @author      SunEEE PHP Team -> tengyuan
 * @interface   企业支付渠道列表接口
 * @describe    前端输入merchant_id/name/active，通过“平台支付渠道列表接口”获取后台数据库中取出满足搜索条件的所有支付渠道信息，然后将数据以JSON格式传输给前端
 * @input       post:{"act":"1","method":"Payments","op":"paymentslistCompany","data":{"sessionId":"UzBCRGFoY1NVUk52VVZjTlUwZFJWVk1OUUYwU0R3SUZWUXBh","merchant_name":"suneee","payment_name":"支付宝","active_status":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */
class PaymentsController extends OperateController{
    // 查询条件数组
    private $search = array();
    // 排序标准
    private $order = 'convert(merchant.name using gbk) ASC,convert(merchant_app.app_name using gbk) ASC,payment_type.type ASC,payment_type.created_ts ASC';
    // 排序标准企业支付渠道管
    private $orderCompany = 'convert(merchant.name using gbk) ASC,payment_type.type ASC,payment_type.created_ts ASC';
    // 分页标准 
    private $limit = '';
    // 应用支付渠道管理列表, 需要返回的字段
    private $key = [
        'app_payment_channel.merchant_app_id',
        'merchant_app.app_name',
        'merchant_app.app_code',
        'merchant.name as mname',
        'merchant.merchant_id',
        'payment_type.name as pname',
        'payment_type.active',
        'payment_type.op_user',
        'payment_type.op_ts',
        'payment_type.op_reason',
        'app_payment_channel.apply_ts',
        'app_payment_channel.active_status',
        'app_payment_channel.audit_reason',
        'app_payment_channel.audit_user',
        'app_payment_channel.audit_ts',
        'app_payment_channel.payment_type_id',
        'app_payment_channel.scenary_id',
        'payment_scenary.name as scenary_name'
    ];
    // 企业支付渠道管理列表, 需要返回的字段
    private $keyCompany = [
        'merchant.name as mname',
        'merchant.merchant_id',
        'payment_type.name as pname',
        'payment_type.payment_type_id',
        'payment_type.op_user',
        'payment_type.op_ts',
        'payment_type.op_reason',
        'merchant_payment_channel.active_status',
        'merchant_payment_channel.audit_reason',
        'merchant_payment_channel.audit_user',
        'merchant_payment_channel.audit_ts',
        'merchant_payment_channel.admin_op'
    ];
    // 平台支付渠道启用状态
    private $paymentType = [];
    // 企业支付渠道启用状态
    private $paymentTypeCompany = [];
    // 当前查询的状态  启用 1 | null 0 | 禁用 -1
    private $paymentTypeStatus = 0;
    // 用于解决 mysql 查选的 and or 优先级问题
    private $whereStr = '1';

    public function __construct(){
        parent::__construct();
        $temp = D('PaymentType')->field(['payment_type_id','active'])->select();
        foreach($temp as $k=>$v){
            $this->paymentType[$v['payment_type_id']] = $v['active'];
        }
    }
    /**
     * 应用支付渠道管理列表
        3:启用
        4:禁用 ( 用户应用禁用 )
        5:管理员平台禁用
        6:用户商户禁用
        7 管理员商户禁用
        8 管理员应用禁用
     */
    public function paymentslist(){
        if($this->searchSql() && $this->pageSql() && $this->getData()){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 企业支付渠道管理
        3:启用
        4:禁用 ( 用户商户禁用 )
        5:管理员平台禁用
        7 管理员商户禁用
     */
    public function paymentslistCompany(){
        if($this->searchSqlCompany() && $this->pageSql() && $this->getDataCompany()){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 企业/平台支付渠道操作接口(禁用/启用)[共用模块]
     * {"act":"1","method":"Payments","op":"paymentsOp","data":{"merchant_id":"1","payment_type_id":"1","active_status":"1","audit_reason":"test!!"},"sign":"456678wewqesa45d64sa56wqe45"}
     *     * @author bingqian tengyuan
     */
    public function paymentsOp(){
        /**
         * 在此不需要判断上级是否已经启用, 只需要在调用时严格判断即可
         */
        if(!is_null($this->param->payment_type_id)){
            $where['payment_type_id'] = $this->param->payment_type_id;

            if(!is_null($this->param->merchant_app_id)){
                $where['merchant_app_id'] = $this->param->merchant_app_id;
                $where['scenary_id'] = $this->param->scenary_id;
                $obj = D('AppPaymentChannel');
            }elseif(!is_null($this->param->merchant_id)){
                $where['merchant_id'] = $this->param->merchant_id;
                $obj = D('MerchantPaymentChannel');
            }else{
                $this->returnData['message'] = '参数不合法!';
                exit(json_encode($this->returnData));
            }
            if(!is_null($this->param->active_status)){
                $update['active_status'] = $this->param->active_status;
                $update['audit_reason'] = $this->param->audit_reason;
                $update['audit_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
//                if($this->param->active_status !== 3)
                    $update['admin_op'] = 1; // 管理员操作
//                else $update['admin_op'] = 0;
            }else{
                $this->returnData['code'] = 2211;
                $this->returnData['message'] = '不存在 active_status';
                exit(json_encode($this->returnData));
            }
            $update['audit_user'] = $this->sessionId->account;

            $data = $obj->setUpdateData($where, $update);

            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            $this->returnData['data']['list'] = $data;

        }
        exit(json_encode($this->returnData));
    }

    /**
     * 根据查询条件,组装sql
     * @author bingqian
     */
    private function searchSql(){
        if(!is_null($this->param->merchant_app_id)){
            if(is_numeric($this->param->merchant_app_id))
                $this->search['app_payment_channel.merchant_app_id'] = $this->param->merchant_app_id;
            else {
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'merchant_app_id not a number';
                exit(json_encode($this->returnData));
            }
        }
        if(!is_null($this->param->app_code))
            $this->search['merchant_app.app_code'] = $this->param->app_code;
        if(!is_null($this->param->app_name))
            $this->search['merchant_app.app_name'] = array('like', '%'.$this->param->app_name.'%');
        if(!is_null($this->param->name))
            $this->search['merchant.name'] = array('like', '%'.$this->param->name.'%');
        if(!is_null($this->param->payment_type_id))
            $this->search['app_payment_channel.payment_type_id'] = $this->param->payment_type_id;
        if(!is_null($this->param->active_status)){
            $this->whereStr = ' app_payment_channel.active_status ="'. $this->param->active_status.'"';
            $this->paymentTypeStatus = ($this->param->active_status==3) ? 1 : -1;
        }
        return true;
    }

    /**
     * 根据查询条件,组装sql
     * @author tengyuan
     */
    private function searchSqlCompany(){
        if(!is_null($this->param->merchant_name))
            $this->search['merchant.name'] = ['LIKE', '%'.$this->param->merchant_name.'%'];
        if(!is_null($this->param->payment_name))
            $this->search['payment_type.name'] = ['LIKE', '%'.$this->param->payment_name.'%'];
        if(!is_null($this->param->payment_type_id))
            $this->search['payment_type.payment_type_id'] = $this->param->payment_type_id;
        if(!is_null($this->param->active_status)){
//            $this->search['merchant_payment_channel.active_status'] = $this->param->active_status;
            $this->whereStr = ' merchant_payment_channel.active_status ="'. $this->param->active_status.'"';
            $this->paymentTypeStatus = ($this->param->active_status==3) ? 1 : -1;
        }
        return true;
    }

    /**
     * 根据分页条件,拼sql,返回数组[共用模块]
     * @author bingqian tengyuan
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize);
        return true;
    }

    /**
     * 应用支付渠道数据操作
     * @author bingqian
     */
    private function getData(){
        $obj = D('AppPaymentChannel');

        $in_array = [];
        if($this->paymentTypeStatus == 1){
            $and_or = ' AND ';
            foreach( $this->paymentType as $k => $v ){
                if($v == 1)
                    $in_array[] = $k;
            }
        }elseif($this->paymentTypeStatus == -1){
            $and_or = ' OR ';
            foreach( $this->paymentType as $k => $v ){
                if($v == 0)
                    $in_array[] = $k;
            }
        }
        $st = '(';
        $t = $this->param->active_status ? 'merchant_payment_channel.active_status = "'.$this->param->active_status.'"' : '';
        if(!empty($in_array)){
            foreach($in_array as $k=>$v){
                $st .=$v.',';
            }
            $st = trim($st,',').')';
            $and_or .= $t .$and_or.' payment_type.payment_type_id in '.$st;
        }elseif($this->paymentTypeStatus == 1){
            foreach($this->paymentType as $k=>$v){
                $st .=$k.',';
            }
            $st = trim($st,',').')';
            $and_or .= $t.$and_or.' payment_type.payment_type_id not in '.$st;
        }else
            $and_or .= $t;
        $this->whereStr = ' ( '.$this->whereStr.$and_or.')';

        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search, $this->whereStr);
        $temp = $obj->searchData($this->key, $this->search, $this->order, $this->limit, $this->whereStr);
//        var_dump($temp);exit;
//echo $obj->getLastSql();exit;
        foreach ($temp as $k=>$v){
            // 支付渠道总禁用, 使用 支付渠道总禁用的 禁用人 禁用原因 禁用时间
            if( $this->paymentType[$v['payment_type_id']] == 0 ){
                $temp[$k]['active_status'] = '5';
                $temp[$k]['audit_reason'] = $v['op_reason'];
                $temp[$k]['audit_user'] = $v['op_user'];
                $temp[$k]['audit_ts'] = $v['op_ts'];
                continue;
            }
            // 进程中 缓存 商户对应渠道的启用禁用信息
            if(isset($this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']])){
                // 商户对应渠道禁用  使用 商户对应渠道禁用的 禁用人 禁用原因 禁用时间
                loop : if($this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']]['active_status'] != 3){
                    $temp[$k]['active_status'] = $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']]['active_status'];
                    $temp[$k]['audit_user'] = $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']]['audit_user'];
                    $temp[$k]['audit_reason'] = $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']]['audit_reason'];
                    $temp[$k]['audit_ts'] = $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']]['audit_ts'];
                    continue;
                }
            }else{
                $tmp =  D('MerchantPaymentChannel')
                    ->field([
                        'active_status',
                        'audit_user',
                        'audit_reason',
                        'audit_ts'
                    ])
                    ->where([
                        'merchant_id'=>$v['merchant_id'],
                        'payment_type_id'=>$v['payment_type_id'],
                    ])
                    ->find();
                if(($tmp['active_status'] != 3) && ($tmp['admin_op'] == 1) )
                    $tmp['active_status'] = '7'; // 管理员 对商户的此渠道 禁用了
                elseif(($tmp['active_status'] != 3) && ($tmp['admin_op'] == 0) )
                    $tmp['active_status'] = '6'; // 商户自己 对商户的此渠道 禁用了
                $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']] = [
                    'active_status' => $tmp['active_status'],
                    'audit_user' => $tmp['audit_user'],
                    'audit_reason' => $tmp['audit_reason'],
                    'audit_ts' => $tmp['audit_ts'],
                ];
                goto loop;
            }
            if( ($v['admin_op'] == 1) && ($v['active_status'] != 3)){
                $temp[$k]['active_status'] = '8';
                continue;
            }
        }
//        $temp = $this->makeArr($temp,'app_name');
//        $this->returnData['data']['list'] = $this->makeArr($temp,'mname');
        $this->returnData['data']['list'] = $temp;
//        var_dump($temp);exit;
        return true;
    }

    /**
     * 企业支付渠道数据操作
     * @author tengyuan
     */
    private function getDataCompany(){
        $obj = D('MerchantPaymentChannel');
        $in_array = [];
        if($this->paymentTypeStatus == 1){
            $and_or = ' AND ';
            foreach( $this->paymentType as $k => $v ){
                if($v == 1)
                    $in_array[] = $k;
            }
        }elseif($this->paymentTypeStatus == -1){
            $and_or = ' OR ';
            foreach( $this->paymentType as $k => $v ){
                if($v == 0)
                    $in_array[] = $k;
            }
        }
        $st = '(';
        if(!empty($in_array)){
            foreach($in_array as $k=>$v){
                $st .=$v.',';
            }
            $st = trim($st,',').')';
            $and_or .=' payment_type.payment_type_id in '.$st;
        }elseif($this->paymentTypeStatus == 1){
            foreach($this->paymentType as $k=>$v){
                $st .=$k.',';
            }
            $st = trim($st,',').')';
            $and_or .=' payment_type.payment_type_id not in '.$st;
        }else $and_or='';
        $this->whereStr = ' ( '.$this->whereStr.$and_or.')';

        $this->returnData['data']['pages']['total_count'] = $obj->getCountCompany($this->search, $this->whereStr);
        $temp = $obj->searchDataCompany($this->keyCompany, $this->search, $this->orderCompany, $this->limit, $this->whereStr);
//        var_dump($temp);exit;
//        echo $obj->getLastSql();exit;
        foreach ($temp as $k=>$v){
            // 支付渠道总禁用, 使用 支付渠道总禁用的 禁用人 禁用原因 禁用时间
            if( $this->paymentType[$v['payment_type_id']] == 0 ){
                $temp[$k]['active_status'] = '5';
                $temp[$k]['audit_reason'] = $v['op_reason'];
                $temp[$k]['audit_user'] = $v['op_user'];
                $temp[$k]['audit_ts'] = $v['op_ts'];
            }
            elseif( ($v['admin_op'] == 1) && ($v['active_status'] != 3))
                $temp[$k]['active_status'] = '7';
        }
//        $this->returnData['data']['list'] = $this->makeArr($temp,'mname');
        $this->returnData['data']['list'] = $temp;
        return true;
    }

    /**
     * 获取应用支付渠道配置详情
     * {"act":"1","method":"Payments","op":"paraDetail","data":{"scenary_id":"1","payment_type_id":"1","merchant_app_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     */
    public function paraDetail(){
        $merchant_app_id = $this->param->merchant_app_id;
        $payment_type_id = $this->param->payment_type_id;
        $scenary_id = $this->param->scenary_id;

        //返回数据
        $data = D('PaymentParameterDefine')->getInfo($merchant_app_id, $payment_type_id, $scenary_id);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $data;
//        var_dump($data);exit;
        exit(json_encode($this->returnData));
    }

    /**
     * 按首字字母顺序进行排列，同字母开头的根据第二个文字的字母排序
     * @param array $arr 排序数组
     * @param string $key 排序键
     * @return array
     */
//    private function makeArr($arr, $key=''){
//        return $arr;
//        if($arr == null) return [];
//        $new_array = [];
//        $i = 0;
//        foreach( $arr as $k => $v ){
//            loop : $i++;
//            if(!isset($new_array[ iconv('UTF-8', 'GBK', $v[ $key ]).(string)$i ]))
//                $new_array[ iconv('UTF-8', 'GBK', $v[$key]).(string)$i ] =  $v ;
//            else goto loop;
//        }
//        ksort($new_array);
//        return array_values($new_array);
//    }
}