<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package     suneee
 * @author      SunEEE PHP Team -> zhuoer
 * @interface   商户接口
 * @describe    接口描述 企业资料修改审核相关
 * @input       借口参数示例
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */
class MerchantInfoActionController extends OperateController{
    /**
     * 企业资料修改审核
     * Enter description here ...
     * {"act":"1","method":"MerchantInfoAction","op":"merchantInfoActionList","data":{"page_no":"1","page_size":"3"},"sign":"456678wewqesa45d64sa56wqe45"}
     * 2016-09-23 修改查询为 原企业名 和 原企业账户
     */
    public function merchantInfoActionList(){
        $m_mer = D('Merchant');
        //搜索
        $search = array();
        if(!is_null($this->param->merchant_id)){
            if(is_numeric($this->param->merchant_id))
                $search['merchant.merchant_id'] = $this->param->merchant_id;
            else {
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'merchant_id not a number';
                exit(json_encode($this->returnData));
            }
        }
        if(!is_null($this->param->name)){
            $search['merchant.name'] = array('LIKE', '%'.$this->param->name.'%');
        }
        if(!is_null($this->param->account)){
            $search['reg_user.account'] = $this->param->account;
        }
        if(!is_null($this->param->audit_status)){
            if($this->param->audit_status == 0){
                $search['merchant_info_action.audit_status'] = array('IN', '1,3');
            }else{
                $search['merchant_info_action.audit_status'] = $this->param->audit_status;
            }
        }
        //排序 当为会员签约审核列表接口时传此参数
        $ser = isset($this->param->order_seq) && $this->param->order_seq == 1 ? 'merchant_info_action.audit_status ASC, merchant_info_action.apply_ts DESC' : 'merchant_info_action.apply_ts DESC';
        // $ser = 'merchant_info.apply_ts DESC';
        $page = intval($this->param->page_no) < 1 ? 1 : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size);
        $pageSize = empty($pageSize) ? 5 : $pageSize;
        $offset = ($page - 1) * $pageSize;
        //总条数
        $count = $m_mer->getActionCount($search);

        //商户列表
        $data = $m_mer->getMerchantActionList($search, $ser, $offset, $pageSize);
//echo $m_mer->getLastSql();
//        var_dump($data);exit;

        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize, 'total_count' => $count);
        $this->returnData['data']['list'] = $data;

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';

        echo json_encode($this->returnData);
    }

    /**
     * 企业资料详情信息
     * {"act":"1","method":"MerchantInfoAction","op":"merchantActionDetail","data":{"merchant_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     */
    public function merchantActionDetail(){
        if(is_null($this->param->admin_op) || is_null($this->param->merchant_id) ){
            $this->returnData['message'] = '参数 merchant_id, admin_op 缺少';
            exit( json_encode($this->returnData));
        }
        $merchant_id = $this->param->merchant_id;
        $admin_op = $this->param->admin_op;

        $livekey_new = D('MerchantInfoAction')->getInfoById($merchant_id, $admin_op);
        $livekey = D('Merchant')->getApplyInfo($merchant_id);
        $livekey_change = $this->getChange($livekey, $livekey_new);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list']['livekey_new'] = $livekey_new;
        $this->returnData['data']['list']['livekey'] = $livekey;
        $this->returnData['data']['list']['livekey_change'] = $livekey_change;

        echo json_encode($this->returnData);
    }

    /**
     * 企业资料修改历史记录
     * {"act":"1","method":"MerchantInfoAction","op":"getMerchantLog","data":{"merchant_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     */
    public function getMerchantLog(){
        if(is_null($this->param->merchant_id)){
            $this->returnData['message'] = '缺少必要参数 merchant_id';
            exit(json_encode($this->returnData));
        }else $merchant_id = $this->param->merchant_id;
        $this->pageSql();
        $obj = D('MerchantInfoLog');
        $this->returnData['data']['pages']['total_count'] = $obj->getCountByMerchantId($merchant_id);
        $temp = $obj->getLogByMerchantId($merchant_id, $this->limit);
        $this->returnData['data']['list'] = $temp;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }
    /**
     * 企业资料修改审核  审核接口(通过/不通过)
     * {"act":"1","method":"MerchantInfoAction","op":"merchantActionVerify","data":{"merchant_id":"1","audit_status":"2"},"sign":"456678wewqesa45d64sa56wqe45"}
     */
    public function merchantActionVerify(){
        if(is_null($this->param->admin_op) || is_null($this->param->merchant_id) ){
            $this->returnData['message'] = '参数 merchant_id, admin_op 缺少';
            exit( json_encode($this->returnData));
        }
        $merchant_id = $this->param->merchant_id;
        $admin_op = $this->param->admin_op;
        if($merchant_id > 0){
            $m_info = D('MerchantInfoAction');
            $m_info->startTrans();
            $audit_status = $this->param->audit_status;
            // 审核通过
            if($audit_status == 2 ){
                $r = $m_info->VerifySuccess($merchant_id,$admin_op, $this->sessionId->account,$this->param->reason);
            }else{
                $r = $m_info
                    ->where([
                        'merchant_info_action.merchant_id'=> $merchant_id ,
                        'merchant_info_action.admin_op'=> $admin_op
                    ])
                    ->data([
                        'audit_status'=> $audit_status,
                        'audit_user'=> $this->sessionId->account,
                        'audit_reason'=>$this->param->reason,
                        'audit_ts'=> date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] )
                    ])
                    ->save();
            }
            if($r !== false){
//                $re = D('RegUser')->where(['merchant_id'=> $merchant_id])->field(['account'])->find();
                $re = D('RegUser')
                    ->join('merchant on merchant.merchant_id=reg_user.merchant_id')
                    ->where([
                        'reg_user.merchant_id'=> $merchant_id,
                    ])
                    ->field([
                        'reg_user.account',
                        'merchant.name as merchant_name',
                    ])
                    ->find();
                if(isset($re['account'])){
                    $this->send_merchantInfo_email($re['account'], $audit_status,  $this->param->reason, $re['merchant_name']);
                    // 记录信息
                    D('MerchantInfoLog')->updateByMerchantId($merchant_id,[
                        'audit_status'=> $audit_status,
                        'audit_user'=> $this->sessionId->account,
                        'audit_reason'=>$this->param->reason,
                        'audit_ts'=> date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] )
                    ]);
                    $m_info->commit();
                    $this->returnData['code'] = 200;
                    $this->returnData['message'] = 'success';
                }else{
                    $m_info->rollback();
                    $this->returnData['message'] = '未获取到用户邮箱';
                }
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        exit(json_encode($this->returnData));
    }
    /**
     * 发送liveKey激活结果邮件
     * @return bool
     */
    private function send_merchantInfo_email($account, $audit_status,  $reason, $merchant_name){
        $mail_config = ($audit_status == 2) ?
            D('SysConfig')->INFO_SUCCESS :
            D('SysConfig')->INFO_FAIL;
        if($mail_config['active'] != 1) return true;
        $subject = $mail_config['subject'];
        $content = str_replace("{#merchant_name}",$merchant_name,$mail_config['content']);
        $content = str_replace("{#reason}",$reason,$content);
        return $this->send_mail($account, $subject, $content);
    }

    /**
     * 比较2个livekey信息的区别, 返回数组
     */
    private function getChange($livekey, $livekey_new){
        $info = [
            'name' => '企业名称',
            'account' => '账户名',
            'contact_mail' => '联系人邮箱',
            'contact_mobile' => '联系人手机号码',
            'reg_address' => '企业注册地址',
            'work_address' => '企业办公地址',
            'lisence_image' => '企业营业执照副本',
            'org_image' => '组织机构代码',
            'contact_name' => '联系人姓名'
        ];
        $arr = [];
        foreach($livekey as $k => $v){
            if( key_exists($k, $info) && ($v != $livekey_new[$k])){
                $arr[] = [
                    'show_name' => $info[$k],
                    'old' => $v,
                    'new' => $livekey_new[$k]
                ];
            }
        }
        return $arr;
    }

    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
}