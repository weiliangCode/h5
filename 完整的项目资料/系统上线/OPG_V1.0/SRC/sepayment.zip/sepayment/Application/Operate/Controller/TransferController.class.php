<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class TransferController extends OperateController{
    static $transfer_url = '';
    static $status = [
        '处理中' => [1,2,4,6,7,9,10,12,13],
        '失败' => [3,5,8,11,14,16],
        '成功' => [15,17,18]
    ];
    // 查询条件数组
    private $search = array();
    // 排序标准
    private $order = 'transfer_request.created_ts desc';
    private $limit = '';
    // 应用支付渠道管理列表, 需要返回的字段
    private $key = [
        'transfer_request.transfer_no',
        'transfer_request.third_trade_no',
        'transfer_request.pay_account',
        'transfer_request.amount',
        'transfer_request.rec_account_no',
        'transfer_request.rec_account_name',
        'transfer_request.created_ts',
        'transfer_request.modified_ts',
        'transfer_request.subject',
        'transfer_request.status_id',
        'transfer_request.description',
        'transfer_request.batch_no',
        'merchant.name as merchant_name',
    ];
    public function __construct(){
        parent::__construct();
        if($_SERVER['HTTP_HOST'] == '172.19.5.55'){
            self::$transfer_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/Transfer';
        }elseif($_SERVER['HTTP_HOST'] == 'opgdev.weilian.cn'){
            self::$transfer_url = 'http://opgdev.weilian.cn/payment/Transfer';
        }elseif($_SERVER['HTTP_HOST'] == '172.16.30.13'){
            self::$transfer_url = 'http://172.16.30.13:9008/payment/Transfer';
        }else self::$transfer_url = 'http://172.19.6.115:82/payment/Transfer';
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
    }
    // 获取应用下的转账列表,支持分页,搜索
    //{"act":"2","method":"Transfer","op":"getList","data":{"merchant_app_id":"1","payment_type_id":"3"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getList($export =false){
        if( is_null($this->param->payment_type_id)){
            $this->returnData['message'] = '缺少必要参数 payment_type_id';
            exit(json_encode($this->returnData));
        }
        if($this->searchSql() && $this->pageSql() && $this->getData($export) ){
            if($export)  return $this->returnData['data']['list'];
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            exit(json_encode($this->returnData));
        }
    }
    // 查看转账详情
    // {"act":"2","method":"Transfer","op":"getInfo","data":{"transfer_no":"1609020000016975"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getInfo(){
        if(is_null($this->param->transfer_no)){
            $this->returnData['message'] = '缺少必要参数 transfer_no';
            exit(json_encode($this->returnData));
        }
//        $res = D('TransferRequest')->getPaymentInfoWithTransferNo($this->param->transfer_no);
        $rr = D('TransferRequest')
            ->join('merchant ON merchant.merchant_id=transfer_request.merchant_id')
            ->where(['transfer_no'=> $this->param->transfer_no])->find();
        $arr = [
            'transfer_no' => $rr['transfer_no'],
            'third_trade_no' => $rr['third_trade_no'],
            'pay_account' => $rr['pay_account'],
            'subject' => $rr['subject'],
            'batch_no' => $rr['batch_no'],
            'status_id' => $rr['status_id'],
            'description' => $rr['description'],
            'rec_account_no' => $rr['rec_account_no'],
            'rec_account_name' => $rr['rec_account_name'],
            'amount' => $rr['amount'],
            'created_ts' => $rr['created_ts'],
            'merchant_name' => $rr['name']
        ];
        $att[] = $arr;
        $this->makeArr($att);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $att[0];
        exit(json_encode($this->returnData));
    }
    // 获取可用的付款账户
    // {"act":"2","method":"Transfer","op":"getAccountWithPayment","data":{"merchant_app_id":"1","payment_type_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getAccountWithPayment(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->payment_type_id)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id || payment_type_id';
            exit(json_encode($this->returnData));
        }
        $arr = D('PaymentParameterDefine')->getScenaryAndName($this->param->merchant_app_id, $this->param->payment_type_id);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $arr;
        exit(json_encode($this->returnData));

    }
    // 订单到处到Excel
    public function exportExcel(){
        $data = $this->getList(true);
        // 汉化字段
        if(isset($data[0])){
            $arr = [
                'payment_type_name' => '支付渠道名称',
                'bill_id' => '订单ID',
                'transfer_no' => '转账流水号',
                'pay_request_id' => '翌支付内部ID',
                'created_ts' => '付款时间',
                'modified_ts' => '转账状态更改时间',
                'amount' => '转账金额',
                'description' => '备注',
//                'status_id' => '交易状态码',
//                'payment_type_id' => '支付渠道ID',
//                'se_payment_code' => '商户code',
                'third_trade_no' => '第三方流水号',
                'rec_account_no' => '收款人账号',
                'rec_account_name' => '收款人姓名',
                'status' => '交易状态',
                'enableRefund' => '可否退款(1可以,0不可以)',
                'note' => '不可退款原因',
                'name' => '企业名称',
                'subject'=> '付款主题',
                'batch_no' => '批量付款批次号',
                'pay_account' => '付款账号',
                'merchant_name' => '企业名称'
            ];
            foreach($data as $k => $v){
                $new = [];
                foreach($v as $k1=>$v1){
                    if(key_exists($k1, $arr)){
                        $new[$arr[$k1]] = $v1;
                    }
//                    else $new[$k1] = $v1;
                }
                $data2[] = $new;
            }
            $data = $data2;
        }
        return D('Operate/Excel')->exportExcel($data);
    }
    // 发起转账流程入口 : 表单数据接受
    // 需要同步请求
    //{"act":"2","method":"Transfer","op":"doTransfer","data":{"merchant_app_id":"1","payment_type_id":"1","scenary_id":"1","rec_account_no":"15549142684@163.com","rec_account_name":"徐腾","amount":"1.33"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function doTransfer(){
        if(is_null($this->param->merchant_app_id) ||
            is_null($this->param->payment_type_id) ||
                is_null($this->param->scenary_id) ||
                    is_null($this->param->rec_account_no) ||
                        is_null($this->param->amount) ||
                            is_null($this->param->rec_account_name)){
            $this->returnData['message'] = '缺少必要参数!';
            exit(json_encode($this->returnData));
        }
        // 支付渠道配置参数
        $paymentInfo = D('PaymentParameterDefine')->getPaymentList($this->param->payment_type_id,$this->param->scenary_id,$this->param->merchant_app_id);
        // 商户相关信息
        $merchantInfo = D('Merchant')->getMerchantInfoByAppId($this->param->merchant_app_id);
        $data = array_merge($paymentInfo, $merchantInfo);
        $data = array_merge((array)$this->param, $data);

        $this->transfer_request($data);
    }
    // 发起转账请求
    private function transfer_request($post){
        //1. 组装参数请求
        $params = [
            'app_code' => $post['app_code'],
            'se_payment_code' => $post['se_payment_code'],
//            'se_private_key' => $post['se_private_key'],
            'rec_account_no' => $post['rec_account_no'],
            'rec_account_name' => $post['rec_account_name'],
            'amount' => $post['amount'],
            'created_ts' => time(),
            'return_url' => '',
            'notify_url' => '',
            'payment_type_id' => $post['payment_type_id'],
            'scenary_id' => $post['scenary_id'],
            'subject'=> isset($post['subject']) ? $post['subject'] : '翌支付商户平台转账',
            'description'=> isset($post['description']) ? $post['description'] : '暂无'
        ];
        $params['se_sign'] = md5(md5($params['app_code'].$params['se_payment_code'].$params['rec_account_no'].$params['amount'].$params['created_ts']).$post['se_private_key']);

        $transfer_no = trim($this->curl(self::$transfer_url, $params));
//        var_dump($transfer_no);exit;
        //4. 重新封装转账号请求
        $params2 = [
            'transfer_no'=> $transfer_no,
            'se_payment_code'=> $post['se_payment_code'],
            'app_code'=> $post['app_code'],
            'created_ts' => time()
        ];
        $params2['payment_type_id'] = $post['payment_type_id'];
        $params2['se_sign'] = md5(md5($params2['app_code'].$params2['se_payment_code'].$params2['transfer_no'].$params2['created_ts']).$post['se_private_key']);
        header('Location:'.self::$transfer_url.'?'.http_build_query($params2));
        exit;
    }
    /**
     * 根据查询条件,
     * @return $this->search
     */
    private function searchSql(){
        $this->search['transfer_request.payment_type_id'] = $this->param->payment_type_id;
//        $this->search['transfer_request.auth_app_id'] = $this->param->merchant_app_id;
        //        $this->search['pay_request.merchant_id'] = $this->sessionId->merchant_id;
        if(!is_null($this->param->transfer_no))
            $this->search['transfer_request.transfer_no'] = $this->param->transfer_no;
        // Mysql中针对不定义精度的float类型进行等值查询
        if(!is_null($this->param->amount))
            $this->search['transfer_request.amount'] = ['like',trim($this->param->amount)];
        if(!is_null($this->param->pay_account))
            $this->search['transfer_request.pay_account'] = $this->param->pay_account;
        if(!is_null($this->param->merchant_name))
            $this->search['merchant.name'] = $this->param->merchant_name;
        if(!is_null($this->param->third_trade_no))
            $this->search['transfer_request.third_trade_no'] = $this->param->third_trade_no;
        if(!is_null($this->param->subject))
            $this->search['transfer_request.subject'] = ['like','%'.trim($this->param->subject).'%'];
        if(!is_null($this->param->status))
            $this->search['transfer_request.status_id'] = ['IN', self::$status[$this->param->status]];
        if(!is_null($this->param->rec_account_no))
            $this->search['transfer_request.rec_account_no'] = ['like','%'.trim($this->param->rec_account_no).'%'];
        if(!is_null($this->param->rec_account_name))
            $this->search['transfer_request.rec_account_name'] = ['like','%'.trim($this->param->rec_account_name).'%'];
        if(!is_null($this->param->created_ts_min))
            $this->search['transfer_request.created_ts'][] = array('EGT',$this->param->created_ts_min);
        if(!is_null($this->param->created_ts_max))
            $this->search['transfer_request.created_ts'][] = array('ELT',$this->param->created_ts_max);
        return true;
    }
    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
    /**
     * 数据操作
     * @return $this->returnData
     */
    private function getData($export){
        if($export) $this->limit = '';
        $obj = D('TransferRequest');
        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search);
        $temp = $obj->searchData($this->key, $this->search ,$this->order, $this->limit);
        $this->makeArr($temp);
        $this->returnData['data']['list'] = $temp;
        return true;
    }
    private function makeArr(&$arr){
        if(empty($arr)) return ;
        foreach($arr as $k =>$v){
            foreach(self::$status as $k2 => $v2){
                if(in_array($v['status_id'], $v2)){
                    $arr[$k]['status'] = $k2;
                    continue;
                }
            }
        }
    }
    //

    /**
     * curl请求提交模式
     *
     * @params string 提交地址
     * @params array 需要提交的参数
     *
     * @parmas string 提交方式 post/get
     *         提交到客户端都需要用 sign 签名字段
     */
    private function curl($url, $params = array(), $type = 'POST', $proxy = false){
        $is_ssl = false;
        $port = false;
        if(preg_match('/^(http|https):\/\/([\w\.]+)(:(\d+))?\//', $url, $m)){
            $is_ssl = true;
        }
        else{
            die('curl error['.$type.']: invalid url => '.$url);
        }
        $ch = curl_init();
        if($port){
            curl_setopt($ch, CURLOPT_PORT, $port);
        }
        //指定以非2进制(multipart/form-data)头部格式传送
        $this_header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);
        if(isset($_SERVER['HTTP_USER_AGENT'])){
            curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        }
        $opts = array(CURLOPT_TIMEOUT => 60, CURLOPT_RETURNTRANSFER => 1, //CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $this_header, CURLOPT_ENCODING => 'gzip,deflate',);
        if($is_ssl){
            $opts[ CURLOPT_SSL_VERIFYHOST ] = true;
            $opts[ CURLOPT_SSL_VERIFYPEER ] = false;
        }
        switch( $type ){
            case 'POST' :
                $opts[ CURLOPT_URL ] = $url;
                $opts[ CURLOPT_POST ] = 1;
                $opts[ CURLOPT_POSTFIELDS ] = http_build_query($params); // 貌似这类参数会报错: 'a=1&b=1';
                break;
            case 'GET':
                $get_params_str = '';
                if($params){
                    $get_params_str = '&';
                    if(strpos($url, '?') === false)
                        $get_params_str = '?';
                    $get_params_str = $get_params_str.http_build_query($params);
                }
                $opts[ CURLOPT_URL ] = $url.$get_params_str;
                break;
        }
        //curl请求
        curl_setopt_array($ch, $opts);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        curl_setopt($ch, CURLOPT_URL, $opts[ CURLOPT_URL ]);
        $output = curl_exec($ch);
        $error = curl_error($ch);
        if($error){
            die('curl error['.$type.']: '.$error.' | '.$opts[ CURLOPT_URL ]);
        }
        curl_close($ch);
        return $output;

    }

}
