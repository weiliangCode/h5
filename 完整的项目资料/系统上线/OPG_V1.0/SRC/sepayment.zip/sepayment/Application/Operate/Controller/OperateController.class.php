<?php
namespace Operate\Controller;
use Think\Controller;
/**
 * SunEEE

 * 象翌微链科技发展有限公司内部的PHP框架

 * Copyright (c) 2015 - 2016, SunEEE 技术

 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任

 * @package     suneee
 * @author      SunEEE PHP Team -> 组员名
 * @interface   接口名称
 * @describe    接口描述
 * @input       借口参数示例
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */

class OperateController extends Controller{
    protected $userTable = 'SysUser';

}