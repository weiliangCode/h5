<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->zhuoer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class SysConfigController extends OperateController{
    public function getList(){
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list']  = $this->makeArr(1);
        exit(json_encode($this->returnData));
    }
    public function getListMail(){
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list']  = $this->makeArr(2);
        exit(json_encode($this->returnData));
    }
    public function getListMessage(){
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list']  = $this->makeArr(3);
        exit(json_encode($this->returnData));
    }
    //{"act":"1","method":"SysConfig","op":"updateConfig","data":{"REFUNDDAY":"99","sessionId":"UzBCRGFoY1NVUk52VVZjTlUwZFJWVk1OUUYwU0R3SUZWUXBhRTBsWFJCWlBYUTFRVTFGVkJWTUxDZ1JiQTFFRENRTlhVUU1IVlFRSVZnTlRDd1pSWFFBS1ZSTVJGVlVWUlVzT0FVUU5YMUZaREdwSEZROVJVUWxWR1FVQkd3VlFFd2dGRUZFZ0FWQVZDM0lDVVE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
    public function updateConfig(){
        $data = (array)$this->param;
        unset($data['sessionId']);
        $obj = D('SysConfig');
        foreach($data as $k =>$v){
            $obj->{$k} = $v;
        }
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }
    private function makeArr($type){
        $arr = [];
        $re = D('SysConfig')->where(['type'=>$type])->select();
        foreach($re as $k => $v){
            $v['config_value'] = unserialize($v['config_value']) ?
                unserialize($v['config_value']) :
                $v['config_value'];
            $arr[$v['config_key']] = $v;
        }
        return $arr;
    }
}