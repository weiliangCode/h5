<?php
namespace Payment\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;

/**
 * SDK支付模拟接口控制器
 * 
 *
 * @author		SunEEE PHP Team(zhuoer)
 * @created		2016-06-22
 * @modified    2015-06-22
*/
class PaySdkController extends PaymentController {

        // 返回数据格式
    protected $returnData = array(
        'code' => '0',
        'message' => 'error',
        'data' => array(

        ));

    private $AliPay = array();
    private $WeChatPay = array();

    /**
     * 支付宝参数
     */	
    public $alipay_notify_url = 'http://opg.weilian.cn/opg/index.php/payment/paySdk/alipay_notify_url'; //支付宝异步回调地址

    const SERVICE = 'mobile.securitypay.pay';   //接口名称
    const PARTNER = '2088011335282401';   //合作者身份ID
    const CHARSET = 'utf-8';   //参数编码字符集
    const SIGN_TYPE = 'RSA';   //签名方式
    const PAYMENT_TYPE = '1';   //支付类型
    const SELLER_ID = 'marketing@suneee.com';   //卖家支付宝账号

    /**
     * 微信支付参数
     */ 
    // public $wechat_notify_url = 'http://opg.weilian.cn/opg/index.php/payment/paySdk/wechat_notify_url'; //微信异步回调地址
    public $wechat_notify_url = 'http://opg.weilian.cn/notify.php';
    protected $pre_order = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
    const APPID = 'wx6dd2a0e6fdab771e';   //应用ID 
    const MCHID = '1364076902';  //商户号  翌商城
    const KEY = 'd960efb0331e6aedf60d7262dcf4a7c3';//安全检验码，以数字和字母组成的32位字符

/*    const APPID = 'wxd55f0609cc3be290';   //应用ID
    const MCHID = '1233606102';  //商户号
    const KEY = 'lkjnhbgj3adf89283w93u3234w23deex';//安全检验码，以数字和字母组成的32位字符*/
    const TRADE_TYPE = 'APP'; //交易类型

    public function index()
    {
        // print_r($this->param);
        //支付号(随机)
        $rp_id = time();
        $pay_no = $this->get_idno($rp_id, $this->env_conf['pay_no_prefix']);
        
        $p = I('get.')?I('get.'):I('post.'); 

        $this->payment_type_id = $p['payment_type_id'];

        if(empty($this->payment_type_id))
        {
            $list = array(array("payment_type_id"=>"1","name"=>"支付宝"),array("payment_type_id"=>"2","name"=>"微信支付"));

            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';   
            $this->returnData['data'] = $list;

            echo json_encode($this->returnData);
        }
        else
        {
            switch ($this->payment_type_id) {
                case 1:
                    $paras['partner'] =  '"'.self::PARTNER.'"';
                    $paras['seller_id'] = '"'.self::SELLER_ID.'"';
                    $paras['out_trade_no'] = '"'.$pay_no.'"';
                    $paras['subject'] = '"'.'测试的商品'.'"';
                    $paras['body'] = '"'.'该测试商品的详细描述'.'"';
                    $paras['total_fee'] = '"'.'0.01'.'"';
                    $paras['notify_url'] = '"'.$this->alipay_notify_url.'"';
                    $paras['service'] =  '"'.self::SERVICE.'"';
                    $paras['payment_type'] = '"'.self::PAYMENT_TYPE.'"';
                    $paras['_input_charset'] = '"'.self::CHARSET.'"';     

                    $third_lib_path = APP_PATH.MODULE_NAME.'/Lib/sdk/AliPay/lib/';
                    require_once($third_lib_path."alipay_core.function.php");
                    require_once($third_lib_path."alipay_rsa.function.php");

                    //除去待签名参数数组中的空值和签名参数            
                    //$para_filter = paraFilter($this->AliPay);
                    //对待签名参数数组排序
                    //$para_sort = argSort($para_filter);
                    //把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
                    $prestr = createLinkstring($paras);

                    //RSA加密
                     $mysign = rsaSign($prestr, dirname(dirname(__FILE__)).'/Lib/sdk/AliPay/key/rsa_private_key.pem');

                    $this->AliPay['service'] =  self::SERVICE;
                    $this->AliPay['partner'] =  self::PARTNER;
                    $this->AliPay['_input_charset'] = self::CHARSET;
                    $this->AliPay['notify_url'] = $this->alipay_notify_url;
                    $this->AliPay['out_trade_no'] = $pay_no;
                    $this->AliPay['subject'] = '商品名称测试';
                    $this->AliPay['payment_type'] = self::PAYMENT_TYPE;
                    $this->AliPay['seller_id'] = self::SELLER_ID;
                    $this->AliPay['total_fee'] = '0.01';
                    //签名结果与签名方式加入请求提交参数组中    
                    $this->AliPay['sign'] = urlencode($mysign);
                    $this->AliPay['sign_type'] = self::SIGN_TYPE;
                    $this->AliPay['body'] = '商品详情测试';

                    $this->returnData['code'] = 200;
                    $this->returnData['message'] = 'success';   
                    $this->returnData['data'] = $this->AliPay;

                    echo json_encode($this->returnData);

                    break;

                case 2:
                    $data['appid'] = self::APPID;
                    $data['mch_id'] = self::MCHID;
                    $data['nonce_str'] = $this->createNoncestr();//随机字符串
                    $data['body'] = '商品描述测试';
                    $data['out_trade_no'] = $pay_no;
                    $data['total_fee'] = '1';
                    $data['spbill_create_ip'] = $_SERVER['REMOTE_ADDR'];//终端ip   
                    $data['notify_url'] = $this->wechat_notify_url;
                    $data['trade_type'] = self::TRADE_TYPE;
                    $data['sign'] = $this->getSign($data);

                    $xml = $this->arrayToXml($data);

                    $response = $this->postXmlCurl($xml,$this->pre_order,30);

                    $this->WeChatPay['appid'] = self::APPID;
                    $this->WeChatPay['partnerid'] = self::MCHID;
                    $this->WeChatPay['prepayid'] = $this->xmlToArray($response)["prepay_id"];//随机字符串
                    $this->WeChatPay['package'] = 'Sign=WXPay';
                    $this->WeChatPay['noncestr'] = $this->createNoncestr();
                    $this->WeChatPay['timestamp'] = time();
                    $this->WeChatPay['sign'] = $this->getSign($this->WeChatPay);

                    unset($this->WeChatPay['package']);
                    $this->WeChatPay['package_value'] = 'Sign=WXPay';
          
                    $this->returnData['code'] = 200;
                    $this->returnData['message'] = 'success';   
                    $this->returnData['data'] = $this->WeChatPay;

                    echo json_encode($this->returnData);
                    break;                

                default:
                    $this->returnData['code'] = 201;
                    $this->returnData['message'] = '暂不支持该支付方式';   

                    echo json_encode($this->returnData);
                    break;
            }
        }
    }
     /**
     *  微信支付对账单接口
     */   
    public function check_account()
    {
        $url = "https://api.mch.weixin.qq.com/pay/downloadbill";
        //请求参数
        $data['appid'] = self::APPID;
        $data['mch_id'] = self::MCHID;
        $data['nonce_str'] = $this->createNoncestr();//随机字符串
        // $data['bill_date'] = date('Ymd',time());//对账单日期
        $data['bill_date'] = '20160827';//对账单日期
        $data['bill_type'] = 'ALL';   
        $data['sign'] = $this->getSign($data);

        $xml = $this->arrayToXml($data);   

         $str = $this->postXmlCurl($xml,$url,30);

/*        $myfile = fopen("account.txt", "a+") or die("Unable to open file!");
        fwrite($myfile, $str);
        fclose($myfile);
        exit;*/

$makeStringToArray = function($str){
            $arr = explode("\r\n",trim($str));
            array_pop($arr);
            array_pop($arr);
            $title = explode(',',$arr[0]);
            unset($arr[0]);
            $content = array_values($arr);
            $c = [];
            foreach($content as $k=>$v){
                $v = trim($v,'`');
                $a = explode(',`',$v);
                $i = 0;
                $new = [];
                foreach($a as $k1=>$v1){
                    $new[$title[$i]] = $v1;

                    $i++;
                }
                $c[] = $new;
            }
            return $c;
        };
         D('Operate/Excel')->exportExcel($makeStringToArray($str));
/*        $res = $this->makeStringToArray($response);
        print_r($res);*/
        // echo $response;
        exit;

    } 
    public function makeStringToArray($str)
    {
        $b = explode(' `',$str);
        $a = $b[0];
        $a = explode(',',$a);
        $vvv1 = $b[count($b)-2];
        $vvv2 = explode(' ',$vvv1);
        $vvv = trim(str_replace($vvv2[count($vvv2)-1],'',$vvv1));
        $b[count($b)-2] = $vvv;
        unset($b[count($b)-1]);
        unset($b[0]);
        $rr = [];
        foreach($b as $k=>$v){
            $arr= explode(',`',$v);
            $i = 0;
            $new = [];
            foreach($arr as $k1=>$v1){
                $new[$a[$i]] = $v1;
                $i++;
            }
            $rr[] = $new;
        }
        return $rr;
    }

 public function indexDo(){
        $str = "交易时间,公众账号ID,商户号,子商户号,设备号,微信订单号,商户订单号,用户标识,交易类型,交易状态,付款银行,货币种类,总金额,企业红包金额,微信退款单号,商户退款单号,退款金额,企业红包退款金额,退款类型,退款状态,商品名称,商户数据包,手续费,费率 `2016-08-27 10:43:07,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272351374939,`P160827000209837,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`NATIVE,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% `2016-08-27 11:15:40,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272353121149,`P160827001000561,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`NATIVE,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% `2016-08-27 15:46:27,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272374271626,`P160827001000562,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`JSAPI,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% `2016-08-27 15:56:47,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272376641031,`P160827001000565,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`JSAPI,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% `2016-08-27 16:22:23,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272377593073,`P160827001000566,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`NATIVE,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% `2016-08-27 17:09:03,`wxd55f0609cc3be290,`1233606102,`0,`,`4008222001201608272381325333,`P160827000209841,`oViF2uNm7QUSnyCsBNpjt4f8t4p0,`JSAPI,`SUCCESS,`CFT,`CNY,`0.01,`0.00,`0,`0,`0,`0,`,`,`测试订单支付1,`,`0.00000,`2.00% 总交易单数,总交易额,总退款金额,总企业红包退款金额,手续费总金额 `6,`0.06,`0.00,`0.00,`0.00000";
echo $str; echo '<br><br>';      
$b = explode(' `',$str);
var_dump($b);exit;        
//        echo $str;
        $makeStringToArray = function($str){
            $b = explode(' `',$str);
            $a = $b[0];
            $a = explode(',',$a);
            $vvv1 = $b[count($b)-2];
            $vvv2 = explode(' ',$vvv1);
            $vvv = trim(str_replace($vvv2[count($vvv2)-1],'',$vvv1));
            $b[count($b)-2] = $vvv;
            unset($b[count($b)-1]);
            unset($b[0]);
            $rr = [];
            foreach($b as $k=>$v){
                $arr= explode(',`',$v);
                $i = 0;
                $new = [];
                foreach($arr as $k1=>$v1){
                    $new[$a[$i]] = $v1;
                    $i++;
                }
                $rr[] = $new;
            }
            return $rr;
        };
        // echo '<pre>';var_dump($makeStringToArray($str));
    D('Operate/Excel')->exportExcel($makeStringToArray($str));

    }

     /**
     *  支付宝异步回调
     */   
    public function alipay_notify_url()
    {
        $third_lib_path = APP_PATH.MODULE_NAME.'/Lib/sdk/AliPay/';
        require_once($third_lib_path."alipay.config.php");
        require_once($third_lib_path."lib/alipay_notify.class.php");

        $alipayNotify = new \AlipayNotify($alipay_config);
        $verify_result = $alipayNotify->verifyNotify();

        if($verify_result) {
            //商户订单号
            $out_trade_no = $_POST['out_trade_no'];
            //支付宝交易号
            $trade_no = $_POST['trade_no'];
            //交易状态
            $trade_status = $_POST['trade_status'];


            if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {

                $log_text = $_POST;
                logResult(json_encode($log_text));
            }
                
            echo "success";     //请不要修改或删除
        }
        else {
            echo "fail";
        }        

    }

     /**
     *  微信异步回调
     */   
    public function wechat_notify_url()
    {
       

    }    

    /**
     *  作用：格式化参数，签名过程需要使用
     */
    function formatBizQueryParaMap($paraMap, $urlencode)
    {
        $buff = "";
        ksort($paraMap);
        foreach ($paraMap as $k => $v)
        {
            if($urlencode)
            {
               $v = urlencode($v);
            }
            //$buff .= strtolower($k) . "=" . $v . "&";
            $buff .= $k . "=" . $v . "&";
        }
        $reqPar;
        if (strlen($buff) > 0) 
        {
            $reqPar = substr($buff, 0, strlen($buff)-1);
        }
        return $reqPar;
    }
    /**
     *  作用：产生随机字符串，不长于32位
     */
    public function createNoncestr( $length = 32 ) 
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
        $str ="";
        for ( $i = 0; $i < $length; $i++ )  {  
            $str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
        }  
        return $str;
    }
    /**
     *  作用：生成签名
     */
    public function getSign($Obj)
    {
        foreach ($Obj as $k => $v)
        {
            $Parameters[$k] = $v;
        }
        //签名步骤一：按字典序排序参数
        ksort($Parameters);
        $String = $this->formatBizQueryParaMap($Parameters, false);
        // echo '【string1】'.$String.'</br>';
        //签名步骤二：在string后加入KEY
        $String = $String."&key=".self::KEY;
        // echo "【string2】".$String."</br>";
        //签名步骤三：MD5加密
        $String = md5($String);
        // echo "【string3】 ".$String."</br>";
        //签名步骤四：所有字符转为大写
        $result_ = strtoupper($String);
        // echo "【result】 ".$result_."</br>";
        return $result_;
    }   
    /**
     *  作用：array转xml
     */
    public function arrayToXml($arr)
    {
        $xml = "<xml>";
        foreach ($arr as $key=>$val)
        {
             if (is_numeric($val))
             {
                $xml.="<".$key.">".$val."</".$key.">"; 

             }
             else
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
        }
        $xml.="</xml>";
        return $xml; 
    }
    /**
     *  作用：以post方式提交xml到对应的接口url
     */
    public function postXmlCurl($xml,$url,$second=30)
    {       
        //初始化curl        
        $ch = curl_init();
        //设置超时
        curl_setopt ( $ch, CURLOPT_TIMEOUT, $second );
        //这里设置代理，如果有的话
        //curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
        //curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
        //设置header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        //要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        //post提交方式
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        //运行curl
        $data = curl_exec($ch);
        
        //返回结果
        if($data)
        {
            curl_close ( $ch );
            return $data;
        }
        else 
        { 
            $error = curl_errno($ch);
            echo "curl出错，错误码:$error"."<br>"; 
            echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
            curl_close($ch);
            return false;
        }
    }  
    /**
     *  作用：将xml转为array
     */
    public function xmlToArray($xml)
    {       
        //将XML转为array        
        $array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);      
        return $array_data;
    }


/*=============================对账单===============================*/
    /**
     * 生成签名
     * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
     */
    public function MakeSign($Obj)
    {
        //签名步骤一：按字典序排序参数
        ksort($Obj);
        $string = $this->ToUrlParams($Obj);
        //签名步骤二：在string后加入KEY
        $string = $string . "&key=".self::KEY;
        //签名步骤三：MD5加密
        $string = md5($string);
        //签名步骤四：所有字符转为大写
        $result = strtoupper($string);
        return $result;
    }
    /**
     * 格式化参数格式化成url参数
     */
    public function ToUrlParams($Obj)
    {
        $buff = "";
        foreach ($Obj as $k => $v)
        {
            if($k != "sign" && $v != "" && !is_array($v)){
                $buff .= $k . "=" . $v . "&";
            }
        }
        
        $buff = trim($buff, "&");
        return $buff;
    }

}