<?php
namespace Payment\Controller;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;
use Think\Log;
/**
 * 中金支付发送验证码控制器
 *
 * 这是中金支付发送验证码的入口
 *
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
 */
class SendController extends PaymentController {
	
	public $datas;

	/**
	 * 构造类
	 */
	public function __construct($list)
	{

		$this->datas = $list;

		parent::__construct();
	}

	/**
	 * 中金支付发送验证码的入口
	 *
	 * a. 商户站点中金支付发送验证码请求的入口
	 * b. 请求到第三方中金支付发送验证码接口
	 */
	public function index()
	{ 
		//1. 检查参数合法性, 验证通过才入库

		$this->check_params();
       
		//2.1 如果是第一次请求应该创建支付请求并返回支付请求号
		if(!$this->pay_no)
		{
			if($this->has_err())
			{
				$this->errlog('verify params failed for first pay request');
			}
		
			//3. 记录一条新支付请求记录
			$this->create_send_request();
		
			//4. 返回支付号, 中断程序
			if(!empty($this->pay_no))
			{
				echo $this->pay_no;
				exit;
			}
			else
			{
				$this->errlog('create pay request failed');
			}
		
			//3. 这里不做参数验证入库, 更新状态为  11, 12  请求验证成功, 请求验证失败
			//$r = $this->update_status('PayRequest', $this->pay_no, 11, 12);
		}
		//2.2 如果是有支付号的请求(第二次)直接进入支付通道选择页面
		else
		{ 
			//3. 更新状态为  13, 14  //支付号请求验证成功, 支付号请求验证失败
			    $this->update_status('PayRequest', $this->pay_no, 13, 14);
				
			   return $this->send_api();
		}
		
		exit;
		
		
	}

	/**
	 * 检查参数
	 */
	protected function check_params($data)
	{
	
	    	//得到需检查的参数
		$p = $this->datas;

		//得到支付的配置
		$conf = C('pay');
		
		//定义配置
		$pconf = '';
		$merchant_info = '';

    	//验证第一次请求(检查没有包含支付号的请求)
    	if(!isset($p['pay_no']))
    	{
    		$p = I('post.');
    		
    		//得到返回url,供返回使用
    		$this->return_url = $p['return_url'];
    		//添加支付方式
    		$this->payment_type_id = $p['payment_type_id'];
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payresult'];

			//验证参数的合法性
			$r = $this->verify_all_params($p, $pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错
				return FALSE;
			}

			//验证授权号
			$m_mer = D('Merchant');

			$merchant_info = $m_mer->get_by_payment_code($p['se_payment_code']);

			if(!isset($merchant_info['se_payment_code']) || !isset($merchant_info['se_payment_key'])
			  || empty($merchant_info['se_payment_code']) || $merchant_info['se_payment_code']!=$p['se_payment_code']
			)
			{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code: ' . $p['se_payment_code']);
				return FALSE;

			}

			//验证签名
			$se_sign = $this->build_sign($p, $pconf, $merchant_info['se_payment_key']);
	    	if(!$se_sign || $p['se_sign'] != $se_sign)
	    	{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_SIGN', 'this is invalid sign: ' . $p['se_sign']);
	    		return FALSE;
	    	}
	    	
    	}

    	else
    	//验证第二次请求(检查包含支付号的请求)
		{
			//赋值交易号给当前类
			$this->pay_no = $p['pay_no'];
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payno'];
    		//$p['se_payment_code'] = '870e856360391980a51958b91f12cb3d';

			//验证参数的合法性
			$r = $this->verify_all_params($p, $pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错
				return FALSE;
			}

			//验证授权号
			$m_mer = D('Merchant');
			$send_data = $m_mer->get_merchant_pay_data_by_pay_no($p['pay_no']);
			$send_data['institution_number'] = $p['institution_number'];//提交中金支付必须数据（秉谦）
			$send_data['binding_number'] = $p['binding_number'];//提交中金支付必须数据（秉谦）
			//得到返回url,供返回使用
    		$this->return_url = isset($send_data['return_url']) ? $send_data['return_url'] : '';

			if(!isset($send_data['se_payment_code']) || !isset($send_data['se_payment_key'])
			  || empty($send_data['se_payment_code'])
			) 
			{
				//如果验证不合法则输入错误状态并报错 
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $p['se_payment_code'] . '(' . $this->pay_no . ')');
				return FALSE;
			}

			//验证签名
			$p['se_payment_code'] = $send_data['se_payment_code'];
			$se_sign = $this->build_sign($p, $pconf, $send_data['se_payment_key']);
	    	if(!$se_sign || $p['se_sign'] != $se_sign)
	    	{
				$this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $p['se_sign'] . '(' . $this->pay_no . ')');
	    		return FALSE;
	    	}

			//赋值退款数据
			$this->send_data = $send_data;
		}

    	return TRUE;
			
	}

	
	/**
	 * 直接选择支付方式支付(接口)
	 */
	public function send_api()
	{
		$p = I('get.')?I('get.'):I('post.');
		
		//判断获取支付方式是否存在
		$m_pay_type = D('PaymentType');
		$this->payment_type_id='5';
		$payment_type = $m_pay_type->get_data_by_id($this->payment_type_id);
	
		if(!$payment_type)
		{
			$this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $payment_type);
			return FALSE;
		}
		$this->payment_type = $payment_type;
	
		//1.生成流水号
		if($this->has_err())
		{
			$this->errlog('verify params failed for first send request');
		}
	

		//2.封装实际支付参数，发起所选择的支付方式支付请求
		if(!empty($this->pay_no))
		{
			$pay_no = $this->pay_no;
	
			//验证授权号
			$m_mer = D('Merchant');
			$send_data = $m_mer->get_merchant_pay_data_by_pay_no($pay_no,$this->payment_type_id);
			$send_data['institution_number'] = $p['institution_number'];//提交中金支付必须数据（秉谦）
			$send_data['binding_number'] = $p['binding_number'];//提交中金支付必须数据（秉谦）
			//得到返回url,供返回使用
			$this->return_url = isset($send_data['return_url']) ? $send_data['return_url'] : '';
	
			//如果没有账号则报错
			if(empty($send_data['merchant_account_id']) || empty($send_data['se_payment_key']) || empty($send_data['se_payment_code']))
			{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $send_data['se_payment_code'] . '(' . $this->pay_no . ')');
				return FALSE;
			}
	
			$this->send_data = $send_data;	//得到商家信息
				
			//更新状态为  13, 14
			$d['merchant_account_id'] = $this->send_data['merchant_account_id'];
			$r = $this->update_status('PayRequest', $this->pay_no, 13, 14, $d);
	
			if(!$r || $this->has_err())
			{
				$this->errlog('verify params failed for second send request');
			}
	
			//发起第三方请求
			return $this->request_third_send();
	
			exit;
		}else{
			$this->errlog('create send request failed');
		}
	
	}

	//---------------------------------------------------------------------------------------------------------------------------//
	//------------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 ------------------------------------------//
	//---------------------------------------------------------------------------------------------------------------------------//

	/**
	 * 请求第三方验证
	 *
	 * @return void
	 */
	public function request_third_send()
	{
		//1. 检查是否是wap/web请求
		$data['client_type'] = is_mobile()===TRUE ? 'wap' : 'web';
		
		//2. 实例化一个支付类并进行支付且得到结果状态
		$data['payment_type'] = $this->payment_type;
		$data['send_data'] = $this->send_data; 
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/';
		
		//2.1 组合账户数据目录
		if(!isset($data['send_data']['account_mer_id']) || empty($data['send_data']['account_mer_id']))
		{
			$this->set_status('EMPTY_PARAMS', 'this is empty account_mer_id for request third send: ' . json_encode($data['send_data']));
			$this->errlog();
			return FALSE;
		}
		$data['merchant_data_path'] = MER_DATA_PATH.$data['send_data']['account_mer_id'].'/'.$data['payment_type']['code'].'/';
		//2.2 组合账户数据的客户端目录
		$data['merchant_data_ctype_path'] = $data['merchant_data_path'].$data['client_type'].'/';
		
		//2.3 载入第三方支付类
		$cls = load_pm_lib('payment/'.$this->payment_type['code'].'/'.$data['client_type'].'/'.$this->payment_type['code'], FALSE, $data);
		
		$result = $cls->send();
		
	    return $result;
	}

	
	protected function create_send_request()
	{
		//创建第一条支付记录
		$p = I('post.');
	
		//筛选业务参数入库
		$d = array();
		$datetime = date('Y-m-d H:i:s');
	
		//初始状态模型类
		$m_status = D('Status');
	
		$d['pay_request_id'] = '';
		$d['pay_no'] = '';
		// $d['payment_type_id'] = '';
		$d['payment_type_id'] = (isset($p['payment_type_id']) && !empty($p['payment_type_id'])) ? $p['payment_type_id'] : '';
		$d['bill_id'] = isset($p['bill_id']) ? $p['bill_id'] : '';
		$d['bill_type_id'] = (isset($p['bill_type_id']) && !empty($p['se_payment_code'])) ? $p['bill_type_id'] : '';
		$d['se_payment_code'] = (isset($p['se_payment_code']) && !empty($p['se_payment_code'])) ? $p['se_payment_code'] : '';
		$d['subject'] = (isset($p['subject']) && !empty($p['subject'])) ? $p['subject'] : '系统默认商户支付';
		$d['description'] = (isset($p['description']) && !empty($p['description'])) ? $p['description'] : '';
		//$d['third_trade_no'] = ''; //第三方交易号, 提交支付类型时更新
		$d['amount'] = (isset($p['amount']) && !empty($p['amount'])) ? $p['amount'] : '';
		$d['return_url'] = (isset($p['return_url']) && !empty($p['return_url'])) ? $p['return_url'] : '';
		$d['notify_url'] = (isset($p['notify_url']) && !empty($p['notify_url'])) ? $p['notify_url'] : '';
		$d['show_url'] = (isset($p['show_url']) && !empty($p['show_url'])) ? $p['show_url'] : '';
		$d['status_id'] = $m_status->get_status_id('10');	//初始状态 10
		//$d['merchant_id'] = '';	//商户ID, 后面更新
		//$d['merchant_account_id'] = ''; //商户账号ID,  后面更新
		$d['currency_code'] = (isset($p['currency_code']) && !empty($p['notify_url'])) ? $p['currency_code'] : 'CNY';
		$d['created_ts'] = $datetime;
		$d['modified_ts'] = $datetime;
		$d['pay_client'] = is_mobile()===TRUE ? 'wap' : 'web';//添加支付设备
	
		//--这里不启动事务处理,因为状态流水和状态如果不对应就表示异常
		//保存支付请求
		$pr_m = D('PayRequest');
	
		//如果该状态存在则不参数数据更新
		$r = $pr_m->save_data($d);
	
		//新增状态流水表
		if($r)
		{
			//流水号状态表保存(组合支付前缀字符串)
			$rp_id = $pr_m->getLastInsID();	//取到当前自增ID值
	
			//组装pay_no
			$pay_no = $this->get_idno($rp_id, $this->env_conf['pay_no_prefix']);
	
			if(is_int($rp_id))
			{
				//更新本表pay_no
				$d1 = array();
				$d1['pay_request_id'] = $rp_id;
				$d1['pay_no'] = $pay_no;
				$d1['status_id'] = $m_status->get_status_id('10'); //默认正确状态
				$m_mer = D('Merchant');
				$merchant_info = $m_mer->get_by_payment_code($d['se_payment_code']);
	
				//判断当前是否处于错误状态,如果有错误状态则返回
				//更新商家信息记录
				if($merchant_info)
				{
					$d1['merchant_id'] = $merchant_info['merchant_id'];
				}
				else
				{
					//如果找不到商家,则报错
					$this->set_status('INVALID_MERCHANT', 'can\'t found merchant data by se_payment_code:' . $d['se_payment_code']);
					$this->errlog('empty merchant info by se_payment_code: ' . $d['se_payment_code']);	//状态12 账号验证失败
					return FALSE;
				}
				//保存创建的商家记录
				$r = $pr_m->save_data($d1);
	
				if(!$r)
				{
					$this->set_status('CREATE_PAY_REQUEST_FAILED', 'create pay request failed for se_payment_code: ' . $d['se_payment_code']);
					$this->errlog('there is system error for create pay request failed for se_payment_code: ' . $d['se_payment_code']);	//状态12 账号验证失败
					return FALSE;
				}
	
				//插入流水状态表记录
				$d2 = array();
				$d2['pay_request_id'] = $rp_id;
				$d2['status_id'] = $d1['status_id'];	//和支付请求记录一致
				$d2['created_ts'] = date('Y-m-d H:i:s');
				$prf_m = D('PayRequestFlow');
				$r = $prf_m->save_data($d2);
	
				//只有流水状态表插入成功,才能获取支付号
				if($r)
				{
					$this->pay_no = $pay_no;
				}
				//else
				//{
				//这里的异常,不做处理,因为不影响整个流程.只是状态流水没有10的记录.
				//}
	
				return $r;
			}
		}
		return FALSE;
	}
	

	/**
	 * 得到类型,用来给模板区分具体的动作
	 */
	public function get_type()
	{
		return 'send';
	}

}