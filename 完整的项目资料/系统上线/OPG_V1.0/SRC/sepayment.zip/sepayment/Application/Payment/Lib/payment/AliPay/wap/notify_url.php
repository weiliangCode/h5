<?php
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

/**
 * 
 * 用来返回支付宝回调方法
 *
 * @author		SunEEE PHP Team(zhuoer)
 * @created		2015-09-06
 * @modified    2015-09-06
*/
require_once("lib/alipay_submit.class.php");
require_once("lib/alipay_notify.class.php");
class notify_url {
	
	private $data = "";

	public function __construct($data)
	{
		$this->data = $data;
		//获取配置信息
		$this->alipay_config = $this->config($this->data['merchant_payment_info']);			
	}

	/**
	 * 检查回调参数
	 */
	public function check_params()
	{		
 		$alipayNotify = new AlipayNotify($this->alipay_config);
		$verify_result = $alipayNotify->verifyNotify();
		if($verify_result) {//验证成功
			$out_trade_no = $_POST['out_trade_no'];//商户订单号		
			$trade_no = $_POST['trade_no'];//支付宝交易号	
			$trade_status = $_POST['trade_status'];//交易状态
		    if($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
				//判断该笔订单是否在商户网站中已经做过处理
				//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
				//如果有做过处理，不执行商户的业务程序
		    	echo "success";		//请不要修改或删除
		    	//third_status: 第三方支付平台状态值, status: SE支付网关状态值
		    	return array("third_status" => $trade_status, "pay_no" => $out_trade_no, "third_trade_no" => $trade_no, "status"=>'SUCCESS');
		    }
		    return array("third_status" => $trade_status, "pay_no" => $out_trade_no, "status"=>'EXCEPTION');
		}else {		
	    //验证失败
	    echo "fail";
	    //如要调试，请看alipay_notify.php页面的verifyReturn函数
	    	return array("third_status" => $_POST['trade_status'], "pay_no" => $_GET['out_trade_no'], "status"=>'FAILED');
	 	}
	}
	
	/**
	 * 检查回调参数
	 */
	 public function notify_result(){
	 	return ;
	 }


	/**
	 * 回调商户的同步回调return_url
	 */
	 public function callback($data){	 	
	 	$pay_data = $data['pay_data'];
    	$params = array(
    		'se_payment_code' => $pay_data['se_payment_code'],
			'pay_no'=> $pay_data['pay_no'], 
			'created_ts' => time(),
			// 'result' => $_GET['trade_status']
		);
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['created_ts']).$pay_data['se_payment_key']);
		//5. 从$params参数数组中移除不需要的商家授权号参数
		unset($params['se_payment_code']);

    	header('Location:'.$pay_data['notify_url'].'?'.http_build_query($params));

    	exit;	
	 }	 

    protected function config($merchant_payment_info)
    {
        $alipay_config = array();
		//合作身份者id，以2088开头的16位纯数字
        $alipay_config['partner'] = trim($merchant_payment_info['alipay_partner']);
        //收款支付宝账号
        $alipay_config['seller_id']	= trim($merchant_payment_info['alipay_partner']);
		//安全检验码，以数字和字母组成的32位字符
		//如果签名方式设置为“MD5”时，请设置该参数
		$alipay_config['key']	=  trim($merchant_payment_info['key']);
		//商户的私钥（后缀是.pen）文件相对路径
		$alipay_config['private_key_path']	= 'key/rsa_private_key.pem';
		//支付宝公钥（后缀是.pen）文件相对路径
		$alipay_config['ali_public_key_path']= 'key/alipay_public_key.pem';
        //签名方式 不需修改
        $alipay_config['sign_type']    = 'MD5';
        //字符编码格式 目前支持 gbk 或 utf-8
        $alipay_config['input_charset'] = strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = 'cacert.pem'; //getcwd().'\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';

        return $alipay_config;
    }	 	    
}