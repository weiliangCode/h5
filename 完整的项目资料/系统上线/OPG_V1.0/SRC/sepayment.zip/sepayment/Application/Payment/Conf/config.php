<?php
/**
 * 支付配置文件
 * 
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/


return array(
	//业务缓存生成时间配置redis （秒）
	'cache_expire'=>'30',
	//---------------------------------------------------------------------------------------------------//
	//------------------------------------------- 支付配置     ------------------------------------------------//
	//---------------------------------------------------------------------------------------------------// 
    //支付号前缀
    'pay_no_prefix' => 'P',
    //退款号前缀
    'refund_no_prefix' => 'R',
    //转账号前缀
    'transfer_no_prefix' => 'T', 
	//支付配置
	'pay' => array(
		//异步通知url (给到第三方支付平台)	
		//'notify_url' => '/pay/return_url/payment_type/?/client_type/?',
	
		//同步通知url (给到第三方支付平台)
		//'return_url' => '/pay/return_url/payment_type/?/client_type/?',
		
		//---------------------------------//
		//商户对se的支付请求, 参数列表  (0:不必填,有值则校验, 1:必填需签名, 2:无论如何不参与校验,可以参与签名) 签名的顺序一定要排好
		//创建流水
		'merchat_to_se_payresult' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),   //应用编码
			'se_payment_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>32),  //商户号
			'bill_id' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,32'),   //订单号
			'bill_type_id' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,32'),   //订单类型
			'subject' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,256', 'default'=>'SE商城支付'),  
			'description' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'),  
			'amount' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'float', 'size'=>'0.01,1000000000.00'),
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),  
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),  	//签名字段必填,不需进行参与签名
			'return_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //同步回调
			'notify_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //异步回调
		
		),
		
		//商户得到支付号的支付请求, 参数列表
		//获取交易号
		'merchat_to_se_payno' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'pay_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'),  
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32)
		),
		
		//商户支付类型请求, 参数列表
		//发起支付
		'merchat_to_se_pay' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'pay_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'),
			'payment_type_id' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,16'),  
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32)
		),
				
				
	),

	//---------------------------------------------------------------------------------------------------//
	//------------------------------------------- 退款配置  -------------------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	
	//退款配置
	'refund' => array(
		//异步通知url (给到第三方支付平台)	
		//'notify_url' => '/refund/return_url/payment_type/?/client_type/?',
	
		//同步通知url (给到第三方支付平台)
		//'return_url' => '/refund/return_url/payment_type/?/client_type/?',
		
		//---------------------------------//
		//请求响应给商户站点 签名规则 (该规则以2维数组为组合, 比如有2组, 第一组是按字段 合并起来, md5 加密一次,  再和后面一组进行累加 md5加密. 依次类推如果有多组进行多组组合md5加密)
		
		//---------------------------------//
		//商户对se的退款请求, 参数列表  (0:不必填,有值则校验, 1:必填需签名, 2:无论如何不参与校验, 可以参与签名) 签名的顺序一定要排好
		'merchat_to_se_payresult' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'pay_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'), 
			'subject' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,32', 'default'=>'SE商城支付'),  
			'description' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'),
			'amount' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'float', 'size'=>'0.01,10000.00'),	
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),  	//签名字段必填,不需进行参与签名
			'return_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //同步回调
			'notify_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //异步回调
		),
		
		//商户得到退款号的退款请求 
		'merchat_to_se_payno' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'refund_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'),  
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),
		),
	),	

	//---------------------------------------------------------------------------------------------------//
	//------------------------------------------- 转账配置  -------------------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	'transfer' => array(
		//商户对se的支付请求, 参数列表  (0:不必填,有值则校验, 1:必填需签名, 2:无论如何不参与校验,可以参与签名) 签名的顺序一定要排好
		'merchat_to_se_payresult' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>32),  
			'rec_account_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,32'),  
			'subject' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,32', 'default'=>'SE商城支付'),  
			'description' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'),  
			'amount' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'float', 'size'=>'0.01,10000.00'),
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),  
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),  	//签名字段必填,不需进行参与签名
			'return_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //同步回调
			'notify_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //异步回调
		
		),
		
		//商户得到支付号的支付请求, 参数列表 
		'merchat_to_se_payno' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'transfer_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'),  
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32)
		),
		
		//商户支付类型请求, 参数列表 
		'merchat_to_se_pay' => array(
			'app_code' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>14),
			'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32), 
			'transfer_no' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'16,32'),
			'payment_type_id' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,16'),  
			'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),   
			'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32)
		),		
				
	),

	
	//中金绑卡操作短信验证码配置
	'tie' => array(
			//异步通知url (给到第三方支付平台)
			//'notify_url' => '/refund/return_url/payment_type/?/client_type/?',
	
			//同步通知url (给到第三方支付平台)
			//'return_url' => '/refund/return_url/payment_type/?/client_type/?',
	
			//---------------------------------//
			//请求响应给商户站点 签名规则 (该规则以2维数组为组合, 比如有2组, 第一组是按字段 合并起来, md5 加密一次,  再和后面一组进行累加 md5加密. 依次类推如果有多组进行多组组合md5加密)
	
			//---------------------------------//
			//商户对se的中金绑卡请求, 参数列表  (0:不必填,有值则校验, 1:必填需签名, 2:无论如何不参与校验, 可以参与签名) 签名的顺序一定要排好
			'merchat_to_se_payresult' => array(
					'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32),
				    'institution_number' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,6','default'=>'001970'),
					'binding_number' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,32'),
	 				'BankID' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,8'),
					'AccountName' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,48'),
					'AccountNumber' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,32'), 
					'IdentificationType' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'int', 'size'=>'1,16'), 
					'IdentificationNumber' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,32'),
					'PhoneNumber' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,16'), 
					'CardType' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>'1,2'), 
					'ValidDate' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,32'), 
					'CVN2' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,32'),  
					'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),
					'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),  	//签名字段必填,不需进行参与签名
					'return_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //同步回调
					'notify_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //异步回调
			),
	),
	
	//中金绑卡操作配置
	'bang' => array(
			//异步通知url (给到第三方支付平台)
			//'notify_url' => '/refund/return_url/payment_type/?/client_type/?',
	
			//同步通知url (给到第三方支付平台)
			//'return_url' => '/refund/return_url/payment_type/?/client_type/?',
	
			//---------------------------------//
			//请求响应给商户站点 签名规则 (该规则以2维数组为组合, 比如有2组, 第一组是按字段 合并起来, md5 加密一次,  再和后面一组进行累加 md5加密. 依次类推如果有多组进行多组组合md5加密)
	
			//---------------------------------//
			//商户对se的中金绑卡请求, 参数列表  (0:不必填,有值则校验, 1:必填需签名, 2:无论如何不参与校验, 可以参与签名) 签名的顺序一定要排好
			'merchat_to_se_payresult' => array(
					'se_payment_code' => array('is_required'=>2, 'is_sign'=>1, 'type'=>'string', 'size'=>32),
					'institution_number' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,6','default'=>'001970'),
					'binding_number' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'string', 'size'=>'1,32'),
					'message_code' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>6),
					'created_ts' => array('is_required'=>1, 'is_sign'=>1, 'type'=>'time'),
					'se_sign' => array('is_required'=>1, 'is_sign'=>0, 'type'=>'string', 'size'=>32),  	//签名字段必填,不需进行参与签名
					'return_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //同步回调
					'notify_url' => array('is_required'=>0, 'is_sign'=>0, 'type'=>'string', 'size'=>'0,256'), //异步回调
			),
	),

	//错误代码定义和归类
	'error_status' => array(
	
		//成功
		'1' => 'SUCCESS',
		//系统错误
		'0' => 'SYSTEM_ERROR',
		//系统错误
		'FAILED' => 'SYSTEM_ERROR',		
		//不合法的参数
		'INVALID_PARAMS' => 'PARAMS_ERROR',
		//必填参数
		'REQUIRED_PARAMS' => 'PARAMS_ERROR',
		//不合法的商家
		'INVALID_MERCHANT' => 'PARAMS_ERROR',
		//不合法的签名
		'INVALID_SIGN' => 'PARAMS_ERROR',
		//空的参数
		'EMPTY_PARAMS' => 'PARAMS_ERROR',
		//不合法的参数类型
		'INVALID_PAYMENT_TYPE' => 'PARAMS_ERROR',
		//创建支付请求失败
		'CREATE_PAY_REQUEST_FAILED' => 'SYSTEM_ERROR',
		//邮件错误
		//'SEND_MAIL_FAILED' => 'SEND_MAIL_FAILED',
		//邮件异常
		//'SEND_MAIL_EXCEPTION' => 'SEND_MAIL_EXCEPTION',
		
	),
	
	
	
	
);