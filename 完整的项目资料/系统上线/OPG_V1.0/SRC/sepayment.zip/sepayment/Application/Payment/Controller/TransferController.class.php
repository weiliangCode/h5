<?php
namespace Payment\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team (tengyun)
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
use Think\Log;
class TransferController extends PaymentController{
    // 请求参数
    protected $param = [];
    // 效验规则
    private $rule = [];
    // 当前请求类型
    private $requestType = 'getTransferNo';
    // 转账详细
    private $transferInfo = [];
    // 返回类型
    private $use_json = false;
    public function __construct(){
        parent::__construct();
        $this->param = I('get.') ? I('get.') : I('post.');
        $this->rule = C('transfer');

    }
    // 转款入口
    public function index(){
        $this->check_params();
        if($this->has_err()){
            $this->errlog('verify params failed for request');
        }
        $this->use_json = (isset($this->param['use_json']) && $this->param['use_json'] ==1) ? true :false;
        $this->{$this->requestType}();
    }
    // 异步回调入口 (如:支付宝)
    public function notify_url($se_val = ''){
        /** $_POST如下
        array (
        'sign' => '108232224fcaa9d41d419890c3e380fc',
        'notify_time' => '2016-09-14 16:19:28',
        'pay_user_id' => '2088011335282401',
        'fail_details' => '1609140000017128^15549100304^徐腾^1.11^F^收款账户有误或不存在！^201609140119747371^20160914161517|',
        'pay_user_name' => '象翌微链科技发展有限公司',
        'sign_type' => 'MD5',
        'success_details' => '1609140000017129^15549142684@163.com^徐腾^1.22^S^^201609140119747372^20160914161529|',
        'notify_type' => 'batch_trans_notify',
        'pay_account_no' => '20880113352824010156',
        'notify_id' => '07bbf83475e96c737315a25cd364faakee',
        'batch_no' => '100000017002',
        )
         */
        //分解参数
        if(empty($se_val)){
            $this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: '.json_encode($_GET));
            $this->errlog();
        }
        //分解参数 $account_mer_id-$se_payment_type-$se_client_type
        $params_arr = explode('-', $se_val);
        if(count($params_arr) != 5){
            $this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url'.json_encode($_GET));
            $this->errlog();
        }
        $payment_code = $params_arr[0];
        //        $client_type = $params_arr[1];
        $client_type = 'web';
        $payment_type = $params_arr[2];
        $scenary_id = $params_arr[3];
        $app_id = $params_arr[4];

        $data = D('PaymentParameterDefine')->getList($payment_type, $scenary_id, $app_id);
        $alipay_config = [
            'partner' => $data['alipay_partner'],
            'key' => $data['key'],
            'sign_type' => strtoupper('MD5'),
            'input_charset' => strtolower('utf-8'),
            'transport' => 'http',
            'cacert' => $data['cacert']
        ];

        //1. 载入第三方支付接口的回调业务处理类去处理
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$payment_code.'/'.$client_type.'/';

        $cls = load_pm_lib($data['third_lib_path'].'transfer_notify_url', false, $alipay_config);

        $result = $cls->check_params();
        $checkResult = function($result){
            D('TransferRequestBatch')->startTrans();
            $transfer_data = D('Merchant')->get_info_by_transfer_no($result['details'][0]['transfer_no']);
            //3. 返回交易结果 给商户的异步返回
            if(isset($transfer_data['notify_url']) && !empty($transfer_data['notify_url'])){
                $do_notify = true;
            }else $do_notify = false;

            $t = D('TransferRequestBatch')->where(['transfer_request_batch_id'=>$result['batch_no']])->save(['status_id'=>1]);
//            if(!$t) return false;

            $transfer_no_info = '';
            foreach($result['details'] as $v){
                $transfer_no_info .='|'.$v['transfer_no'].'^'.$v['amount'].'^'.$v['msg'].'^'.$v['status'];
                if($v['status'] == 'SUCCESS')
                    $this->set_status(1);
                else $this->set_status('FAIL');
                $this->update_status('TransferRequest', $v['transfer_no'], 31, 32,['third_trade_no'=> $v['third_trade_no']]);
                if($do_notify) $this->update_status('TransferRequest', $v['transfer_no'], 51, 52);
            }
            $transfer_no_info = ltrim($transfer_no_info, '|');
            if($do_notify){
                $params = array('se_payment_code' => $transfer_data['se_payment_code'], 'transfer_no_info' => $transfer_no_info, 'payment_type_id' => $transfer_data['payment_type_id'], 'created_ts' => time());
                $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no_info'].$params['created_ts']).$transfer_data['se_private_key']);
                unset($params['se_payment_code']);
                $this->curl($transfer_data['notify_url'], http_build_query($params));
            }
            D('TransferRequestBatch')->commit();
            return true;
        };
        $checkResult($result);
        exit;
    }
    /**
     * 第一次请求.获取转账号TransferNo
     * 请求信息入库, 返回转账号
     */
    private function getTransferNo(){
        $datetime = date('Y-m-d H:i:s');
        //筛选业务参数入库
        $d = [
            'status_id' => D('Status')->get_status_id('10'),
            'payment_type_id' => isset($this->param['payment_type_id']) ? $this->param['payment_type_id'] : '',
//            'merchant_account_id' => isset($this->param['merchant_account_id']) ? $this->param['merchant_account_id'] : '',
            'rec_account_no' => isset($this->param['rec_account_no']) ? $this->param['rec_account_no'] : '',
            'rec_account_name' => isset($this->param['rec_account_name']) ? $this->param['rec_account_name'] : '',
            'se_payment_code' => isset($this->param['se_payment_code']) ? $this->param['se_payment_code'] : '',
            'subject' => isset($this->param['subject']) ? $this->param['subject'] : 'Suneee转账平台',
            'description' => isset($this->param['description']) ? $this->param['description'] : '',
            'amount' => isset($this->param['amount']) ? $this->param['amount'] : '',
            'return_url' => isset($this->param['return_url']) ? $this->param['return_url'] : '',
            'notify_url' => isset($this->param['notify_url']) ? $this->param['notify_url'] : '',
            'currency_code' => isset($this->param['currency_code']) ? $this->param['currency_code'] :'CNY',
            'created_ts' => $datetime,
            'modified_ts' => $datetime
        ];
        //场景区别
        if(isset($this->param->scenary_id) && !empty($this->param->scenary_id) ){
            $d['scenary_id'] = $this->param->scenary_id;
        }elseif(!isset($this->param['sdk']) || empty($this->param['sdk']))
            $d['scenary_id'] = (is_mobile()===TRUE )? '2' : '1';//判断应用使用场景
        else $d['scenary_id'] = (strtoupper($this->param['sdk']) == 'IOS') ? '3' : '4';//判断应用使用场景

        /**
        * 回调需要参数的情况下的拼接
        * 如 : xxxxxx?return_url=www.baidu.com&return_url_query=yyyy&yyyy={"mobile":"15278019052","fixfileids":"225"}
        * 则 : 数据库中的 return_url 将保存为 www.baidu.com?mobile=15278019052&fixfileids=225
        */
       $merchant_url = function($url_name) use(&$d){
           $url_query = $url_name.'_query';
           if(isset($this->param[$url_name]) && isset($this->param[$url_query]) && isset($this->param[ $this->param[$url_query] ])){
               $query = json_decode(html_entity_decode($this->param[ $this->param[$url_query] ])) ? json_decode(html_entity_decode($this->param[ $this->param[$url_query] ]),true) : $this->param[ $this->param[$url_query]] ;
               $d[$url_name] = $this->param[$url_name].'?'.http_build_query($query);
           }
           else $d[$url_name] = html_entity_decode($this->param[$url_name]);
       };
       $merchant_url('return_url');
//       $merchant_url('show_url');
       $merchant_url('notify_url');
            
        //保存支付请求
        $tr_m = D('TransferRequest');
        //如果该状态存在则不参数数据更新
        $r = $tr_m->add($d);
        //新增状态流水表
        if($r){
            //流水号状态表保存(组合支付前缀字符串)
            $rt_id = $tr_m->getLastInsID();    //取到当前自增ID值
            //组装transfer_no
            $transfer_no = $this->get_idno($rt_id, C('transfer_no_prefix'));
            if(is_int($rt_id)){
                //更新本表pay_no
                $d1 = array();
                $d1['transfer_request_id'] = $rt_id;
                $d1['transfer_no'] = $transfer_no;
                $d1['status_id'] = D('Status')->get_status_id('10'); //默认正确状态
                $m_mer = D('Merchant');
                $merchant_info = $m_mer->get_by_payment_code($d['se_payment_code']);
                $d1['auth_app_id'] = D('MerchantApp')->get_by_app($this->param['app_code'],$merchant_info['merchant_id']);
                //判断当前是否处于错误状态,如果有错误状态则返回
                //更新商家信息记录
                if($merchant_info && $d1['auth_app_id']){
                    $d1['merchant_id'] = $merchant_info['merchant_id'];
                }
                else{
                    //如果找不到商家,则报错
                    $this->set_status('INVALID_MERCHANT', 'can\'t found merchant data by se_payment_code:'.$d['se_payment_code']);
                    $this->errlog('empty merchant info by se_payment_code: '.$d['se_payment_code']);    //状态12 账号验证失败
                    return false;
                }
                //保存创建的商家记录
                $r = $tr_m->save_data($d1);
                if(!$r){
                    $this->set_status('CREATE_PAY_REQUEST_FAILED', 'create pay request failed for se_payment_code: '.$d['se_payment_code']);
                    $this->errlog('there is system error for create pay request failed for se_payment_code: '.$d['se_payment_code']);    //状态12 账号验证失败
                    return false;
                }
                //插入流水状态表记录
                $d2 = array();
                $d2['transfer_request_id'] = $rt_id;
                $d2['status_id'] = $d1['status_id'];    //和支付请求记录一致
                $d2['created_ts'] = date('Y-m-d H:i:s');
                $trf_m = D('TransferRequestFlow');
                $r = $trf_m->add($d2);
                //只有流水状态表插入成功,才能获取支付号
                if($r){
                    $this->update_status('TransferRequest', $this->param['transfer_no'], 11, 12);
                    if($this->use_json){
                        exit(json_encode([
                            'code'=> 200,
                            'message'=>'success',
                            'data'=>[
                                'transfer_no' => $transfer_no
                            ]
                        ]));
                    }else exit($transfer_no);
                }
            }
        }
        $this->errlog('create transfer request failed');
    }

    /**
     * 第2次请求, 没有payment_type_id
     * 存在 $this->param['sdk'] 返回json 否则返回 html
     */
    private function getPaymentType(){
        //支付号请求验证成功, 支付号请求验证失败
        $r = $this->update_status('TransferRequest', $this->param['transfer_no'], 13, 14);

        $payment_type = D('MerchantApp')->get_payment_by_appid_or_code_transfer($this->transferInfo['auth_app_id'],$this->transferInfo['scenary_id']);
//        $payment_type = D('MerchantApp')->select();
        //剔除不支持转账的支付方式
        foreach( $payment_type as $key => $value ){
            if($value['is_transfer'] == 0){
                unset($payment_type[ $key ]);
            }
        }
        //4. 响应当前的表单选择页面
        if(isset($this->param['use_json']) && ($this->param['use_json'] == 1)){
            $arr = [];
            foreach($payment_type as $v){
                $arr[] = [
                    'payment_type_id' => $v['payment_type_id'],
                    'name' => $v['name'],
                    'code' => $v['code']
                ];
            }
            exit(json_encode([
                'code'=> 200,
                'message'=> '',
                'data'=>[
                    'transfer_no' => $this->transferInfo['transfer_no'],
                    'payment_type_list' =>$arr,
                ]
            ]));
        }
        else{
            //初始化支付的参数数据
            $m_transfer_req = D('TransferRequest');
            $transfer_req_info = $m_transfer_req->get_by_transfer_no($this->transferInfo['transfer_no']);
            $this->assign('transfer_request', $transfer_req_info);
            //生成签名和交易参数
            $sign_data = array();
            $conf = C('transfer');
            $pconf = $conf['merchat_to_se_payno'];

            $sign_data['auth_app_id'] = $this->transferInfo['auth_app_id'];
            $sign_data['app_code'] = $this->param['app_code'];
            $sign_data['se_payment_code'] = $this->transferInfo['se_payment_code'];
            $sign_data['transfer_no'] = $this->transferInfo['transfer_no'];
            $sign_data['created_ts'] = time();
            $sign_data['se_sign'] = $this->build_sign($sign_data, $pconf, $this->transferInfo['se_private_key']);

            //签名录入表单,准备下次提交验证
            $this->assign('sign_data', $sign_data);
            $this->assign('payment_type', $payment_type);
            $this->assign('result', $this->status);
            //判断是否web/wap
            $is_mobile = is_mobile();
            if($is_mobile)
                $this->display('wap_transfer');
            else
                $this->display('web_transfer');
            exit();
        }
    }

    /**
     * 请求第三方支付
     */
    private function goPay(){
//        var_dump($this->param);exit;
        //1. 更新支付类型已经状态,并更新商户账号ID
        if(isset($this->param['payment_type_id']) && !empty($this->param['payment_type_id'])){
            $d = [
                'payment_type_id' => $this->param['payment_type_id'],
//                'merchant_account_id' => $this->param['merchant_account_id'],
            ];
            $this->transferInfo['payment_type_id'] = $this->param['payment_type_id'];
//            $this->transferInfo['merchant_account_id'] = $this->param['merchant_account_id'];
            $this->update_status('TransferRequest', $this->param['transfer_no'], 21, 22, $d); //支付类型验证成功, 支付类型验证失败
        }
        if($this->has_err()){
            $this->errlog('Invalid params for process pay controller');
        }
        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['transfer_data'] = $this->transferInfo;
        switch($data['transfer_data']['scenary_id']){
            case '1' :
                $data['client_type'] = 'web';
                break;
            case '2' :
                $data['client_type'] = 'wap';
                break;
            case '3' :
                $data['client_type'] = 'ios';
                break;
            case '4' :
                $data['client_type'] = 'android';
                break;
        }
//        var_dump($data);exit;
//        $data['payment_type'] = D('PaymentType')->checkPayment($this->transferInfo['auth_app_id'],$this->transferInfo['payment_type_id']);
        $data['payment_type'] = D('PaymentType')->checkPayment_is_tansfer($this->transferInfo['payment_type_id']);

        //// debug
//        if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//            var_dump( D('PaymentType')->getLastSql());exit;
//        }
        ////
        if(!$data['payment_type'])
            $this->errlog('Invalid payment_type for transfer controller');

        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'];

        //// debug
//        if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//            var_dump($data);exit;
//        }
        ////
//        var_dump($data);
//        exit('wwwww');
//        if(!$payment_type){
//            $this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: '.$payment_type);
//            return false;
//        }
//        $this->payment_type = $payment_type;
        // 获取当前app,payment 下的商户配置参数
        $arr = D('PaymentParameterDefine')->getList(
            $data['payment_type']['payment_type_id'],
            $data['transfer_data']['scenary_id'],
            $data['transfer_data']['auth_app_id']
        );
        $data['payment_type'] = array_merge($data['payment_type'], $arr);
//var_dump($data);exit;
        $att = [
            'pay_account' => isset($arr['account']) ? $arr['account'] : '商户暂未配置该支付渠道下的account,'.$data['transfer_data']['scenary_id']
        ];
        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/'.$data['payment_type']['code'], false, $data);
        //调用第三方支付,并得到结果
        $this->update_status('TransferRequest', $this->transferInfo['transfer_no'], 30,32,$att);
        $this->result = $cls->transfer();
        /*
     $this->result = array(
           //SE支付网关交易号
           'transfer_no' => 'xxx',
           //第三方交易号
           'third_trade_no' => 'xxx',
           //SE支付网关的状态
           'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
           //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
           'status_msg' => '签名错误'
       );
       */
        //3. 如果是跳入第三方结果页面下面代码不会被执行 (如:支付宝),
        //   如果$cls->transfer()中只接受第三方值, 执行下面的代码 (如:微信 ).
        //返回data值
        $this->check_third_return_val($this->result);
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);    //得到成功的支付结果, 得到失败的支付结果

        // 执行异步回调
        $result = $cls->notify_result();
        if($result)
            $this->update_status('TransferRequest', $transfer_no, 51, 52);
        // 同步响应
        $this->return_url();
    }
    // 同步响应
    private function return_url(){
        $params = $this->get_return_result();
        // 商户同步回调
        if(isset($this->transferInfo['return_url']) && !empty($this->transferInfo['return_url'])){
            $this->update_status('TransferRequest', $this->transferInfo['transfer_no'], 51, 52);
            header('Location:'.$this->transferInfo['return_url'].'?'.http_build_query($params));
        }else{
            if($this->use_json){
                exit(json_encode([
                    'code'=> ($this->status == TRUE) ? 200 : 0,
                    'message'=> $this->status_msg,
                    'data'=>[
                        'transfer_no' => $this->transferInfo['transfer_no']
                    ]
                ]));
            }
            // 平台展示结果
            if($this->has_err())
                $this->errlog();
            else{
                $this->assign('transfer_data', $this->transferInfo);
                if(is_mobile()) $this->display('wap_success');
                else $this->display('web_success');
                exit;
            }
        }
    }
    // 统一参数检测,组装
    private function check_params(){
        //检查是否是第一次转账请求(没有转账号)
        if(!isset($this->param['transfer_no']) || empty($this->param['transfer_no'])){
            // 设置请求类型(请求目的)
            $this->requestType = 'getTransferNo';
            $rule = $this->rule['merchat_to_se_payresult'];
            // 1.验证参数的合法性
            $r = $this->verify_all_params( $this->param, $rule );
            if($r === false){
                //如果验证不合法则报错
                return false;
            }

            // 2.验证授权号se_payment_code
            $merchant_info = D('Merchant')->get_by_payment_code($this->param['se_payment_code']);
            //// debug
//            if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//                var_dump(D('Merchant')->la);exit;
//            }
            ////
            if(
                !isset($merchant_info['se_payment_code']) ||
                !isset($merchant_info['se_private_key']) ||
                empty($merchant_info['se_payment_code']) ||
                ($merchant_info['se_payment_code'] != $this->param['se_payment_code'])
            ){
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code: '.$this->param['se_payment_code'].' ; check your se_private_key');
                return false;
            }

            // 3.验证签名
            $se_sign = $this->build_sign($this->param, $rule, $merchant_info['se_private_key']);
            if(!$se_sign || ($this->param['se_sign'] != $se_sign)){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_SIGN', 'this is invalid sign: '.$this->param['se_sign']);
                return false;
            }
        }
        //验证第二次请求(检查包含转账号的请求)
        else{
            //得到参数格式配置
            $rule = $this->rule['merchat_to_se_payno'];

            //验证参数的合法性
            $r = $this->verify_all_params($this->param, $rule);
            if($r === false) return false;
            // 1.验证授权号
            $this->transferInfo = D('Merchant')->get_info_by_transfer_no($this->param['transfer_no']);
            //得到返回url,供返回使用
//            $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';
            if(!isset($this->transferInfo['se_payment_code']) || !isset($this->transferInfo['se_private_key']) || empty($this->transferInfo['se_payment_code'])){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$this->param['se_payment_code'].'('.$this->transfer_no.')');
                return false;
            }
            // 2.验证签名
            $this->param['se_payment_code'] = $this->transferInfo['se_payment_code'];
            $se_sign = $this->build_sign($this->param, $rule, $this->transferInfo['se_private_key']);
            if(!$se_sign || $this->param['se_sign'] != $se_sign){
                $this->set_status('INVALID_SIGN', 'this is invalid sign for '.$this->param['se_sign'].'('.$this->transferInfo['transfer_no'].')');
                return false;
            }
            // 3.设置请求类型(请求目的)
            if(empty($this->transferInfo['payment_type_id']) ){
                if(!isset($this->param['payment_type_id']) || empty($this->param['payment_type_id'])){
                    $this->requestType = 'getPaymentType';
                    return true;
                }
            }
            $this->requestType = 'goPay';
        }
    }
    /**
     * 得到返回结果
     * @return Array
     */
    private function get_return_result(){
        $params = array('se_payment_code' => $this->transferInfo['se_payment_code'], 'transfer_no' => $this->transferInfo['transfer_no'], 'payment_type_id' => $this->transferInfo['payment_type_id'], 'created_ts' => time(), 'result' => $this->status, 'msg' =>  $this->status_msg);
        $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no'].$params['created_ts']).$this->transferInfo['se_private_key']);
        unset($params['se_payment_code']);
        return $params;
    }
}