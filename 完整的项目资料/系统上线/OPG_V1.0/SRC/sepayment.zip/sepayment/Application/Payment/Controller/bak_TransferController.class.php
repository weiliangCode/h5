<?php
namespace Payment\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
use Think\Log;

/**
 * 支付控制器
 * 这是支付的入口
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class TransferController extends PaymentController{

    /**
     * 转账号, 商户第二次回调请求会带转账号过来。
     * @type string
     */
    protected $transfer_no = '';

    /**
     * 支付请求id
     */
    protected $pay_request_id = '';

    /**
     * 支付类型ID
     */
    protected $payment_type_id = '';

    protected $paymentParams = array();

    /**
     * 支付的入口
     * a. 商户站点支付请求的入口
     * b. 得到支付号再次请求
     * c. 商户响应一个支付页面
     */
    public function index(){
        $p = I('get.') ? I('get.') : I('post.');
        //1. 检查参数合法性, 验证通过才入库
        $this->check_params();

        $this->payment_type_id = $p['payment_type_id'];//公共支付存在支付类型

        /*if($this->payment_type_id && $this->transfer_no)
        {
            $this->transfer_api();
        }*/
        //2.1 如果是第一次请求应该创建转账请求并返回转账请求号
        if(!$this->transfer_no){
            if($this->has_err()){
                $this->errlog('verify params failed for first pay request');
            }
            //3. 记录一条新支付请求记录
            $this->create_transfer_request();

            //4. 返回转账号, 中断程序
            if(!empty($this->transfer_no)){
                echo $this->transfer_no;
                exit;
            }
            else{
                $this->errlog('create transfer request failed');
            }
            //3. 这里不做参数验证入库, 更新状态为  11, 12  请求验证成功, 请求验证失败
            //$r = $this->update_status('PayRequest', $this->pay_no, 11, 12);
        }
        //2.2 如果是有转账号的请求(第二次)直接进入转账通道选择页面
        else{
            //3. 更新状态为  13, 14  //支付号请求验证成功, 支付号请求验证失败
            $r = $this->update_status('TransferRequest', $this->transfer_no, 13, 14);

            if(!$r || $this->has_err()){
                $this->errlog('verify params failed for second pay request');
            }

            //4. 响应当前的表单选择页面
            if($this->payment_type_id){
                $this->transfer_api();
            }
            else{
                $this->display_transfer_select();
            }

        }

        exit;
    }

    /**
     * FLOW 校验参数 (该流程校验不会退出程序,只有记录入库后才根据状态去决定是否退出)
     * a. 如果验证失败则直接返回错误调用到商户站点回调页
     * b. 更新会话记录状态 '11/12 | 13/14', 新增支付请求流水记录状态为'11/12 | 13/14'
     * @return boolean TRUE 继续执行, FALSE 回调告诉错误,并终止逻辑
     */
    protected function check_params(){

        //得到需检查的参数
        $p = I('get.') ? I('get.') : I('post.');
        // $p = $this->paymentParams?$this->paymentParams:(I('get.')?I('get.'):I('post.'));

        //得到支付的配置
        $conf = C('transfer');
        
        //检查是否是第一次转账请求(没有转账号)
        if(!isset($p['transfer_no'])){
            // $p = I('post.');
            $p = I('post.') ? I('post.') : I('get.');

            //得到返回url,供返回使用
            $this->return_url = $p['return_url'];
            //添加支付方式
            $this->payment_type_id = $p['payment_type_id'];

            //得到参数格式配置
            $pconf = $conf['merchat_to_se_payresult'];

            //验证参数的合法性
            $r = $this->verify_all_params($p, $pconf);
            if($r === false){
                //如果验证不合法则报错
                return false;
            }

            //验证授权号
            $m_mer = D('Merchant');

            $merchant_info = $m_mer->get_by_payment_code($p['se_payment_code']);

            if(!isset($merchant_info['se_payment_code']) || !isset($merchant_info['se_private_key']) || empty($merchant_info['se_payment_code']) || $merchant_info['se_private_key'] != $p['se_private_key']){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code: '.$p['se_payment_code']);
                return false;

            }

            //验证签名
            $se_sign = $this->build_sign($p, $pconf, $merchant_info['se_private_key']);

            if(!$se_sign || $p['se_sign'] != $se_sign){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_SIGN', 'this is invalid sign: '.$p['se_sign']);
                return false;
            }
        }

        else//验证第二次请求(检查包含转账号的请求)
        {
            //赋值转账号给当前类
            $this->transfer_no = $p['transfer_no'];

            //添加支付方式
            $this->payment_type_id = $p['payment_type_id'];

            //得到参数格式配置
            $pconf = $conf['merchat_to_se_payno'];
            //$p['se_payment_code'] = '870e856360391980a51958b91f12cb3d';

            //验证参数的合法性
            $r = $this->verify_all_params($p, $pconf);
            if($r === false){
                //如果验证不合法则报错
                return false;
            }
            //验证授权号
            $m_mer = D('Merchant');
            $transfer_data = $m_mer->get_merchant_transfer_data_by_transfer_no($p['transfer_no']);
            $transfer_data['OrderNo'] = $p['OrderNo'];
            $transfer_data['app_code'] = $p['app_code'];
            $transfer_data['institution_number'] = $p['institution_number'];
            $transfer_data['AccountType'] = $p['AccountType'];
            $transfer_data['BankID'] = $p['BankID'];
            /*   $transfer_data['AccountName'] = $p['AccountName'];
              $transfer_data['AccountNumber'] = $p['AccountNumber'];
              $transfer_data['BranchName'] = $p['BranchName'];
              $transfer_data['Province'] = $p['Province'];
              $transfer_data['City'] = $p['City'];*/
            //得到返回url,供返回使用
            $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';

            if(!isset($transfer_data['se_payment_code']) || !isset($transfer_data['se_private_key']) || empty($transfer_data['se_payment_code'])){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$p['se_payment_code'].'('.$this->transfer_no.')');
                return false;
            }
            //验证签名
            $p['se_payment_code'] = $transfer_data['se_payment_code'];
            $se_sign = $this->build_sign($p, $pconf, $transfer_data['se_private_key']);
            if(!$se_sign || $p['se_sign'] != $se_sign){
                $this->set_status('INVALID_SIGN', 'this is invalid sign for '.$p['se_sign'].'('.$this->transfer_no.')');
                return false;
            }

            //赋值转账数据
            $this->transfer_data = $transfer_data;
        }

        return true;
    }

    /**
     * 显示转账选择页面
     * a. 初始化商户请求的参数信息
     * b. 初始化签名
     * c. 初始化支付类型
     */
    protected function display_transfer_select(){
        //初始化支付的参数数据
        $m_transfer_req = D('TransferRequest');
        $transfer_req_info = $m_transfer_req->get_by_transfer_no($this->transfer_no);
        $this->assign('transfer_request', $transfer_req_info);

        //生成签名和交易参数
        $sign_data = array();
        $conf = C('transfer');
        $pconf = $conf['merchat_to_se_payno'];

        $sign_data['auth_app_id'] = $this->transfer_data['auth_app_id'];
        $sign_data['app_code'] = $this->transfer_data['app_code'];
        $sign_data['se_payment_code'] = $this->transfer_data['se_payment_code'];
        $sign_data['transfer_no'] = $this->transfer_no;
        $sign_data['created_ts'] = time();
        $sign_data['se_sign'] = $this->build_sign($sign_data, $pconf, $this->transfer_data['se_private_key']);
        $sign_data['OrderNo'] = $this->transfer_data['OrderNo'];
        $sign_data['institution_number'] = $this->transfer_data['institution_number'];
        $sign_data['AccountType'] = $this->transfer_data['AccountType'];
        $sign_data['BankID'] = $this->transfer_data['BankID'];
        /* $sign_data['AccountName'] = $this->transfer_data['AccountName'];
        $sign_data['AccountNumber'] = $this->transfer_data['AccountNumber'];
        $sign_data['BranchName'] = $this->transfer_data['BranchName'];
        $sign_data['Province'] = $this->transfer_data['Province'];
        $sign_data['City'] = $this->transfer_data['City'];*/
        //签名录入表单,准备下次提交验证
        $this->assign('sign_data', $sign_data);



        //判断是否web/wap去调用对应的接口
        $is_mobile = is_mobile();
//        $scenary = $is_mobile ? 2 : 1;
//        // 保存支付场景
//        D('TransferRequest')->where(['transfer_no'=>$this->transfer_no])->save(['scenary_id'=>$scenary]);
        // 获取当前app与场景 的可用的支付方式
        $payment_type = D('MerchantApp')->get_payment_by_appid_or_code($this->transfer_data['auth_app_id'],$this->transfer_data['scenary_id']);
//        var_dump($payment_type);exit;
            //初始化支付方式                                               
            //$m_pay_type = D('PaymentType');
            //$payment_type = $m_pay_type->get_id_data_list();

        //剔除不支持转账的支付方式
        foreach( $payment_type as $key => $value ){
            if($value['is_transfer'] == 0){
                unset($payment_type[ $key ]);
            }
        }

        $this->assign('payment_type', $payment_type);

        $this->assign('result', $this->status);
        if($is_mobile){
            $this->display('wap_transfer');
        }
        else{
            $this->display('web_transfer');
        }

    }

    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------- 回调接口, 支持同步回调,异步回调方法 ----------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//

    /**
     * 同步回调
     *
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     *
     * @return void
     */
    public function return_url($se_val = ''){
        //分解参数
        if(empty($se_val)){
            $this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: '.json_encode($_GET));
            $this->errlog();
        }

        //分解参数 $account_mer_id-$se_payment_type-$se_client_type
        $params_arr = explode('-', $se_val);
        if(count($params_arr) != 3){
            $this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url'.json_encode($_GET));
            $this->errlog();
        }
        $account_mer_id = $params_arr[0];
        $se_payment_type = $params_arr[1];
        $se_client_type = $params_arr[2];
        //组合账户数据的客户端目录
        $data['merchant_data_path'] = MER_DATA_PATH.$account_mer_id.'/'.$se_payment_type.'/';
        $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$se_client_type.'/';

        //1. 载入第三方支付接口的回调业务处理类去处理
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';
        $cls = load_pm_lib($data['third_lib_path'].'return_url', false, $data);

        //2. 检查回调参数并返回结果的状态联数组
        /*
        return array(
            //SE支付网关交易号
            'pay_no' => 'xxx',
            //第三方交易号
            'third_trade_no' => 'xxx',
            //SE支付网关的状态
            'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
            //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
            'status_msg' => '签名错误'
        );
        */
        $this->result = $cls->check_params();
        $this->check_third_return_val($this->result);

        //3. 更新状态和返回第三方交易号结果
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);
//        $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);
        $transfer_data = D('Merchant')->get_info_by_transfer_no($transfer_no);

        //4. 如果有错误,则返回到错误页面
        if($this->has_err()){
            //在SE支付平台显示错误信息
            if(empty($transfer_data) || !isset($transfer_data['return_url']) || empty($transfer_data['return_url'])){
                $this->errlog();
            }
            //把错误信息返回到第三方平台
            else{
                $this->transfer_data = $transfer_data;
                $return_result = $this->get_return_result();
                header('Location:'.$transfer_data['return_url'].'?'.http_build_query($return_result));
            }
            exit;
        }

        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('TransferRequest', $transfer_no, 51, 52);

        //6. 回调商户的同步回调return_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        if(!isset($transfer_data['return_url']) || empty($transfer_data['return_url'])){
            $this->assign('transfer_data', $transfer_data);
            if(is_mobile()){
                $this->display('wap_success');
            }
            else{
                $this->display('web_success');
            }
            exit;
        }
        //6.2 如果商户有回调url,则调用回调url
        else{
            $this->transfer_data = $transfer_data;
            $return_result = $this->get_return_result();
            header('Location:'.$transfer_data['return_url'].'?'.http_build_query($return_result));
        }

        //7. 回执更新最后结果状态 201, 202 (此状态暂时不调用, 异步更新会更新到 201, 202)
        //$this->update_status('PayRequest', $pay_no, 201, 202, '', $result);
    }

    /**
     * 异步回调
     * @params string 参数组合 $params=$payment_code-$client_type-$payment_type-$scenary_id-$app_id
     * @return void
     */
    public function notify_url($se_val = ''){
        //分解参数
        if(empty($se_val)){
            $this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: '.json_encode($_GET));
            $this->errlog();
        }
        //分解参数 $account_mer_id-$se_payment_type-$se_client_type
        $params_arr = explode('-', $se_val);
        if(count($params_arr) != 5){
            $this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url'.json_encode($_GET));
            $this->errlog();
        }
        $payment_code = $params_arr[0];
        $client_type = $params_arr[1];
        $payment_type = $params_arr[2];
        $scenary_id = $params_arr[3];
        $app_id = $params_arr[4];

        $data = D('PaymentParameterDefine')->getList($payment_type, $scenary_id, $app_id);

        $alipay_config = [
            'partner' => $data['alipay_partner'],
            'key' => $data['key'],
            'sign_type' => strtoupper('MD5'),
            'input_charset' => strtolower('utf-8'),
            'transport' => 'http'
        ];

        //1. 载入第三方支付接口的回调业务处理类去处理
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$payment_code.'/'.$client_type.'/';

        $cls = load_pm_lib($data['third_lib_path'].'transfer_notify_url', false, $alipay_config);

        //2. 检查回调参数并返回结果的状态联数组
        /*
        return array(
            //支付号
            'pay_no' => 'xxx',
            //第三方支付号
            'third_trade_no' => '交易号',
            //SE支付网关的状态
            'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
            //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
            'status_msg' => '签名错误'
        );
        */
        $this->result = $cls->check_params();
//        $this->check_third_return_val($this->result);
        var_dump($this->result);
exit;
        //3. 更新状态和返回第三方交易号结果
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);
//        $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);
        $transfer_data = D('Merchant')->get_info_by_transfer_no($transfer_no);

        //4. 如果有错误,则返回到错误页面
        if($this->has_err()){
            //在SE支付平台显示错误信息
            if(!isset($transfer_data['notify_url']) || empty($transfer_data['notify_url'])){
                //$this->errlog();
                exit;
            }
            //把错误信息返回到第三方平台
            else{
                $this->transfer_data = $transfer_data;
                $return_result = $this->get_return_result();
                $this->curl($transfer_data['notify_url'], $return_result);
            }
        }

        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('TransferRequest', $transfer_no, 51, 52);

        //6. 回调商户的异步回调notify_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        if(!isset($transfer_data['notify_url']) || empty($transfer_data['notify_url'])){
            exit;
        }

        //6.2 如果商户有回调url,则调用回调url
        $this->transfer_data = $transfer_data;
        $return_result = $this->get_return_result();
        $this->curl($transfer_data['notify_url'], $return_result);

        //7. 回执更新最后结果状态 201, 202 (此状态暂时不调用)
        $this->update_status('TransferRequest', $transfer_no, 201, 202, '', $result);
    }

    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 ------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//

    /**
     * 创建第一次支付请求 (未带pay_no的支付请求)
     * @return void
     */
    protected function create_transfer_request(){
        //创建第一条支付记录
        // $p = I('post.');
        $p = I('post.') ? I('post.') : I('get.');
        //筛选业务参数入库
        $d = array();
        $datetime = date('Y-m-d H:i:s');

        //初始状态模型类
        $m_status = D('Status');

        $d['status_id'] = $m_status->get_status_id('10');    //初始状态 10

        $d['transfer_request_id'] = '';
        $d['transfer_no'] = '';
        // $d['payment_type_id'] = '';
        $d['payment_type_id'] = (isset($p['payment_type_id']) && !empty($p['payment_type_id'])) ? $p['payment_type_id'] : '';
//        $d['scenary_id'] = (isset($p['scenary_id']) && !empty($p['scenary_id'])) ? $p['scenary_id'] : '';
        $d['rec_account_no'] = isset($p['rec_account_no']) ? $p['rec_account_no'] : '';
        $d['rec_account_name'] = isset($p['rec_account_name']) ? $p['rec_account_name'] : '';
        $d['se_payment_code'] = (isset($p['se_payment_code']) && !empty($p['se_payment_code'])) ? $p['se_payment_code'] : '';
        $d['subject'] = (isset($p['subject']) && !empty($p['subject'])) ? $p['subject'] : 'Suneee转账平台';
        $d['description'] = (isset($p['description']) && !empty($p['description'])) ? $p['description'] : '';
        //$d['third_trade_no'] = ''; //第三方交易号, 提交支付类型时更新
        $d['amount'] = (isset($p['amount']) && !empty($p['amount'])) ? $p['amount'] : '';
        $d['return_url'] = (isset($p['return_url']) && !empty($p['return_url'])) ? $p['return_url'] : '';
        $d['notify_url'] = (isset($p['notify_url']) && !empty($p['notify_url'])) ? $p['notify_url'] : '';

        //场景区别
        if(!isset($p['sdk']) || empty($p['sdk']))
            $d['scenary_id'] = (is_mobile()===TRUE )? '2' : '1';//判断应用使用场景
        else $d['scenary_id'] = (strtoupper($p['sdk']) == 'IOS') ? '3' : '4';//判断应用使用场景

        //$d['merchant_id'] = '';	//商户ID, 后面更新
        //$d['merchant_account_id'] = ''; //商户账号ID,  后面更新
        $d['currency_code'] = (isset($p['currency_code']) && !empty($p['notify_url'])) ? $p['currency_code'] : 'CNY';
        $d['created_ts'] = $datetime;
        $d['modified_ts'] = $datetime;

        //--这里不启动事务处理,因为状态流水和状态如果不对应就表示异常
        //保存支付请求
        $tr_m = D('TransferRequest');

        //如果该状态存在则不参数数据更新
        $r = $tr_m->add($d);

        //新增状态流水表
        if($r){
            //流水号状态表保存(组合支付前缀字符串)
            $rt_id = $tr_m->getLastInsID();    //取到当前自增ID值

            //组装transfer_no
            $transfer_no = $this->get_idno($rt_id, $this->env_conf['transfer_no_prefix']);

            if(is_int($rt_id)){
                //更新本表pay_no
                $d1 = array();
                $d1['transfer_request_id'] = $rt_id;
                $d1['transfer_no'] = $transfer_no;
                $d1['status_id'] = $m_status->get_status_id('10'); //默认正确状态
                $m_mer = D('Merchant');
                $merchant_info = $m_mer->get_by_payment_code($d['se_payment_code']);

                $d1['auth_app_id'] = D('MerchantApp')->get_by_app($p['app_code'],$merchant_info['merchant_id']);
                //判断当前是否处于错误状态,如果有错误状态则返回
                //更新商家信息记录
                if($merchant_info && $d1['auth_app_id']){
                    $d1['merchant_id'] = $merchant_info['merchant_id'];
                }
                else{
                    //如果找不到商家,则报错
                    $this->set_status('INVALID_MERCHANT', 'can\'t found merchant data by se_payment_code:'.$d['se_payment_code']);
                    $this->errlog('empty merchant info by se_payment_code: '.$d['se_payment_code']);    //状态12 账号验证失败
                    return false;
                }
                //保存创建的商家记录
                $r = $tr_m->save_data($d1);

                if(!$r){
                    $this->set_status('CREATE_PAY_REQUEST_FAILED', 'create pay request failed for se_payment_code: '.$d['se_payment_code']);
                    $this->errlog('there is system error for create pay request failed for se_payment_code: '.$d['se_payment_code']);    //状态12 账号验证失败
                    return false;
                }

                //插入流水状态表记录
                $d2 = array();
                $d2['transfer_request_id'] = $rt_id;
                $d2['status_id'] = $d1['status_id'];    //和支付请求记录一致
                $d2['created_ts'] = date('Y-m-d H:i:s');
                $trf_m = D('TransferRequestFlow');
                $r = $trf_m->add($d2);

                //只有流水状态表插入成功,才能获取支付号
                if($r){
                    $this->transfer_no = $transfer_no;
                }
                //else
                //{
                //这里的异常,不做处理,因为不影响整个流程.只是状态流水没有10的记录.
                //}
                return $r;
            }
        }
        return false;
    }

    /**
     * 直接选择转账方式转账(接口)
     */
    public function transfer_api(){
        $p = I('get.') ? I('get.') : I('post.');
        //判断获取支付方式是否存在
        $m_pay_type = D('TransferRequest');
        $payment_type = $m_pay_type->check_payment_with_transfer_no($p['transfer_no']);
// todo 
        // 获取当前app与场景 的可用的支付方式
        $payment_type = D('MerchantApp')->get_payment_by_appid_or_code($p['auth_app_id'],$this->transfer_data['scenary_id']);
        //        var_dump($payment_type);exit;
        //初始化支付方式
        //$m_pay_type = D('PaymentType');
        //$payment_type = $m_pay_type->get_id_data_list();

        //剔除不支持转账的支付方式
        foreach( $payment_type as $key => $value ){
            if($value['is_transfer'] == 0){
                unset($payment_type[ $key ]);
            }
        }

        ////

        if(!$payment_type){
            $this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: '.$payment_type);
            return false;
        }
        $this->payment_type = $payment_type;

        //1.生成流水号
        if($this->has_err()){
            $this->errlog('verify params failed for first transfer request');
        }

        // $this->create_transfer_request();

        //2.封装实际支付参数，发起所选择的支付方式支付请求
        if(!empty($this->transfer_no)){

            $transfer_no = $this->transfer_no;

            //验证授权号
            $m_mer = D('Merchant');
            $transfer_data = $m_mer->get_merchant_transfer_data_by_transfer_no($transfer_no, $this->payment_type_id);
            $transfer_data['OrderNo'] = $p['OrderNo'];
            $transfer_data['institution_number'] = $p['institution_number'];
            $transfer_data['AccountType'] = $p['AccountType'];
            $transfer_data['BankID'] = $p['BankID'];
            /*   $transfer_data['AccountName'] = $p['AccountName'];
             $transfer_data['AccountNumber'] = $p['AccountNumber'];
            $transfer_data['BranchName'] = $p['BranchName'];
            $transfer_data['Province'] = $p['Province'];
            $transfer_data['City'] = $p['City'];*/
            //得到返回url,供返回使用
            $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';

            //如果没有账号则报错
            if(empty($transfer_data['merchant_account_id']) || empty($transfer_data['se_payment_key']) || empty($transfer_data['se_payment_code'])){
                //如果验证不合法则输入错误状态并报错
                $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$transfer_data['se_payment_code'].'('.$this->transfer_no.')');
                return false;
            }

            $this->transfer_data = $transfer_data;    //得到商家信息

            //更新状态为  13, 14 
            $d['merchant_account_id'] = $this->transfer_data['merchant_account_id'];
            $r = $this->update_status('TransferRequest', $this->transfer_no, 13, 14, $d);

            if(!$r || $this->has_err()){
                $this->errlog('verify params failed for second transfer request');
            }

            //发起第三方请求
            $this->request_third_transfer();

            exit;
        }
        else{
            $this->errlog('create transfer request failed');
        }

    }

    /**
     * 请求第三方转账
     * @return void
     */
    protected function request_third_transfer(){
        //1. 检查是否是wap/web请求
        $data['client_type'] = is_mobile() === true ? 'wap' : 'web';

        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['payment_type'] = $this->payment_type;
        $data['transfer_data'] = $this->transfer_data;
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/';

        //2.1 组合账户数据目录
        if(!isset($data['transfer_data']['account_mer_id']) || empty($data['transfer_data']['account_mer_id'])){
            $this->set_status('EMPTY_PARAMS', 'this is empty account_mer_id for request third pay: '.json_encode($data['transfer_data']));
            $this->errlog();
            return false;
        }
        $data['merchant_data_path'] = MER_DATA_PATH.$data['transfer_data']['account_mer_id'].'/'.$data['payment_type']['code'].'/';
        //2.2 组合账户数据的客户端目录
        $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$data['client_type'].'/';
        //             echo '<pre>';var_dump($data);exit;
        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$this->payment_type['code'].'/'.$data['client_type'].'/'.$this->payment_type['code'], false, $data);
        //调用第三方支付,并得到结果

        $this->result = $cls->transfer();
        $this->check_third_return_val($this->result);

        //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
        //返回data值
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);    //得到成功的支付结果, 得到失败的支付结果

        //4. 如果有错误,则返回到错误页面
        if($this->has_err()){
            $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);
            //在SE支付平台显示错误信息
            if(!isset($transfer_data['return_url']) || empty($transfer_data['return_url'])){
                $this->errlog();
            }
            //把错误信息返回到第三方平台
            else{
                $this->transfer_data = $transfer_data;
                $return_result = $this->get_return_result();
                header('Location:'.$transfer_data['return_url'].'?'.http_build_query($return_result));
            }
        }

        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('TransferRequest', $transfer_no, 51, 52);

        //6. 回调商户的同步回调return_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        $transfer_data = D('Merchant')->get_merchant_transfer_data_by_transfer_no($transfer_no);

        if(!isset($transfer_data['return_url']) || empty($transfer_data['return_url'])){
            $this->assign('transfer_data', $transfer_data);
            if(is_mobile()){
                $this->display('wap_success');
            }
            else{
                $this->display('web_success');
            }
            exit;
        }
        //6.2 如果商户有回调url,则调用回调url
        else{
            $return_result = $this->get_return_result();
            header('Location:'.$transfer_data['return_url'].'?'.http_build_query($return_result));
            exit;
        }
    }

    /**
     * 得到返回结果
     * @return Array
     */
    protected function get_return_result(){
        $params = array('se_payment_code' => $this->transfer_data['se_payment_code'], 'transfer_no' => $this->transfer_data['transfer_no'], 'payment_type_id' => $this->transfer_data['payment_type_id'], 'created_ts' => time(), 'result' => $this->status);
        $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no'].$params['created_ts']).$this->transfer_data['se_payment_key']);
        unset($params['se_payment_code']);
        return $params;
    }

    /**
     * 得到类型,用来给模板区分具体的动作
     * @return String
     */
    public function get_type(){
        return 'pay';
    }

    //支付结果
    public function pay_result($requestData = ''){
        $pay_no = current(explode('-', $requestData));
        $result = D('PayRequest')->get_by_pay_no($pay_no);
        $status_id = D('Status')->get_status_id('51'); //成功支付代码
        if($result['status_id'] == $status_id){
            $re_data['msg'] = "success";
        }
        else{
            $re_data['msg'] = "fail";
        }

        echo json_encode($re_data);
        exit;
    }

    public function third_call_back($data = ''){
        if(!empty($data)){
            $data = json_decode($data, true);
        }
        $cls = load_pm_lib($data['third_lib_path'].$data['payment_type']['code'], false, $data);
        $cls->toPay();
    }

}