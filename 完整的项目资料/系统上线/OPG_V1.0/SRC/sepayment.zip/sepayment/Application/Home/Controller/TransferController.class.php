<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class TransferController extends HomeController{
    static $transfer_url = '';
    static $transfer_batch_url = '';
    static $status = [
        '处理中' => [1,2,4,6,7,9,10,12,13],
        '失败' => [3,5,8,11,14,16],
        '成功' => [15,17,18]
    ];
    private $is_batch = false;//是否批量
    // 查询条件数组
    private $search = array();
    // 排序标准
    private $order = 'transfer_request.created_ts desc';
    private $limit = '';
    // 应用支付渠道管理列表, 需要返回的字段
    private $key = [
        'transfer_request.transfer_no',
        'transfer_request.third_trade_no',
        'transfer_request.pay_account',
        'transfer_request.amount',
        'transfer_request.rec_account_no',
        'transfer_request.rec_account_name',
        'transfer_request.created_ts',
        'transfer_request.subject',
        'transfer_request.modified_ts',
        'transfer_request.status_id',
        'transfer_request.description',
        'transfer_request.batch_no'
    ];
    public function __construct(){
        parent::__construct();

        $server = think_server();
        switch($server){
            case 'DEV':
                self::$transfer_url = 'http://172.16.30.13:9008/payment/Transfer';
                self::$transfer_batch_url = 'http://172.16.30.13:9008/payment/TransferBatch';
                break;
            case 'TEST':
                self::$transfer_url = 'http://172.19.6.115:9008/payment/Transfer';
                self::$transfer_batch_url = 'http://172.19.6.115:9008/payment/TransferBatch';
                break;
            case 'PROD':
                self::$transfer_url = 'http://pay.weilian.cn/payment/Transfer';
                self::$transfer_batch_url = 'http://pay.weilian.cn/payment/TransferBatch';
                break;
            default:
                self::$transfer_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/Transfer';
                self::$transfer_batch_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/TransferBatch';
                break;
        }
//        if($_SERVER['HTTP_HOST'] == '172.19.5.55'){
//            self::$transfer_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/Transfer';
//            self::$transfer_batch_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/TransferBatch';
//        }elseif($_SERVER['HTTP_HOST'] == 'opgdev.weilian.cn'){
//            self::$transfer_url = 'http://opgdev.weilian.cn/payment/Transfer';
//            self::$transfer_batch_url = 'http://opgdev.weilian.cn/payment/TransferBatch';
//        }elseif($_SERVER['HTTP_HOST'] == '172.16.30.13:9008'){
//            self::$transfer_url = 'http://172.16.30.13:9008/payment/Transfer';
//            self::$transfer_batch_url = 'http://172.16.30.13:9008/payment/TransferBatch';
//        }else {
//            self::$transfer_url = 'http://172.19.6.115:9008/payment/Transfer';
//            self::$transfer_batch_url = 'http://172.19.6.115:9008/payment/TransferBatch';
//        }
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
    }
    // 获取应用下的转账列表,支持分页,搜索
    //{"act":"2","method":"Transfer","op":"getList","data":{"merchant_app_id":"1","payment_type_id":"3"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getList($export =false){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->payment_type_id)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id || payment_type_id';
            exit(json_encode($this->returnData));
        }
        if($this->searchSql() && $this->pageSql() && $this->getData($export) ){
            if($export)  return $this->returnData['data']['list'];
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            exit(json_encode($this->returnData));
        }
    }
    // 查看转账详情
    // {"act":"2","method":"Transfer","op":"getInfo","data":{"transfer_no":"1609020000016975"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getInfo(){
        if(is_null($this->param->transfer_no)){
            $this->returnData['message'] = '缺少必要参数 transfer_no';
            exit(json_encode($this->returnData));
        }
//        $res = D('TransferRequest')->getPaymentInfoWithTransferNo($this->param->transfer_no);
        $rr = D('TransferRequest')->where(['transfer_no'=> $this->param->transfer_no])->find();
//        var_dump($rr);exit;
        $arr = [
            'transfer_no' => $rr['transfer_no'],
            'third_trade_no' => $rr['third_trade_no'],
            'pay_account' => $rr['pay_account'],
            'subject' => $rr['subject'],
            'batch_no' => $rr['batch_no'],
            'status_id' => $rr['status_id'],
            'description' => $rr['description'],
            'rec_account_no' => $rr['rec_account_no'],
            'rec_account_name' => $rr['rec_account_name'],
            'amount' => $rr['amount'],
            'created_ts' => $rr['created_ts']
        ];
        $att[] = $arr;
        $this->makeArr($att);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $att[0];
        exit(json_encode($this->returnData));
    }
    // 获取可用的付款账户
    // {"act":"2","method":"Transfer","op":"getAccountWithPayment","data":{"merchant_app_id":"1","payment_type_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getAccountWithPayment(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->payment_type_id)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id || payment_type_id';
            exit(json_encode($this->returnData));
        }
        $arr = D('PaymentParameterDefine')->getScenaryAndName($this->param->merchant_app_id, $this->param->payment_type_id);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $arr;
        exit(json_encode($this->returnData));

    }
    // 发起转账流程入口 : 表单数据接受
    // 需要同步请求
    //{"act":"2","method":"Transfer","op":"doTransfer","data":{"merchant_app_id":"1","payment_type_id":"1","scenary_id":"1","rec_account_no":"15549142684@163.com","rec_account_name":"徐腾","amount":"1.33"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function doTransfer(){
        if(is_null($this->param->merchant_app_id) ||
            is_null($this->param->payment_type_id) ||
            is_null($this->param->scenary_id) ||
            is_null($this->param->rec_account_no) ||
            is_null($this->param->amount) ||
            is_null($this->param->rec_account_name)){
            $this->returnData['message'] = '缺少必要参数!';
            exit(json_encode($this->returnData));
        }
        // 支付渠道配置参数
        $paymentInfo = D('PaymentParameterDefine')->getPaymentList($this->param->payment_type_id,$this->param->scenary_id,$this->param->merchant_app_id);
        // 商户相关信息
        $merchantInfo = D('Merchant')->getMerchantInfoByAppId($this->param->merchant_app_id);
        if(is_null($merchantInfo)){
            header("Content-type: text/html; charset=utf-8");
//            echo D('Merchant')->getLastSql();
            exit('请先获取翌支付私钥!!');
        }
        $data = array_merge($paymentInfo, $merchantInfo);
        $data = array_merge((array)$this->param, $data);
        $this->transfer_request([$data]);
    }
    // 发起转账流程入口 : Excel数据接受
    // 需要同步请求
    //{"act":"2","method":"Transfer","op":"doTransferExcel","data":{"merchant_app_id":"3","payment_type_id":"1","scenary_id":"1","excel":"http://172.19.5.55/suneee/OPG/web/trunk/sepayment/test.xlsx"},"sign":"456678wewqesa45d64sa56wqe45"}
    // http://172.19.5.55/suneee/OPG/web/trunk/sepayment/index.php?act=2&method=Transfer&op=doTransferExcel&data={%22excel%22:%22http://172.19.5.55/suneee/OPG/web/trunk/sepayment/test.xlsx%22,%22scenary_id%22:%221%22,%22payment_type_id%22:%221%22,%22merchant_app_id%22:%223%22,%22sessionId%22:%22V1ZwVFdoY1BRRndEREFZRldsWUNBQUZIQVFNWFEwMENWdzRTUlZoRlJCSmNCRlJRQkFRRlUxRlpWd05iVjFZUEFBY0RVVmNGV2dJS1VBMVJYQVFCVlZ3TkZrWVdBRUFVUXdVQ0ZnNE9WMTllUFVGQVd3QlRVQTVPQkF3VUJ3Tk9DUWtWQmlOVEIwUURlUVlDUkJOVlVXOFhSbFlVYlFvRkJWVUhFMVJUUlFaUVdGNUJQUWhRWEFRSw==%22}&sign=7aa1f4de46060f8d2cb8e0ca17057a41
    public function doTransferExcel(){
        if(is_null($this->param->merchant_app_id) ||
            is_null($this->param->payment_type_id) ||
            is_null($this->param->scenary_id) ||
            is_null($this->param->excel)){
            $this->returnData['message'] = '缺少必要参数!';
            exit(json_encode($this->returnData));
        }
        if($this->param->payment_type_id != 1){
            $this->returnData['message'] = '目前仅支持 支付宝';
            exit(json_encode($this->returnData));
        }
        $data = D('Operate/Excel')->importExcel($this->param->excel, $this->sessionId->merchant_id);

        $makeData = function($data){
            array_shift($data);
            $arr = [];
            foreach($data as $k=>$v){
                if(is_null($data[$k]['B'])||is_null($data[$k]['C'])||is_null($data[$k]['D']))
                    continue;
                $arr[] =  [
                    'subject' => $data[$k]['A'],
                    'rec_account_no' => $data[$k]['B'],
                    'rec_account_name' => $data[$k]['C'],
                    'amount' => $data[$k]['D'],
                    'description' => $data[$k]['E'],
                ];
            }
            return $arr;
        };
        $param = $makeData($data);
//var_dump($param);exit;
        // 支付渠道配置参数
        $paymentInfo = D('PaymentParameterDefine')->getPaymentList($this->param->payment_type_id,$this->param->scenary_id,$this->param->merchant_app_id);
        // 商户相关信息
        $merchantInfo = D('Merchant')->getMerchantInfoByAppId($this->param->merchant_app_id);
        $data = array_merge($paymentInfo, $merchantInfo);
        $data = array_merge((array)$this->param, $data);

        foreach($param as $k => $v){
            $param[$k] = array_merge($v, $data);
        }
//        var_dump($param);exit;
        ///// debug
//        if($this->sessionId->account == '1771033392@qq.com'){
//            var_dump($param);exit;
//        }
        ////
        $this->transfer_request($param);
    }
    // 订单到处到Excel
    public function exportExcel(){
        $data = $this->getList(true);
        // 汉化字段
        if(isset($data[0])){
            $arr = [
                'payment_type_name' => '支付渠道名称',
                'bill_id' => '订单ID',
                'transfer_no' => '转账流水号',
                'pay_request_id' => '翌支付内部ID',
                'created_ts' => '付款时间',
                'modified_ts' => '转账状态更改时间',
                'amount' => '转账金额',
                'description' => '备注',
//                'status_id' => '交易状态码',
//                'payment_type_id' => '支付渠道ID',
//                'se_payment_code' => '商户code',
                'third_trade_no' => '第三方流水号',
                'rec_account_no' => '收款人账号',
                'rec_account_name' => '收款人姓名',
                'status' => '交易状态',
                'enableRefund' => '可否退款(1可以,0不可以)',
                'note' => '不可退款原因',
                'name' => '企业名称',
                'subject'=> '付款主题',
                'batch_no' => '批量付款批次号(仅支付宝批量付款)',
                'pay_account' => '付款账号'
            ];
            foreach($data as $k => $v){
                $new = [];
                foreach($v as $k1=>$v1){
                    if(key_exists($k1, $arr)){
                        $new[$arr[$k1]] = $v1;
                    }
//                    else $new[$k1] = $v1;
                }
                $data2[] = $new;
            }
            $data = $data2;
        }
        return D('Operate/Excel')->exportExcel($data);
    }
    // act=2&method=Transfer&op=getExample&data={%22sessionId%22:%22V1ZwVFdoY1BRRndEREFZRldsWUNBQUZIQVFNWFEwMENWdzRTUlZoRlJCSmNCRlJRQkFRRlUxRlpWd05iVjFZUEFBY0RVVmNGV2dJS1VBMVJYQVFCVlZ3TkZrWVdBRUFVUXdVQ0ZnNE9WMTllUFVGQVd3QlRVQTVPQkF3VUJ3Tk9DUWtWQmlOVEIwUURlUVlDUkJOVlVXOFhSbFlVYlFvRkJWVUhFMVJUUlFaUVdGNUJQUWhRWEFRSw==%22}&sign=7aa1f4de46060f8d2cb8e0ca17057a41
    public function getExample(){
//        $this->returnData['code'] = 200;
//        $this->returnData['message'] = 'success';
//        $this->returnData['data']['url'] =  D('Operate/SysConfig')->TRANSFER_BATCH;
        $ext = end(explode('.', D('Operate/SysConfig')->TRANSFER_BATCH));
        ob_end_clean();//清除缓冲区,避免乱码
        header('pragma:public');
        header('Content-type:application/vnd.ms-excel;charset=utf-8;name="TransferExample.'.$ext.'"');
        header("Content-Disposition:attachment;filename=TransferExample.$ext");//attachment新窗口打印inline本窗口打印
        readfile(D('Operate/SysConfig')->TRANSFER_BATCH);
        exit;
//        exit(json_encode($this->returnData));
    }
    /**
     * 发起转账请求
     * @param        $post
     * @param string $batch 是否为批量
     */
    private function transfer_request($post){
        $transfer_no = [];
        $time = time();
//        var_dump($_SERVER);
//        var_dump(self::$transfer_url);exit;
        foreach($post as $k => $v){
            //1. 组装参数请求
            $params = [
                'app_code' => $v['app_code'],
                'se_payment_code' => $v['se_payment_code'],
                //            'se_private_key' => $post['se_private_key'],
                'rec_account_no' => $v['rec_account_no'],
                'rec_account_name' => $v['rec_account_name'],
                'amount' => $v['amount'],
                'created_ts' => $time,
                'return_url' => '',
                'notify_url' => '',
                'payment_type_id' => $v['payment_type_id'],
                'scenary_id' => $v['scenary_id'],
                'subject'=> isset($v['subject']) ? $v['subject'] : '翌支付商户平台转账',
                'description'=> isset($v['description']) ? $v['description'] : '暂无'
            ];
            $params['se_sign'] = md5(md5($params['app_code'].$params['se_payment_code'].$params['rec_account_no'].$params['amount'].$params['created_ts']).$v['se_private_key']);
//var_dump($params);exit;
            $transfer_no[] = trim($this->curl(self::$transfer_url, $params));
        }
        /**
        array(2) {
        [0]=>
        string(16) "1609130000017082"
        [1]=>
        string(16) "1609130000017083"
        }
         */
        // todo
        ///// debug
//        if($this->sessionId->account == '1771033392@qq.com'){
//            var_dump($transfer_no);exit;
//        }
        ////
//        var_dump($transfer_no);exit;
        if(count($transfer_no)>1) $this->is_batch = true;
        $transfer_no_str = '';
        $sign_str = '';

        foreach($transfer_no as $k => $v){
            $transfer_no_str .='|'.$v;
            if(isset($v) && (empty($v) || !preg_match('/^\w+$/', $v))){
                echo $v;
                exit();
            }
            $sign_str .='|'.md5(md5($post[0]['app_code'].$post[0]['se_payment_code'].$v.$time).$post[0]['se_private_key']);
        }
        $transfer_no_str = ltrim($transfer_no_str,'|');
        $sign_str = ltrim($sign_str,'|');
//        var_dump($sign_str);exit;
        //4. 重新封装转账号请求
        $params2 = [
            'transfer_no'=> $transfer_no_str,
            'se_payment_code'=> $post[0]['se_payment_code'],
            'app_code'=> $post[0]['app_code'],
            'payment_type_id' => $post[0]['payment_type_id'],
            'created_ts' => $time,
            'se_sign' => $sign_str
        ];
//        $params2['payment_type_id'] = $post['payment_type_id'];
//        $params2['se_sign'] = $sign_str;
//        var_dump($params2);
//       exit();
        ///// debug
//                if($this->sessionId->account == '1771033392@qq.com'){
//                    var_dump($params2);exit;
//                }
        ////
        if($this->is_batch)
            header('Location:'.self::$transfer_batch_url.'?'.http_build_query($params2));
        else header('Location:'.self::$transfer_url.'?'.http_build_query($params2));
        exit;
    }
    /**
     * 根据查询条件,
     * @return $this->search
     */
    private function searchSql(){
        $this->search['transfer_request.payment_type_id'] = $this->param->payment_type_id;
        $this->search['transfer_request.auth_app_id'] = $this->param->merchant_app_id;
        //        $this->search['pay_request.merchant_id'] = $this->sessionId->merchant_id;
        if(!is_null($this->param->transfer_no))
            $this->search['transfer_request.transfer_no'] = $this->param->transfer_no;
        if(!is_null($this->param->pay_account))
            $this->search['transfer_request.pay_account'] = $this->param->pay_account;
        // Mysql中针对不定义精度的float类型进行等值查询
        if(!is_null($this->param->amount))
            $this->search['transfer_request.amount'] = ['like',trim($this->param->amount)];
        if(!is_null($this->param->batch_no))
            $this->search['transfer_request.batch_no'] = $this->param->batch_no;
        if(!is_null($this->param->third_trade_no))
            $this->search['transfer_request.third_trade_no'] = $this->param->third_trade_no;
        if(!is_null($this->param->subject))
            $this->search['transfer_request.subject'] = ['like','%'.trim($this->param->subject).'%'];
        if(!is_null($this->param->status))
            $this->search['transfer_request.status_id'] = ['IN', self::$status[$this->param->status]];
        if(!is_null($this->param->rec_account_no))
            $this->search['transfer_request.rec_account_no'] = ['like','%'.trim($this->param->rec_account_no).'%'];
        if(!is_null($this->param->rec_account_name))
            $this->search['transfer_request.rec_account_name'] = ['like','%'.trim($this->param->rec_account_name).'%'];
        if(!is_null($this->param->created_ts_min))
            $this->search['transfer_request.created_ts'][] = array('EGT',$this->param->created_ts_min);
        if(!is_null($this->param->created_ts_max))
            $this->search['transfer_request.created_ts'][] = array('ELT',$this->param->created_ts_max);
        return true;
    }
    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
    /**
     * 数据操作
     * @return $this->returnData
     */
    private function getData($export){
        if($export) $this->limit = '';
        $obj = D('TransferRequest');
        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search);
        $temp = $obj->searchData($this->key, $this->search ,$this->order, $this->limit);
//        echo $obj->getLastSql();exit;
        $this->makeArr($temp);
        $this->returnData['data']['list'] = $temp;
        return true;
    }
    private function makeArr(&$arr){
        if(empty($arr)) return ;
        foreach($arr as $k =>$v){
            foreach(self::$status as $k2 => $v2){
                if(in_array($v['status_id'], $v2)){
                    $arr[$k]['status'] = $k2;
                    continue;
                }
            }
        }
    }
    //

    /**
     * curl请求提交模式
     *
     * @params string 提交地址
     * @params array 需要提交的参数
     *
     * @parmas string 提交方式 post/get
     *         提交到客户端都需要用 sign 签名字段
     */
    private function curl($url, $params = array(), $type = 'POST', $proxy = false){
        $is_ssl = false;
        $port = false;
        if(preg_match('/^(http|https):\/\/([\w\.]+)(:(\d+))?\//', $url, $m)){
            $is_ssl = true;
        }
        else{
            die('curl error['.$type.']: invalid url => '.$url);
        }
        $ch = curl_init();
        if($port){
            curl_setopt($ch, CURLOPT_PORT, $port);
        }
        //指定以非2进制(multipart/form-data)头部格式传送
        $this_header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);
        if(isset($_SERVER['HTTP_USER_AGENT'])){
            curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        }
        $opts = array(CURLOPT_TIMEOUT => 60, CURLOPT_RETURNTRANSFER => 1, //CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $this_header, CURLOPT_ENCODING => 'gzip,deflate',);
        if($is_ssl){
            $opts[ CURLOPT_SSL_VERIFYHOST ] = true;
            $opts[ CURLOPT_SSL_VERIFYPEER ] = false;
        }
        switch( $type ){
            case 'POST' :
                $opts[ CURLOPT_URL ] = $url;
                $opts[ CURLOPT_POST ] = 1;
                $opts[ CURLOPT_POSTFIELDS ] = http_build_query($params); // 貌似这类参数会报错: 'a=1&b=1';
                break;
            case 'GET':
                $get_params_str = '';
                if($params){
                    $get_params_str = '&';
                    if(strpos($url, '?') === false)
                        $get_params_str = '?';
                    $get_params_str = $get_params_str.http_build_query($params);
                }
                $opts[ CURLOPT_URL ] = $url.$get_params_str;
                break;
        }
        //curl请求
        curl_setopt_array($ch, $opts);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        curl_setopt($ch, CURLOPT_URL, $opts[ CURLOPT_URL ]);
        $output = curl_exec($ch);
        $error = curl_error($ch);
        if($error){
            die('curl error['.$type.']: '.$error.' | '.$opts[ CURLOPT_URL ]);
        }
        curl_close($ch);
        return $output;

    }

}
