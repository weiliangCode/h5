<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class AbnormalRequestController extends HomeController{
    // 退款时限 15 天
    static $RefundDay = 15;
    static $status = [
        '处理中' => [1,2,4,6,7,9,10,12,13],
        '失败' => [3,5,8,11,14,16],
        '成功' => [15,17,18]
    ];
    static $AbnormalStatus =  [
        ['abnormal_id'=>'0', 'abnormal_name'=>'其他'],
        ['abnormal_id'=>'1', 'abnormal_name'=>'支付状态正常未收到款'],
        ['abnormal_id'=>'2', 'abnormal_name'=>'退款状态正常未退回客户款项']
    ];
    // 查询条件数组
    private $search = array();
    // 排序标准
    private $order = 'pay_request.created_ts desc';
    private $limit = '';
    // 应用支付渠道管理列表, 需要返回的字段
    private $key = [
        'payment_type.name as payment_type_name',
        'pay_request.bill_id',
        'pay_request.pay_request_id',
        'pay_request.created_ts',
        'pay_request.amount',
        'pay_request.description',
        'pay_request.status_id',
        'pay_request.payment_type_id',
        'pay_request.se_payment_code',
        'pay_request.third_trade_no',
        'pay_request.abnormal_status'
    ];

    public function __construct(){
        parent::__construct();
        self::$RefundDay = D('Operate/SysConfig')->REFUNDDAY;
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
    }
    // 企业门户异常类型查询
    // 返回”异常类型”选项的代号及中文释义
    public function getAbnormalType(){
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = self::$AbnormalStatus;
        exit(json_encode($this->returnData));
    }

    // 企业门户订单的异常报告与查询
    public function reportAbnormal(){
        if(is_null($this->param->pay_request_id)){
            $this->returnData['message'] = '参数不合法, pay_request_id';
            exit(json_encode($this->returnData));
        }
        // 查询
        if(is_null($this->param->abnormal_id) && is_null($this->param->content)){
            $re = $this->returnData['data'] = D('AbnormalRequest')->getAbnormalByPayRequestId($this->param->pay_request_id);
        }
        // 新增
        else{
            $data = [
                'pay_request_id' => $this->param->pay_request_id,
                'apply_user' => $this->sessionId->account,
                'apply_ts' =>  date('Y-m-d',$_SERVER['REQUEST_TIME']),
                'apply_reason' => $this->param->content,
                'abnormal_type' => $this->param->abnormal_id,
                'abnormal_status' => 1
            ];
            $re = D('AbnormalRequest')->createAbnormalWithPayRequestId($data);
        }
        if($re){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));

    }

    // 企业门户异常订单查询(支持搜索)
    //{"act":"2","method":"AbnormalRequest","op":"getList","data":{"merchant_app_id":"1","created_ts":"2016-05-01"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getList($export =false){
        if($this->searchSql() && $this->pageSql() && $this->getData($export) ){
            if($export)  return $this->returnData['data']['list'];
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            exit(json_encode($this->returnData));
        }
    }
    // 订单到处到Excel
    public function exportExcel(){
        $data = $this->getList(true);
        // 汉化字段
        if(isset($data[0])){
            $arr = [
                'payment_type_name' => '支付渠道名称',
                'bill_id' => '订单ID',
                'pay_no' => '支付流水号',
                'pay_request_id' => '翌支付内部ID',
                'created_ts' => '支付时间',
                'amount' => '订单金额',
                'description' => '备注',
//                'status_id' => '交易状态码',
//                'payment_type_id' => '支付渠道ID',
//                'se_payment_code' => '商户code',
                'third_trade_no' => '第三方流水号',
//                'abnormal_status' => '异常状态码',
                'status' => '交易状态',
                'enableRefund' => '可否退款(1可以,0不可以)',
                'note' => '不可退款原因',
                'name' => '企业名称',
            ];
            foreach($data as $k => $v){
                $new = [];
                foreach($v as $k1=>$v1){
                    if(key_exists($k1, $arr)){
                        $new[$arr[$k1]] = $v1;
                    }
//                    else $new[$k1] = $v1;
                }
                $data2[] = $new;
            }
            $data = $data2;
        }
        return D('Operate/Excel')->exportExcel($data);
    }
    /**
     * 根据查询条件,
     * @return $this->search
     */
    private function searchSql(){
        if(is_null($this->param->merchant_app_id)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id';
            exit(json_encode($this->returnData));
        }
        $this->search['pay_request.auth_app_id'] = $this->param->merchant_app_id;
//        $this->search['pay_request.merchant_id'] = $this->sessionId->merchant_id;
        if(!is_null($this->param->bill_id))
            $this->search['pay_request.bill_id'] = $this->param->bill_id;
        if(!is_null($this->param->status))
            $this->search['pay_request.status_id'] = ['IN', self::$status[$this->param->status]];
        if(!is_null($this->param->payment_type_id))
            $this->search['pay_request.payment_type_id'] = $this->param->payment_type_id;
        if(!is_null($this->param->se_payment_code))
            $this->search['pay_request.se_payment_code'] = $this->param->se_payment_code;
        if(!is_null($this->param->amount_min))
            $this->search['pay_request.amount'][] = array('EGT',$this->param->amount_min);
        if(!is_null($this->param->amount_max))
            $this->search['pay_request.amount'][] = array('ELT',$this->param->amount_max);
        if(!is_null($this->param->created_ts_min))
            $this->search['pay_request.created_ts'][] = array('EGT',$this->param->created_ts_min);
        if(!is_null($this->param->created_ts_max))
            $this->search['pay_request.created_ts'][] = array('ELT',$this->param->created_ts_max);
        if(!is_null($this->param->third_trade_no))
            $this->search['pay_request.third_trade_no'] = $this->param->third_trade_no;
        $this->search['pay_request.abnormal_status'] = ['NEQ', 0];
        return true;
    }
    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
    /**
     * 数据操作
     * @return $this->returnData
     */
    private function getData($export){
        if($export) $this->limit = '';
        $obj = D('PayRequest');
        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search);
        $temp = $obj->searchData($this->key, $this->search ,$this->order, $this->limit);
        $this->makeArr($temp);
        $this->returnData['data']['list'] = $temp;
        return true;
    }

    /**
     * 判断订单数据是否符合退款要求,否则给出理由
     */
    private function makeArr(&$temp){
        $obj = D('RefundRequest');
        foreach($temp as $k=>$v){
            $Max_Refund_amount = $v['amount'];
            foreach(self::$status as $k2=>$v2){
                if( in_array($v['status_id'], $v2)){
                    $temp[$k]['status'] = $k2;
                    continue;
                }
            }
            if($temp[$k]['status'] !== '成功'){
                $temp[$k]['enableRefund'] = 0;
                $temp[$k]['note'] = '订单交易'.$temp[$k]['status'];
            }else{
                $re = $obj->getByPayRequest($temp[$k]['pay_request_id']);
                if(is_null($re))
                    $temp[$k]['enableRefund'] = 1;
                else{
                    $status = '状态未识别!';
                    foreach(self::$status as $k3=> $v3){
                        if(in_array($re[0]['status_id'], $v3)){
                            $status = $k3;
                            break;
                        }
                    }
                    if($status == '处理中'){
                        $temp[$k]['enableRefund'] = 0;
                        $temp[$k]['note'] = '上次退款'.$status;
                        continue;
                    }
                    foreach($re as $k3=>$v3){
                        if(in_array($v3['status_id'], self::$status['成功']))
                            $Max_Refund_amount -= $v3['amount'];
                    }
                    if($Max_Refund_amount <= 0){
                        $temp[$k]['enableRefund'] = 0;
                        $temp[$k]['note'] = '已全额退款';
                        continue;
                    }
                    $temp[$k]['enableRefund'] = 1;
                }
                if( ($_SERVER['REQUEST_TIME'] - strtotime($temp[$k]['created_ts'])) > (self::$RefundDay*3600*24) ){
                    $temp[$k]['enableRefund'] = 0;
                    $temp[$k]['note'] = '订单距今已超过'.self::$RefundDay.'天';
                    continue;
                }
            }
        }
    }
}
