<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class AppAccountController extends HomeController{
    //文件传输请求地址
    protected $chinapay_url = 'https://filedownload.95516.com/';
    // 签名证书路径
    const SDK_SIGN_CERT_PATH = 'D:/certs/PRO_898450148160123_acp.pfx';
    //文件下载目录 
    const SDK_FILE_DOWN_PATH = 'D:/file/';   
    const OPENSSL_ALGO_SHA1 = 1;

    public $cert;
    public $certId;
    public $key;

    //微信支付对账请求url
    protected $wechat_url = 'https://api.mch.weixin.qq.com/pay/downloadbill';

	 /**
     * 获取当前应用支持的支付渠道
     * {"act":"2","method":"AppAccount","op":"appPayments","data":{"merchant_app_id":"3"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     */	 
	 public function appPayments()
	 {
	 	//当前应用id
	 	$merchant_app_id = $this->param->merchant_app_id;

	 	$res = D('MerchantPaymentConfig')
            ->join('payment_parameter_define ON merchant_payment_config.para_define_id = payment_parameter_define.para_define_id')
	 		->join('payment_type ON payment_parameter_define.payment_type_id = payment_type.payment_type_id')
            ->field('payment_parameter_define.payment_type_id, payment_type.name')
            ->where('merchant_payment_config.merchant_app_id='.$merchant_app_id)
            ->group('payment_type_id')
            ->select();		

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $res;

        exit(json_encode($this->returnData));
	 }
	 /**
     * 当前支付渠道的日账单
     * {"act":"2","method":"AppAccount","op":"getAppAccount","data":{"merchant_app_id":"3","payment_type_id":"1","bill_date":"20160818"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     */
	 public function getAppAccount()
	 {
	 	//当前应用id
	 	$merchant_app_id = $this->param->merchant_app_id;
        // $merchant_app_id = 3;
	 	//默认支付宝
		$payment_type_id = $this->param->payment_type_id?$this->param->payment_type_id : '1';
        // $payment_type_id = 1; 
        // $start_time = '2016-08-18 00:00:00';//格式必须为这样
        // $end_time = '2016-08-19 00:00:00';
		//微信日期
        // $bill_date = '20160818';
        //银联支付日期
        // $settleDate = '0830';
        //微信
        $bill_date = $this->param->bill_date;
        //银联
        $settleDate = substr($bill_date, 4, 4);
        //支付宝
        $start_time = date('Y-m-d',strtotime($bill_date)).' 00:00:00';
        $end_time = date('Y-m-d',strtotime($bill_date)).' 23:59:59';
         //// 性能测试用 start
//         $data = [
//             [
//                 '性能测试' => '11111',
//                 '性能测试22' => '222'
//             ],
//             [
//                 '性能测试' => '33333',
//                 '性能测试22' => '444'
//             ]
//         ];
//         D('Operate/Excel')->exportExcel($data);
//         exit;
         //// 性能测试用 end

        //获取支付宝对账单
        if($payment_type_id == 1){
            $data = $this->alipayAccount($merchant_app_id, $payment_type_id, $start_time, $end_time);
        }
        //获取银联支付对账单
        if($payment_type_id == 2){
            $data = $this->chinapayAccount($merchant_app_id, $payment_type_id, $settleDate);
        }
        //获取微信支付对账单
        if($payment_type_id == 3){
            $data = $this->wechatAccount($merchant_app_id, $payment_type_id, $bill_date);
        }    

/*        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $data;
        exit(json_encode($this->returnData));*/
	 }
     /**
     * 获取支付宝账单信息（日账单）
     * 
     */
    private function alipayAccount($merchant_app_id, $payment_type_id, $start_time, $end_time)
    {
        //引入支付宝类文件
        $third_lib_path = APP_PATH.MODULE_NAME.'/Lib/AliPay';
        require_once($third_lib_path."/lib/alipay_submit.class.php");       

        //获取配置信息
        $this->config = $this->paymentConfig($merchant_app_id, $payment_type_id);    

        $alipay_config = array();
        $alipay_config['partner'] = trim($this->config['alipay_partner']);
        $alipay_config['key'] = trim($this->config['key']);//安全检验码，以数字和字母组成的32位字符
        $alipay_config['sign_type'] = strtoupper('MD5');//签名方式 不需修改
        $alipay_config['input_charset']= strtolower('utf-8'); //字符编码格式 目前支持 gbk 或 utf-8
       //ca证书路径地址，用于curl中ssl校验 ，请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = $third_lib_path.'/cacert.pem';   
        $alipay_config['transport']    = 'http';//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http

        $page_no = 1;
        //构造要请求的参数数组，无需改动
        $parameter = array(
                "service" => "account.page.query",
                "partner" => trim($this->config ['alipay_partner']),
                "page_no"   => $page_no,
                "gmt_start_time"    => $start_time,
                "gmt_end_time"  => $end_time,
                "_input_charset"    => trim(strtolower('utf-8'))
        );         
        //建立请求
        $alipaySubmit = new \AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestHttp($parameter);
        ////解析XML
        $array_data = json_decode(json_encode(simplexml_load_string($html_text, 'SimpleXMLElement', LIBXML_NOCDATA)), true);       

        if($array_data['is_success']  == 'T')
        {
            $account_page_query_result = $array_data["response"]["account_page_query_result"]["account_log_list"]["AccountQueryAccountLogVO"];
            $arr = [
                'balance' => '余额',
                'buyer_account' => '买家支付宝人民币资金账号',
                'currency' => '货币代码',
                'goods_title' => '商品名称',
                'income' => '收入金额',
                'iw_account_log_id' => '财务序列号',
                'merchant_out_order_no' => '商户订单号',
                'outcome' => '支出金额',
                'partner_id' => '合作者身份ID',
                'rate' => '费率',
                'seller_account' => '卖家支付宝人民币资金账号',
                'seller_fullname' => '卖家姓名',
                'service_fee' => '交易服务费',
                'sign_product_name' => '签约产品',
                'sub_trans_code_msg' => '子业务类型',
                'total_fee' => '交易总金额',
                'trade_no' => '支付宝交易号',
                'trade_refund_amount' => '累积退款金额',
                'trans_code_msg' => '业务类型',
                'trans_date' => '交易付款时间'
            ];

            foreach ($account_page_query_result as $k1 => $v1) {
                unset($account_page_query_result[$k1]['deposit_bank_no']);
                unset($account_page_query_result[$k1]['memo']);
                unset($account_page_query_result[$k1]['service_fee_ratio']);

                    foreach ($v1 as $key => $value) {
                        if(array_key_exists($key, $arr)){
                            $account_page_query_result[$k1][$arr[$key]] = $value;
                            unset($account_page_query_result[$k1][$key]);  
                        }
                    }
            }

            D('Operate/Excel')->exportExcel($account_page_query_result);
        }   

/*        $doc = new \DOMDocument();
        $doc->loadXML($html_text);
        //解析XML
        if( ! empty($doc->getElementsByTagName( "alipay" )->item(0)->nodeValue) ) {
            $alipay = $doc->getElementsByTagName( "alipay" )->item(0)->nodeValue;
            $filename = trim($this->config['alipay_partner']).'_'.date('YmdHis').'_对账单明细'.'.txt';
            ob_end_clean();//清除缓冲区,避免乱码
            header('pragma:public');
            header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$filename);
            header("Content-Disposition:attachment;filename=".$filename);//attachment新窗口打印inline本窗口打印
            file_put_contents ( 'php://output', $alipay );
            exit();            
        }  */    

    }
     /**
     * 获取银联支付账单信息（日账单）
     * 
     */
     private function chinapayAccount($merchant_app_id, $payment_type_id, $date)
     {
        //获取配置信息
        $this->config = $this->paymentConfig($merchant_app_id, $payment_type_id);   

        $params = array(
            'version' => '5.0.0', // 版本号
            'encoding' => 'utf-8', // 编码方式
            'txnType' => '76', // 交易类型
            'signMethod' => '01', // 签名方法
            'txnSubType' => '01', // 交易子类
            'bizType' => '000000', // 业务类型
            'accessType' => '0', // 接入类型
            'fileType' => '00', // 文件类型
            'txnTime' => date('YmdHis'), // 订单发送时间，取北京时间，格式为YYYYMMDDhhmmss，
            'merId' => $this->config['merid'], // 商户代码
            'settleDate' => $date); //清算日期

        // $cert_path = self::SDK_SIGN_CERT_PATH;
        $cert_path = $this->config['SDK_SIGN_CERT_PATH'];
/*        $third_lib_path = APP_PATH.MODULE_NAME.'/Lib/ChinaPay';
        $cert_path = $third_lib_path.'/PRO_898450148160123_acp.pfx'; */
        $cert_pwd = $this->config['SDK_SIGN_CERT_PWD'];
        //签名
        $this->sign($params, $cert_path, $cert_pwd);

        $result_arr = $this->post($params, $this->chinapay_url);

        if($result_arr["respCode"] == "98"){
           /* $this->returnData['message'] = '文件不存在。';
            exit(json_encode($this->returnData));*/
            $message = '文件不存在。';
            $this->assign('message', $message);
            $this->display('no_account');
        }else if ($result_arr["respCode"] != "00") {
           /* $this->returnData['message'] = "失败:respCode=" . $result_arr["respCode"];
            exit(json_encode($this->returnData));*/
            $message = "失败:respCode=" . $result_arr["respCode"];
            $this->assign('message', $message);
            $this->display('no_account');
        }
        //将结果导出
        $this->deCodeFileContent($result_arr);

     }
     /**
     * 获取微信支付账单信息（日账单）
     * 
     */
     private function wechatAccount($merchant_app_id, $payment_type_id, $date)
     {
        //获取配置信息
        $this->config = $this->paymentConfig($merchant_app_id, $payment_type_id);

        //请求参数
        $wechat['appid'] = $this->config['appid'];
        $wechat['mch_id'] = $this->config['mchid'];
        $wechat['nonce_str'] = $this->createNoncestr();//随机字符串
        $wechat['bill_date'] = $date;//对账单日期
        $wechat['bill_type'] = 'ALL';  

        $wechat['sign'] = $this->getSign($wechat);

        $xml = $this->arrayToXml($wechat);   

        $response = $this->postXmlCurl($xml,$this->wechat_url,30);  

        $makeStringToArray = function($response){
            $arr = explode("\r\n",trim($response));
            array_pop($arr);
            array_pop($arr);
            $title = explode(',',$arr[0]);
            unset($arr[0]);
            $content = array_values($arr);
            $c = [];
            foreach($content as $k=>$v){
                $v = trim($v,'`');
                $a = explode(',`',$v);
                $i = 0;
                $new = [];
                foreach($a as $k1=>$v1){
                    $new[$title[$i]] = $v1;

                    $i++;
                }
                $c[] = $new;
            }
            return $c;
        };
        
        D('Operate/Excel')->exportExcel($makeStringToArray($response));

     }
     /**
     * 获取对应支付场景的支付渠道配置信息
     */
     private function paymentConfig($merchant_app_id, $payment_type_id)
     {
        $wmap['merchant_payment_config.merchant_app_id'] = $merchant_app_id;
        $wmap['payment_parameter_define.payment_type_id'] = $payment_type_id;
        $wmap['payment_parameter_define.scenary_id'] = '2';

        $result = D('MerchantPaymentConfig')
            ->join('payment_parameter_define on payment_parameter_define.para_define_id = merchant_payment_config.para_define_id')
            ->field('payment_parameter_define.para_define_id,payment_parameter_define.para_name,merchant_payment_config.para_value')
            ->where($wmap)
            ->select();        
        if(is_array($result))
            {
                //商户渠道配置信息重组
                $merchant_payment_info = array();
                foreach($result as $key=>$val)
                {
                    if(is_array($val))
                    {
                        $merchant_payment_info[$val['para_name']] = $val['para_value'] ;
                    }
                }
                return $merchant_payment_info;
            }
     }
    /**
     *  作用：生成签名
     */
    private function getSign($Obj)
    {
        foreach ($Obj as $k => $v)
        {
            $Parameters[$k] = $v;
        }
        //签名步骤一：按字典序排序参数
        ksort($Parameters);
        $String = $this->formatBizQueryParaMap($Parameters, false);
        // echo '【string1】'.$String.'</br>';
        //签名步骤二：在string后加入KEY
        $String = $String."&key=".$this->config['key'];
        // echo "【string2】".$String."</br>";
        //签名步骤三：MD5加密
        $String = md5($String);
        // echo "【string3】 ".$String."</br>";
        //签名步骤四：所有字符转为大写
        $result_ = strtoupper($String);
        // echo "【result】 ".$result_."</br>";
        return $result_;
    }       
    /**
     *  作用：array转xml
     */
    private function arrayToXml($arr)
    {
        $xml = "<xml>";
        foreach ($arr as $key=>$val)
        {
             if (is_numeric($val))
             {
                $xml.="<".$key.">".$val."</".$key.">"; 

             }
             else
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
        }
        $xml.="</xml>";
        return $xml; 
    }
    /**
     *  作用：产生随机字符串，不长于32位
     */
    private function createNoncestr( $length = 32 ) 
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
        $str ="";
        for ( $i = 0; $i < $length; $i++ )  {  
            $str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
        }  
        return $str;
    }
    /**
     *  作用：以post方式提交xml到对应的接口url
     */
    private function postXmlCurl($xml,$url,$second=30)
    {       
        //初始化curl        
        $ch = curl_init();
        //设置超时
        curl_setopt ( $ch, CURLOPT_TIMEOUT, $second );
        //这里设置代理，如果有的话
        //curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
        //curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
        //设置header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        //要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        //post提交方式
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        //运行curl
        $data = curl_exec($ch);
        
        //返回结果
        if($data)
        {
            curl_close ( $ch );
            return $data;
        }
        else 
        { 
            $error = curl_errno($ch);
            echo "curl出错，错误码:$error"."<br>"; 
            echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
            curl_close($ch);
            return false;
        }
    }      
    /**
     *  作用：格式化参数，签名过程需要使用
     */
    private function formatBizQueryParaMap($paraMap, $urlencode)
    {
        $buff = "";
        ksort($paraMap);
        foreach ($paraMap as $k => $v)
        {
            if($urlencode)
            {
               $v = urlencode($v);
            }
            //$buff .= strtolower($k) . "=" . $v . "&";
            $buff .= $k . "=" . $v . "&";
        }
        $reqPar;
        if (strlen($buff) > 0) 
        {
            $reqPar = substr($buff, 0, strlen($buff)-1);
        }
        return $reqPar;
    }
/*============================================银联支付账单start===============================================*/
    /**
     * 签名
     * @param req 请求要素
     * @param resp 应答要素
     * @return 是否成功
     */
    private function sign(&$params, $cert_path, $cert_pwd){
        $certs = $this->initSignCert($cert_path, $cert_pwd);
        $params ['certId'] = $certs['certId']; //证书ID

        if(isset($params['signature'])){
            unset($params['signature']);
        }
        // 转换成key=val&串
        $params_str = $this->createLinkString($params, true, false );
        $params_sha1x16 = sha1 ( $params_str, FALSE );
        $private_key = $certs['key'];
        // 签名
        $sign_falg = openssl_sign ( $params_sha1x16, $signature, $private_key, self::OPENSSL_ALGO_SHA1);
        if ($sign_falg) {
            $signature_base64 = base64_encode ( $signature );
            // $logger->LogInfo ( "签名串为 >" . $signature_base64 );
            $params ['signature'] = $signature_base64;
        } else {
            // $logger->LogInfo ( ">>>>>签名失败<<<<<<<" );
            echo ">>>>>签名失败<<<<<<<";
        }
    }
    /**
     * 读取证书
     * @param req 请求要素
     * @param resp 应答要素
     * @return 是否成功
     */    
    private function initSignCert($certPath, $certPwd){
        $cert = array();
        $pkcs12certdata = file_get_contents($certPath);
        if($pkcs12certdata === false ){
            echo $certPath . "读取失败。";
        }   
        openssl_pkcs12_read ( $pkcs12certdata, $certs, $certPwd );
        $x509data = $certs ['cert'];

        openssl_x509_read ( $x509data );
        $certdata = openssl_x509_parse ( $x509data );
        $cert['certId'] = $certdata ['serialNumber'];
        $cert['key'] = $certs['pkey'];
        $cert['cert'] = $x509data;

        return $cert;
    }           
    /**
     * 后台交易 HttpClient通信
     *
     * @param unknown_type $params          
     * @param unknown_type $url         
     * @return mixed
     */
     private function post($params, $url) {       
         $opts = $this->createLinkString($params, false, true );    
         $ch = curl_init ();
         curl_setopt ( $ch, CURLOPT_URL, $url );
         curl_setopt ( $ch, CURLOPT_POST, 1 );
         curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false ); // 不验证证书
         curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, false ); // 不验证HOST
         curl_setopt ( $ch, CURLOPT_SSLVERSION, 1 );
         curl_setopt ( $ch, CURLOPT_HTTPHEADER, array (
                'Content-type:application/x-www-form-urlencoded;charset=UTF-8' 
         ) );
         curl_setopt ( $ch, CURLOPT_POSTFIELDS, $opts );
         curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
         $html = curl_exec ( $ch );
        
         if(curl_errno($ch)){
             $errmsg = curl_error($ch);
             curl_close ( $ch );
             exit("请求失败，报错信息>".$errmsg);
             // $logger->LogInfo ( "请求失败，报错信息>" . $errmsg );
             // return null;
         }
         if( curl_getinfo($ch, CURLINFO_HTTP_CODE) != "200"){
            $errmsg = "http状态=" . curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close ( $ch );
            exit("请求失败，报错信息>" . $errmsg);
             // $logger->LogInfo ( "请求失败，报错信息>" . $errmsg );
            // return null;
        }
        curl_close ( $ch );
        $result_arr = $this->convertStringToArray ( $html );
        return $result_arr;
    }
    /**
     * 讲数组转换为string
     *
     * @param $para 数组          
     * @param $sort 是否需要排序          
     * @param $encode 是否需要URL编码         
     * @return string
     */
    private function createLinkString($para, $sort, $encode) {
        if($para == NULL || !is_array($para))
            return "";
        
        $linkString = "";
        if ($sort) {
            $para = $this->argSort ( $para );
        }
        while ( list ( $key, $value ) = each ( $para ) ) {
            if ($encode) {
                $value = urlencode ( $value );
            }
            $linkString .= $key . "=" . $value . "&";
        }
        // 去掉最后一个&字符
        $linkString = substr ( $linkString, 0, count ( $linkString ) - 2 );
        
        return $linkString;
    }
    /**
     * 对数组排序
     *
     * @param $para 排序前的数组
     *          return 排序后的数组
     */
    private function argSort($para) {
        ksort ( $para );
        reset ( $para );
        return $para;
    }     
    /**
     * 字符串转换为 数组
     *
     * @param unknown_type $str
     * @return multitype:unknown
     */
    private function convertStringToArray($str) {
        return $this->parseQString($str);
    }    
    /**
     * key1=value1&key2=value2转array
     * @param $str key1=value1&key2=value2的字符串
     * @param $$needUrlDecode 是否需要解url编码，默认不需要
     */
    private function parseQString($str, $needUrlDecode=false){
        $result = array();
        $len = strlen($str);
        $temp = "";
        $curChar = "";
        $key = "";
        $isKey = true;
        $isOpen = false;
        $openName = "\0";

        for($i=0; $i<$len; $i++){
            $curChar = $str[$i];
            if($isOpen){
                if( $curChar == $openName){
                    $isOpen = false;
                }
                $temp = $temp . $curChar;
            } elseif ($curChar == "{"){
                $isOpen = true;
                $openName = "}";
                $temp = $temp . $curChar;
            } elseif ($curChar == "["){
                $isOpen = true;
                $openName = "]";
                $temp = $temp . $curChar;
            } elseif ($isKey && $curChar == "="){
                $key = $temp;
                $temp = "";
                $isKey = false;
            } elseif ( $curChar == "&" && !$isOpen){
                $this->putKeyValueToDictionary($temp, $isKey, $key, $result, $needUrlDecode);
                $temp = "";
                $isKey = true;
            } else {
                $temp = $temp . $curChar;
            }
        }
        $this->putKeyValueToDictionary($temp, $isKey, $key, $result, $needUrlDecode);
        return $result;
    } 
    private function putKeyValueToDictionary($temp, $isKey, $key, &$result, $needUrlDecode) {
        if ($isKey) {
            $key = $temp;
            if (strlen ( $key ) == 0) {
                return false;
            }
            $result [$key] = "";
        } else {
            if (strlen ( $key ) == 0) {
                return false;
            }
            if ($needUrlDecode)
                $result [$key] = urldecode ( $temp );
            else
                $result [$key] = $temp;
        }
    } 
    /**
     * 处理报文中的文件
     *
     * @param unknown_type $params
     */
    private function deCodeFileContent($params, $fileDirectory=SDK_FILE_DOWN_PATH) {
        if (isset ( $params ['fileContent'] )) {
            $fileContent = $params ['fileContent'];
            if (empty ( $fileContent )) {
                $logger->LogInfo ( '文件内容为空' );
                return false;
            } else {
                // 文件内容 解压缩
                $content = gzuncompress ( base64_decode ( $fileContent ) );
                $filename = $params['fileName'];
                ob_end_clean();//清除缓冲区,避免乱码
                header('pragma:public');
                header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$filename);
                header("Content-Disposition:attachment;filename=".$filename);//attachment新窗口打印inline本窗口打印
                file_put_contents ( 'php://output', $content );
                exit();
/*                 $filePath = null;
               if (empty ( $params ['fileName'] )) {
                    $logger->LogInfo ( "文件名为空" );
                    $filePath = $fileDirectory . $params ['merId'] . '_' . $params ['batchNo'] . '_' . $params ['txnTime'] . '.txt';
                } else {
                    $filePath = $fileDirectory . $params ['fileName'];
                }
                $handle = fopen ( $filePath, "w+" );
                if (! is_writable ( $filePath )) {
                    $logger->LogInfo ( "文件:" . $filePath . "不可写，请检查！" );
                    return false;
                } else {
                    file_put_contents ( $filePath, $content );
                    $logger->LogInfo ( "文件位置 >:" . $filePath );
                }
                fclose ( $handle );*/
            }
        } else {
            return false;
        }
    }
/*============================================银联支付账单end===============================================*/



}