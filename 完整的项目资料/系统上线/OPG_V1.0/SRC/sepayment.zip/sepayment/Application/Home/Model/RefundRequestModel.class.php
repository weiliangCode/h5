<?php
namespace Home\Model;
/**
 * Class PayRequestModel 对应数据表 pay_request
 * @package Operate\Model
 * @author  tengyuan
 */
class RefundRequestModel extends HomeModel {
    public function RefundRequestForm(array $where = array()){
        $re = $this
            ->join('pay_request on refund_request.pay_request_id=pay_request.pay_request_id','right')
            ->join('payment_type on payment_type.payment_type_id=pay_request.payment_type_id','right')
            ->field([
                'pay_request.bill_id',
                'pay_request.pay_request_id',
                'pay_request.scenary_id',
                'pay_request.created_ts',
                'pay_request.payment_type_id',
                'pay_request.status_id',
                'pay_request.amount',
                'payment_type.name as payment_type_name',
                'pay_request.payment_type_id',
                'pay_request.scenary_id',
                'refund_request.status_id as refund_status_id',
                'refund_request.created_ts as last_refund_ts',
                'refund_request.amount as refund_amount'
            ])
            ->where($where)
            ->order('refund_request.created_ts desc')
            ->select();
        return $re;
    }

    public function newRefund(array $data = array()){
        $re = $this
            ->data($data)
            ->add();
        return $re;
    }

    public function getByPayRequest($pay_request_id){
        $re = $this
            ->where([
                'pay_request_id'=>$pay_request_id
            ])
            ->order('refund_request.created_ts desc')
            ->select();
        return $re;
    }
}