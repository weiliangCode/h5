<?php
namespace Home\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team ->test
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
// 支付渠道管理
class PaymenttypeOpController extends HomeController{
    public function paymentsMerchantOp(){
        $payment_type_id = $this->param->payment_type_id;
        if($payment_type_id > 0){
            $d['active_status'] = $this->param->active_status;
            $d['audit_reason'] = $this->param->audit_reason;
            $d['audit_user'] = $this->sessionId->account;
            $d['audit_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            $d['admin_op'] = 0;

            $this->checkStatus($payment_type_id);

            $r = D('MerchantPaymentChannel')->saveData($d, $payment_type_id, $this->sessionId->merchant_id);

            if($r === 0){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '渠道状态保持为 : '.$d['active_status'];
            }else if($r !== false){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '渠道状态更新为 : '.$d['active_status'];
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        exit(json_encode($this->returnData));
    }
    public function paymentsAppOp(){
        $payment_type_id = $this->param->payment_type_id;
        $merchant_app_id = $this->param->merchant_app_id;
        $scenary_id = $this->param->scenary_id;
        if($payment_type_id > 0){
            $d['active_status'] = $this->param->active_status;
            $d['audit_reason'] = $this->param->audit_reason;
            $d['audit_user'] = $this->sessionId->account;
            $d['audit_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            $d['admin_op'] = 0;
            
            $this->checkStatus($payment_type_id);
            $this->checkStatusInMerchant($payment_type_id,$merchant_app_id);

            $r = D('AppPaymentChannel')->saveData($d, $payment_type_id,$merchant_app_id,$scenary_id);

            if($r === 0){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '渠道状态保持为 : '.$d['active_status'];
            }else if($r !== false){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '渠道状态更新为 : '.$d['active_status'];
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 查询渠道在平台上是否可用
     */
    private function checkStatus($payment_type_id){
        $re = D('PaymentType')->where(['payment_type_id'=>$payment_type_id])->find();
        if($re && ($re['active'] == 1)){
            $trs = D('MerchantPaymentChannel')->where([
                'payment_type_id'=>$payment_type_id,
                'merchant_id'=>$this->sessionId->merchant_id
            ])->find();
            if(($trs['admin_op'] == 1) && ($trs['active_status'] != 3)){
                $this->returnData['message'] = '管理员已禁用!';
                exit(json_encode($this->returnData));
            }
        }
        else {
            $this->returnData['message'] = '平台禁止操作!';
            exit(json_encode($this->returnData));
        }
    }

    /**
     * 查询渠道在商户是否已启用
     */
    private function checkStatusInMerchant($payment_type_id, $merchant_app_id){
        $re = D('MerchantPaymentChannel')->where([
            'payment_type_id'=>$payment_type_id,
            'merchant_id'=>$this->sessionId->merchant_id
        ])->find();
        if($re && ($re['active_status'] == 3)){
            $trs = D('AppPaymentChannel')->where([
                'payment_type_id'=>$payment_type_id,
                'merchant_app_id'=> $merchant_app_id
            ])->find();
            if(($trs['admin_op'] == 1) && ($trs['active_status'] != 3)){
                $this->returnData['message'] = '管理员已禁用!';
                exit(json_encode($this->returnData));
            }
        }
        else {
            $this->returnData['message'] = '商户禁止操作!';
            exit(json_encode($this->returnData));
        }
    }
}