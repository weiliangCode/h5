<?php
namespace Home\Controller;
use Think\Controller;
/**
 * SunEEE

 * 象翌微链科技发展有限公司内部的PHP框架

 * Copyright (c) 2015 - 2016, SunEEE 技术

 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任

 * @package     suneee
 * @author      SunEEE PHP Team -> 组员名
 * @interface   接口名称
 * @describe    接口描述
 * @input       借口参数示例
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */

class HomeController extends Controller{
    protected $userTable = 'RegUser';
    /**
     * 当前环境配置
     */
    protected $env_conf = '';

    // 请求参数
    protected $param;

    // 返回数据格式
/*    protected $returnData = array(
        'code' => '0',
        'message' => 'error',
        'data' => array(
            'pages' => array(
                'page_index' => 1,
                'page_size' => 5,
                'total_count' => 11),
            'list' => array()
        ));*/
//
//
//    public function __construct(){
//        parent::__construct();
//        if($_SERVER['REMOTE_ADDR']=='172.19.5.156' || $this->sessionId->account =='1771033392@qq.com'){
//            define('XT',true);
//        }else define('XT',false);
//    }
}