<?php
namespace Home\Controller;

use Home\Controller\HomeController;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package   suneee
 * @author    SunEEE PHP Team ->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version   Version 1.0.0
 */
class RegUserController extends HomeController{
    private $p = false;
    private static $short_message_time = 300;
    public function __construct(){
        parent::__construct();
        self::$short_message_time = D('Operate/SysConfig')->SHORT_MESSAGE_TIME;
    }

    /**
     *  {"act":"2","method":"reg_user","op":"login","data":{"user":"379214301@qq.com","password":"123456"},"sign":"456678wewqesa45d64sa56wqe45"}
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function login(){
        //获取用户名和密码
        $d = array();
        $d['account'] = $this->param->user;
        $d['passwd'] = md5($this->param->password);

        $r = D('RegUser')->verifyUser($d);
//        var_dump($r);exit;
        if($r){
            $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
            D('RegUser')->where($d)->save(['login_ts'=>$time]);
            $r['login_ts'] = $time;
            $r['sessionId'] = $this->getSessionId($d['account'], $r);  //获取用户身份令牌
            unset($r['reg_user_id']);
            // $this->redis->set('userInfo',$r);
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            $this->returnData['data']['list'] = $r;
        }
        echo json_encode($this->returnData);
    }

    /**
     * 注册
     * Enter description here ...
     *  {"act":"2","method":"reg_user","op":"register","data":{"account":"zhuoer@suneee.com","code":"123456"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function register(){
        //获取验证码和邮箱
        $account = $this->param->account;
        $this->p = true;

        $this->check_verify(); // 效验验证码
        // 验证邮箱是否已存在且设置了密码
        D('RegUser');
        // 检查是否初次发送邮件
        $rest = D('RegUser')->where([
            'account'=>$account,
        ])->where('passwd is not null and passwd != ""')
            ->find();
        if($rest){
            $this->returnData['code'] = 0;
            $this->returnData['message'] = '该邮箱已注册';
            exit(json_encode($this->returnData));
        }

        $time = time();
        //DES加密   des（账户名+秘钥）;
        $se_code = \Think\Crypt::encrypt($account.'-'.$time, C('SESSION_ID_KEY'), 0);
        $r = $this->send_register_email($account, $time, $se_code);
        if($r){
            //更新数据库状态
            $d = array();
            $d['account'] = $account;
            $d['reg_ts'] = date('Y-m-d H:i:s',time());
            $user = D('RegUser');
            // 检查是否初次发送邮件
            $rest = $user->where([
                'account'=>$account,
            ])->where('passwd is null or passwd = ""')
                ->find();

            if($rest){
                $res = $user->saveData($d, $account);
            }else
                $res = $user->saveData($d);
            if($res !== false){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }else{
                $this->returnData['code'] = 0;
                $this->returnData['message'] = '邮件发送成功,但数据更新失败';
            }
        }else{
            $this->returnData['code'] = 0;
            $this->returnData['message'] = '邮件发送失败,请稍候重试';
        }

        echo json_encode($this->returnData);
    }

    /**
     * 检测账户是否存在
     * Enter description here ...
     *   {"act":"2","method":"reg_user","op":"accountVerify","data":{"account":"zhuoedr@suneee.com"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function accountVerify(){
        $account = $this->param->account;
        $user = D('RegUser');
        $r = $user->accountVerify($account);

        //如果邮箱不存在/邮箱存在，但是没有设置过密码，返回success
        if(!$r || ($r && empty($r['passwd']))){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '邮箱已经存在';
        }
        echo json_encode($this->returnData);
    }

    /**
     * 设置密码
     * Enter description here ...
     *   {"act":"2","method":"reg_user","op":"setPassword","data":{"account":"zhuoer@suneee.com","passwd":"123456"},"sign":"456678wewqesa45d64sa56wqe45"}

     * @params unkonw $url
     * @params unkonw $data
     */
    public function setPassword(){
        //获取用户名和密码
        $account = \Think\Crypt::decrypt($this->param->account, C('SESSION_ID_KEY'));
        $account = explode('-', $account)[0];
        $passwd = md5($this->param->password);
        $user = D('RegUser');
        $merchant = D('Merchant');
        // 效验 account 为未设置密码的状态
        $check = $user->where([
            'account'=>$account,
        ])->where('passwd is not null and passwd != ""')->find();
        if($check){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            exit(json_encode($this->returnData));
        }
        $user->startTrans();

        //创建新商户
        $dm['name'] = '';
        $dm['is_merchant'] = 1;  //SE支付网关默认账户
        $dm['se_payment_code'] = md5(microtime());//支付code
//        $dm['audit_status'] = 0;
//        $dm['reg_user_id'] = $this->sessionId->reg_user_id;
        $a = $merchant->saveData($dm);
        $merchant_id = $di['merchant_id'] = $merchant->getLastInsID();
        $b = $user->savePasswd($passwd, $account,$merchant_id);

        if($a && $b){
            $user->commit();
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        echo json_encode($this->returnData);
    }

    /**
     * 生成验证码
     *{"act":"2","method":"reg_user","op":"create_verify","data":{},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function create_verify(){
        $Verify = new \Think\Verify();
        //在服务器打开一个缓冲区来保存所有的输出
        ob_start();
        $Verify->entry('',function($code){
            $str = '';
            foreach($code as $v){
                $str .= $v;
            }
            self::$redis->set('create_verify_code'.$_COOKIE['PHPSESSID'],$str,self::$short_message_time);
        },true);
        $r = ob_get_contents();
        ob_clean();
//        var_dump($this->test );exit;
        $data = 'data:image/png;base64,'.base64_encode($r);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['image'] = $data;
        exit(json_encode($this->returnData));
    }

    /**
     * 验证码检测
     * {"act":"2","method":"reg_user","op":"check_verify","data":{},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $id
     */
    public function check_verify(){
        $code = self::$redis->get('create_verify_code'.$_COOKIE['PHPSESSID']);
        if(strtolower($code) != strtolower($this->param->code)){
            $this->returnData['code'] = 0;
            $this->returnData['message'] = '验证码错误 : ';
            exit(json_encode($this->returnData));
        }
        if($this->p !== true){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            echo json_encode($this->returnData);
        }
    }

    /**
     * 发送邮件
     * @return bool
     */
    protected function send_register_email($account, $time, $se_code){
        //检测参数
        if(empty($time) || empty($se_code)){
            echo 'invalid params for send register email!';
            return false;
        }
        $register_mail_config = D('Operate/SysConfig')->REGISTER;
        // 不发送
        if($register_mail_config['active'] != 1) return true;
        //主题
        $subject = $register_mail_config['subject'];
        // 端口号
        $port = D('Operate/SysConfig')->PORT;
        //注册url
        $server = think_server();
        if($server == 'PROD')
            $register_url = 'http://pay.weilian.cn/#/setpw/'.$se_code.'/'.$time;
        else $register_url = 'http://'.$_SERVER['REMOTE_ADDR'].':'.$port.'/#/setpw/'.$se_code.'/'.$time;
        //内容
        $content = $register_mail_config['content'];
        $content = str_replace("{#register_url}",$register_url,$content);

        return $this->send_mail($account, $subject, $content);
    }

    /**
     * 检测账户是否存在
     * Enter description here ...
     * {"act":"2","method":"reg_user","op":"accountForm","data":{"account":"zhuoer@suneee.com","passwd":"123456"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function accVerify($account){
        if(!empty($account)){
            $user = D('RegUser');
            $r = $user->accountVerify($account);
            //如果邮箱存在，返回true
            if($r) return true;
        }
        return false;
    }

    /**
     * 密码重置(发送邮件)
     * Enter description here ...
     *   {"act":"2","method":"reg_user","op":"sendEmail","data":{"account":"zhuoer@suneee.com"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function sendEmail(){
        //首先查看邮箱是否存在
        $account = $this->param->account;
        $r = $this->accVerify($account);

        $se_code = self::$redis->get('se_code'.$account);
        //如果存在，返回true，发送邮件
        if($r){
            //如果已发送邮件，则提示半个小时后重新发送
            if($se_code){
                $this->returnData['code'] = 2212;
                $this->returnData['message'] = '已发送邮件，请半个小时后重试';
                exit(json_encode($this->returnData));
            }
            $time = time();
            //DES加密   des（账户名+秘钥）;
            $se_code = \Think\Crypt::encrypt($account.'-'.$time, C('SESSION_ID_KEY'), 0);
            //生成日期，将code保存
//            S('se_code'.$account,$se_code,D('Operate/SysConfig')->SE_CODE_TIMEOUT);
            $res = $this->send_reset_email($account, $time, $se_code);
            if($res){
                //生成日期，将code保存
                self::$redis->set('se_code'.$account,$se_code,D('Operate/SysConfig')->SE_CODE_TIMEOUT);
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }else{
                $this->returnData['code'] = 0;
                $this->returnData['message'] = '邮件发送失败,请稍后重试!(管理员可能已停用此功能)';
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '邮箱不存在';
        }
        exit(json_encode($this->returnData));
    }
    /**
     * 重置密码邮件
     * @return bool
     */
    protected function send_reset_email($account, $time, $se_code){
        //检测参数
        if(empty($time) || empty($se_code)){
            echo 'invalid params for send register email!';
            return false;
        }
        $mail_config = D('Operate/SysConfig')->RESET;
//        var_dump($mail_config);exit;
        // opg888@suneee.com
        // iK8*290000
        // opg888@suneee.com
        // 不发送
        if($mail_config['active'] != 1) return false;
        //主题
        $subject = $mail_config['subject'];
        // 端口号
        $port = D('Operate/SysConfig')->PORT;
        // 重置url

        $server = think_server();
        if($server == 'PROD')
            $register_url = 'http://pay.weilian.cn/#/setpw/'.$se_code.'/'.$time.'/reset';
        else $reset_url = 'http://'.$_SERVER['SERVER_ADDR'].':'.$port.'/#/setpw/'.$se_code.'/'.$time.'/reset';
        //内容
        $content = $mail_config['content'];
        $content = str_replace("{#reset_url}",$reset_url,$content);
//        var_dump($_SERVER);exit;
        return $this->send_mail($account, $subject, $content);
    }
    /**
     * 修改用户邮箱
     * Enter description here ...
     *   {"act":"2","method":"reg_user","op":"accountChange","data":{"account":"zhuoedr@suneee.com","sessionId":"U2x4WGFoY1NVUk52VVZjTlVFZGRVMElCWFZJSVJqd0lYRjRHRTFoVlZBcE5WMFFJVVZZTlV3RU1BQUJUUkFRR1FSTWJVQWxmUlJKTUFrQkFTZ3NH"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function accountChange()
    {
        $reg_user_id = $this->sessionId->reg_user_id;
        $account = $this->param->account;//新邮箱
        $password = md5($this->param->password);//密码

        //检测该邮箱是否存在,如果邮箱存在，直接返回
        $r = $this->accVerify($account);
        if($r){
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '邮箱已经存在';
            exit(json_encode($this->returnData));
        }
        //检测密码是否错误
        $user = D('RegUser');
        $res = $user->getDataById($reg_user_id);
        if($res['passwd'] != $password){
            $this->returnData['code'] = 2212;
            $this->returnData['message'] = '输入密码错误';
            exit(json_encode($this->returnData));   
        }
        // 删除占用此邮箱 的仅发邮件,未设置密码用户
        D('RegUser')->where([
            'account'=>$account,
        ])->where('passwd is null or passwd = ""')->delete();

        //修改邮箱
        $d['account'] = $account;
        $old_account = $this->sessionId->account;
        $r = $user->saveDataById($d,$reg_user_id);

        // todo 发提示邮件
        $mail_config = D('Operate/SysConfig')->RESET_ACCOUNT;
        // 不发送
        if($mail_config['active'] == 1) {
            //主题
            $subject = $mail_config['subject'];
            //内容
            $content = $mail_config['content'];
            $content = str_replace("{#account}",$account,$content);

            $m = $this->send_mail($old_account, $subject, $content);
        }else $m = true;

        if($r && $m){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 重置密码
     * Enter description here ...
     *   {"act":"2","method":"reg_user","op":"resetPasswrod","data":{"account":"zhuoer@suneee.com","passwd":"111111"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $url
     * @params unkonw $data
     */
    public function resetPasswrod(){
        //获取用户名和密码
        $account = \Think\Crypt::decrypt($this->param->account, C('SESSION_ID_KEY'));
        $account = explode('-', $account)[0];
        $d['passwd'] = md5($this->param->password);

        $user = D('RegUser');
        $r = $user->saveData($d,$account);

        //如果设置成功，返回success
        if($r !== false){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 邮件过期时间检测接口
     * {"act":"2","method":"reg_user","op":"emailVerify","data":{"account":"UWxGRldnY1RkQkpGVmxaVkIwOVRXVjFQQkFkUUMxWlFDMWNEQUE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @params unkonw $id
     */
    public function emailVerify(){
        $account = \Think\Crypt::decrypt($this->param->account, C('SESSION_ID_KEY'));
        $se_time = explode('-', $account)[1];
        //如果用户收到邮件超过有效期，则提示邮件已经过期
//        $timeout = ($this->param->active == 'reg') ? C('REG_EMAIL_TIMEOUT') : D('Operate/SysConfig')->EMAIL_TIMEOUT;
        $timeout = D('Operate/SysConfig')->EMAIL_TIMEOUT;
        if((time() - $se_time) > $timeout){
            $this->returnData['code'] = 0;
            $this->returnData['message'] = '该邮件已经过期，请重新发送邮件';
        }else{
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';            
        }
        exit(json_encode($this->returnData));
    }   

}