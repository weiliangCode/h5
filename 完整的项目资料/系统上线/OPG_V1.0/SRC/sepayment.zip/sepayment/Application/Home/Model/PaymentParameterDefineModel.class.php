<?php
namespace Home\Model;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
class PaymentParameterDefineModel extends HomeModel{
    // 获取支付渠道配置信息
    public function getList($where, $merchant_app_id,$merchant_id, &$update){
        $res = $this
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id="'.$merchant_app_id.'"','LEFT')
            ->where($where)
            ->field(['payment_parameter_define.*','merchant_payment_config.para_value'])
            ->select();
        if(is_null($res[0]['para_value']))
            $update = 0;
        return $res;
    }
    // 获取支付渠道配置信息, 若当前应用没有就查询同商户下的其他应用的配置信息
    public function getListTwo($where, $merchant_app_id,$merchant_id, &$update){
        $res = $this
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id="'.$merchant_app_id.'"','LEFT')
            ->where($where)
            ->field(['payment_parameter_define.*','merchant_payment_config.para_value'])
            ->select();
        // begin 兼容数据库变动,造成的数据无值,从而判断出错的情况
        $t = true;
        foreach($res as $v){
            if(!is_null($v['para_value']))
                $t = false;
        }
        // end
        if($t){
            $update = 0;
            $re = $this
                ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id ','LEFT')
                ->join('merchant_app ON merchant_payment_config.merchant_app_id = merchant_app.merchant_app_id')
                ->where($where)
                ->where([
                    'merchant_app.merchant_id' => $merchant_id
                ])
                ->field([
                    'merchant_app.merchant_app_id',
                    'merchant_payment_config.config_id',
                    'payment_parameter_define.*',
                    'merchant_payment_config.para_value',
                    'merchant_payment_config.modified_ts'
                ])
                ->select();
//                    echo $this->getLastSql();exit;
            $arr = [];
            foreach($re as $k => $v){
                if(!in_array($arr, $v['para_define_id']))
                    $arr[$v['para_define_id']] = $v;
                elseif(strtotime($arr[$v['para_define_id']]['modified_ts']) < $v['modified_ts'] )
                        $arr[$v['para_define_id']] = $v;
            }
            $re = array_values($arr);
        }
        return empty($re) ? $res : $re;
    }
    // TransferController->getAccountWithPayment() 调用
    // 由 merchant_app_id,payment_type_id 查询支持的 scenary_id
    // 目前以scenary_id区分不同付款账户, 以后可以考虑使用name字段(目前测试阶段存在为空的name字段)
    public function getScenaryAndName($merchant_app_id, $payment_type_id){
        $re = $this
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id="'.$merchant_app_id.'"','LEFT')
            ->where([
                'merchant_payment_config.merchant_app_id' => $merchant_app_id,
                'payment_parameter_define.payment_type_id' => $payment_type_id,
                'payment_parameter_define.para_name=\'account\''
            ])
            ->field([
                'payment_parameter_define.scenary_id',
                'merchant_payment_config.para_value as name'
            ])
            ->select();
//        echo $this->getLastSql();exit;
//        foreach($re as $k=>$v){
//            switch($v['scenary_id']){
//                case '1':
//                    $re[$k]['name'] = 'pc账户';
//                    break;
//                case '2':
//                    $re[$k]['name'] = 'web账户';
//                    break;
//                case '3':
//                    $re[$k]['name'] = 'ios账户';
//                    break;
//                case '4':
//                    $re[$k]['name'] = 'android账户';
//                    break;
//            }
//        }
        return is_null($re) ? [] : $re;
    }

    // 获取支付渠道配置信息
    // TransferController->doTransfer() 调用
    public function getPaymentList($payment_type_id, $scenary_id, $merchant_app_id){
        $res = $this
            ->join('merchant_payment_config ON merchant_payment_config.para_define_id=payment_parameter_define.para_define_id AND merchant_payment_config.merchant_app_id="'.$merchant_app_id.'"','LEFT')
            ->where([
                'payment_parameter_define.payment_type_id' => $payment_type_id,
                'payment_parameter_define.scenary_id' => $scenary_id
            ])
            ->field(['payment_parameter_define.*','merchant_payment_config.para_value'])
            ->select();
        $arr = [];
        foreach($res as $k=>$v){
            $arr[$v['para_name']] = $v['para_value'];
        }
        return $arr;
    }
}