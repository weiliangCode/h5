<?php
namespace Operate\Model;
/**
 * Class AbnormalRequestModel 对应数据表 Abnormal_Request
 * @package Operate\Model
 * @author  tengyuan
 */
class AbnormalRequestModel extends OperateModel {
    // 查询存在异常反馈的订单的 反馈信息
    public function getAbnormalByPayRequestId($PayRequestId){
        $re = $this
            ->join('pay_request on pay_request.pay_request_id=abnormal_request.pay_request_id','right')
            ->field('abnormal_request.*')
            ->where([
                'pay_request.pay_request_id' => $PayRequestId,
                'pay_request.abnormal_status' => ['NEQ',0],
            ])
            ->find();
        return $re;
    }
    // 将标记为异常的订单, 进行处理
    public function dealAbnormalWithPayRequestId($data){
        $this->startTrans();
        $a = D('PayRequest')->where([
            'pay_request_id'=> $data['pay_request_id'],
            'abnormal_status'=> 1
        ])->save(['abnormal_status'=>$data['abnormal_status']]);

        $b = $this->where([
            'pay_request_id'=> $data['pay_request_id'],
            'abnormal_status'=> 1
        ])->save($data);
        if( ($a == 1) && ($b == 1)){
            return $this->commit();
        }else $this->rollback();
        return false;
    }
}