<?php
namespace Operate\Model;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
/**
 * 支付渠道参数定义表
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class PaymentParameterDefineModel extends OperateModel{
    /**
     * @param string $merchant_app_id
     * @param string $payment_type_id
     * @param string $scenary_id
     *
     * @return array
     */
    public function getInfo($merchant_app_id='', $payment_type_id='', $scenary_id=''){
        $re = $this
//            ->join('app_payment_channel on payment_parameter_define.payment_type_id=app_payment_channel.payment_type_id and payment_parameter_define.scenary_id=app_payment_channel.scenary_id')
            ->join('merchant_payment_config on merchant_payment_config.para_define_id=payment_parameter_define.para_define_id')
            ->field([
                'payment_parameter_define.para_name',
                'payment_parameter_define.para_type',
                'payment_parameter_define.para_length',
                'payment_parameter_define.input_tips',
                'payment_parameter_define.input_desc',
                'payment_parameter_define.input_desc',
                'merchant_payment_config.para_value'
            ])
            ->where([
                'payment_parameter_define.payment_type_id' => $payment_type_id,
                'payment_parameter_define.scenary_id' => $scenary_id,
                'merchant_payment_config.merchant_app_id' => $merchant_app_id
            ])
            ->select();
//        echo $this->getlastsql();exit;
//        var_dump($re);exit;
//        if(is_array($re))
//            foreach( $re as $k => $v ){
//                $re[$k]['para_value'] = base64_decode($v['para_value']);
//            }
        return $re;
    }
}