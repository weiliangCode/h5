<?php
namespace Operate\Model;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class SysUserModel extends OperateModel {
    /**
     * 验证用户是否存在
     *
     * @params String $account,$passwd
     *
     * @return array/FALSE 当前1行数据
     */

    public function verifyUser($data){
        $wmap['account'] = $data['account'];
        $wmap['passwd'] = $data['passwd'];
        $where['status'] = array('neq', 2); //状态：0 未激活, 1 已经激活, 2 停用
        $result = $this->field('sys_user_id,account,passwd,status,login_ts')->where($wmap)->where($where)->find();
        return $result;
    }
    /**
     * 效验用户sessionId(实现包括 单用户登入,账号密码修改后的退出等)
     * @param $sessionId
     *
     * @return bool
     */
//    public function singleSign($sessionId){
//        $re = $this->where([
//            'account'=>$sessionId->account,
//            'passwd'=>$sessionId->passwd,
//            'status'=>$sessionId->status,
//            'login_ts'=>$sessionId->login_ts
//        ])->find();
//        //        echo $this->getLastSql();
//        return !is_null($re);
//    }
//    public function singleSign($sessionId,$session_id_str){
//        $sessionId_in_redis = self::$cache->get('SESSION'.$sessionId->account);
//        return ($sessionId_in_redis == $session_id_str);
//    }
}