<?php
namespace Operate\Model;
/**
 * Class PayRequestModel 对应数据表 pay_request
 * @package Operate\Model
 * @author  tengyuan
 */
class PayRequestModel extends OperateModel {
    /**
     * 返回数据总数
     * @return int
     */
    public function getCount(array $where = array())
    {
        $re = $this
            ->field('count(*) as a')
            ->join('merchant on pay_request.merchant_id=merchant.merchant_id')
            ->join('payment_type on payment_type.payment_type_id=pay_request.payment_type_id')
            ->where($where)
            ->select();
        return $re[0]['a'];
    }

    /**
     * 根据查询条件,返回2维数组
     * @param array  $key
     * @param array  $where
     * @param string $order
     * @param string $limit
     *
     * @return mixed 2维数组
     */
    public function searchData( array $key = array(), array $where = array(), $order = '',$limit='')
    {
        $re = $this
            ->join('merchant on pay_request.merchant_id=merchant.merchant_id')
            ->join('payment_type on payment_type.payment_type_id=pay_request.payment_type_id')
            ->field($key)
            ->where($where)
            ->limit($limit)
            ->order($order)
            ->select();
//        echo $this->getlastsql();
//        var_dump($re);exit;
        return $re;
    }
}