<?php
namespace Operate\Model;
use Think\Cache\Driver;
use Think\Exception;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class SysConfigModel extends OperateModel{
    private static $config = [];
//    private static $cache = null;
    private $account = '';
//    public function __construct(){
//        parent::__construct();
//        $option = ['expire' => 1];
//        self::$cache = is_object(self::$cache) ? self::$cache :
//            ($_SERVER['SERVER_ADDR'] === '172.16.30.13') ?
//                new Driver\File($option) : new Driver\Redis($option);
//    }
    // 添加 配置项
    public function setSysConfig($par, $value){
        $this->add([
            'config_key'=>$par,
            'config_value'=>serialize($value),
            'apply_user'=>$this->account,
            'modify_ts'=>date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"])
        ]);
        return true;
    }
    // 自动获取操作人
    private function getAccount(){
        if(!$this->account){
            $debug = debug_backtrace();
            $this->account = ($debug[2]['object']->ACCOUNT);
        }
        if(!$this->account) throw new Exception('自动获取操作人失败, 请使用 SysConfigModel->setAccount($account="操作人"),手动指定.');
        return true;
    }
    // 手动指定操作人,保险方法.
    public function setAccount($account){
        $this->account = $account;
        return true;
    }
    private function getByDb($par){
        $re = $this->where([
            'config_key' => $par
        ])
            ->field(['config_value'])
            ->find();
        return is_null($re) ?
            false :
            unserialize($re['config_value']) ?
                unserialize($re['config_value']) :
                $re['config_value'];
    }
    private function getByCache($par){
        if($re = self::$cache->get($par)){
            return $re;
        }else return false;
    }

    /**
     * 按照 进程->缓存->数据库 查找项目
     * @param string $par
     *
     * @return mixed
     * @throws Exception
     */
    public function __get($par){
        if(isset(self::$config[$par]));
        elseif($re = $this->getByCache($par)){
            self::$config[$par] = $re;
        }
        elseif($re = $this->getByDb($par)){
            self::$config[$par] = $re;
            self::$cache->set($par, $re);
        }else throw new Exception('获取的配置项不存在,'.$par);
        return self::$config[$par];
    }

    /**
     * 更新数据库, 更新缓存及进程
     * @param string $par
     * @param mixed  $value
     *
     * @return bool
     */
    public function __set($par, $value){
        $this->getAccount();
        $re = $this->where([
            'config_key'=>$par
        ])->save([
            'config_key'=>$par,
            'config_value'=>serialize($value),
            'apply_user'=>$this->account,
            'modify_ts'=>date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"])
        ]);
        if($re){
            self::$config[$par] = $value;
            self::$cache->set($par, $value);
            return true;
        }else throw new Exception('设置的配置项'.$par.'不存在,或者没有发生改变!');
    }
}