<?php
namespace Operate\Model;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
use Think\Model;

/**
 * 父级模型类
 * 用来初始化环境数据库配置
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class OperateModel extends Model{
    /**
     * 默认 开发环境配置
     * @type string
     */
    protected $connection = 'DB_DEV';

    /**
     * 构造
     */
    public function __construct(){
//        if(isset($_SERVER['SERVER_ADDR'])){
//            switch($_SERVER['SERVER_ADDR']){
//                case '172.16.30.13':
//                    $this->connection = 'DB_DEV';
//                    break;
//                case '172.19.6.115':
//                    $this->connection = 'DB_TEST';
//                    break;
//                default:
//                    $this->connection = 'DB_DEV';
//                    break;
//            }
//        }
        if(isset($_SERVER['OPG_ENV'])){
            $this->connection = 'DB_'.$_SERVER['OPG_ENV'];
        }
        parent::__construct();
    }
}