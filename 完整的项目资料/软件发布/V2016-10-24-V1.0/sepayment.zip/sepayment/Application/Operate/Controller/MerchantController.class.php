<?php
namespace Operate\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package     suneee
 * @author      SunEEE PHP Team -> zhuoer
 * @interface   商户接口
 * @describe    接口描述
 * @input       借口参数示例
 * @copyright   Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version     Version 1.0.0
 */
class MerchantController extends OperateController{

    /**
     * 商户列表查询和会员签约审核列表
     * Enter description here ...
     *  {"act":"1","method":"merchant","op":"merchantList","data":{"page_no":"1","page_size":"3"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function merchantList(){
        $m_mer = D('Merchant');

        //搜索
        $search = array();
        if(!is_null($this->param->merchant_id)){
            if(is_numeric($this->param->merchant_id))
                $search['merchant.merchant_id'] = $this->param->merchant_id;
            else {
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'merchant_id not a number';
                exit(json_encode($this->returnData));
            }
        }
        if(!is_null($this->param->name)){
            $search['merchant.name'] = array('LIKE', '%'.$this->param->name.'%');
        }
        if(!is_null($this->param->account)){
            $search['reg_user.account'] = $this->param->account;
        }
        if(!is_null($this->param->audit_status)){
            if($this->param->audit_status == 0){
                $search['merchant_info.audit_status'] = array('IN', '1,3');
            }else{
                $search['merchant_info.audit_status'] = $this->param->audit_status;
            }
        }
        //排序 当为会员签约审核列表接口时传此参数
        $ser = isset($this->param->order_seq) && $this->param->order_seq == 1 ? 'merchant_info.audit_status ASC, merchant_info.apply_ts DESC' : 'merchant_info.apply_ts DESC';
        // $ser = 'merchant_info.apply_ts DESC';
        $page = intval($this->param->page_no) < 1 ? 1 : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size);
        $pageSize = empty($pageSize) ? 5 : $pageSize;
        $offset = ($page - 1) * $pageSize;

        $data = array();
        //总条数
        $count = $m_mer->getCount($search);

        //商户列表
        $data = $m_mer->getMerchantList($search, $ser, $offset, $pageSize);

        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize, 'total_count' => $count);
        $this->returnData['data']['list'] = $data;

        // $message = json_encode(array('code'=>'200','message'=>'成功','data'=>$array));
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';

        echo json_encode($this->returnData);

    }

    /**
     * 获取商户详情信息
     * {"act":"1","method":"merchant","op":"merchantDetail","data":{"merchant_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $list
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function merchantDetail(){
        $merchant_id = $this->param->merchant_id;

        $m_mer = D('Merchant');
        $merchantDetail = $m_mer->getById($merchant_id);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $merchantDetail;

        echo json_encode($this->returnData);
    }

    /**
     * 会员商户信息编辑
     * {"act":"1","method":"merchant","op":"merchantEdit","data":{"merchant_id":"1","name":"suneee","admin_account":"zhuoer@sunee.com","reg_address":"深圳","work_address":"软件产业基地5e526","lisence_image":"1.png","org_image":"33333.png","contact_mail":"379214306@qq.com"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $list
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function merchantEdit(){
        $merchant_id = $this->param->merchant_id;
        if($merchant_id > 0){
            // 检验是否可以申请审核
            $ress = D('MerchantInfoAction')->where([
                'merchant_id' => $merchant_id,
                'audit_status' => 1,
            ])->find();
            if($ress){
                $this->returnData['message'] = '存在正在审核的资料,无权操作';
                exit(json_encode($this->returnData));
            }

            //更新MerchantInfoAction表
            $di['account'] = $this->param->account;
            $di['merchant_id'] = $merchant_id;
            $di['merchant_name'] = $this->param->name;
            $di['reg_address'] = $this->param->reg_address;
            $di['work_address'] = $this->param->work_address;
            $di['lisence_image'] = $this->param->lisence_image;
            $di['org_image'] = $this->param->org_image;
            $di['contact_mail'] = $this->param->contact_mail;
            $di['contact_name'] = $this->param->contact_name;
            $di['contact_mobile'] = $this->param->contact_mobile;
            $di['apply_user'] = $this->sessionId->account;
            $di['apply_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            $di['audit_status'] = 1;    //1 资料已提交，待审核
            $di['admin_op'] = 1;

            $e = D('MerchantInfoAction')->where([
                'merchant_id' => $merchant_id,
                'admin_op' => 1
            ])->find();
            if($e)
                $res = D('MerchantInfoAction')->data($di)->where('merchant_id="'.$merchant_id.'"')->save();
            else
                $res = D('MerchantInfoAction')->add($di);
            D('MerchantInfoLog')->add($di);
            if($res){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        echo json_encode($this->returnData);
    }

    /**
     * 会员商户信息编辑,检测相关信息是否存在
     * Enter description here ...
     * {"act":"1","method":"merchant","op":"merchantEditVerify","data":{"account":"suneee"},"sign":"456678wewqesa45d64sa56wqe45"}       
     * @params unkonw $url
     * @params unkonw $data
     */
    public function merchantEditVerify()
    {
        $name = $this->param->name;  //企业名称 
        $account = $this->param->account;  //账户名 

        //企业名称检测 
        if(!empty($name))
        {
            $m_mer = D('Merchant');
            $r = $m_mer->nameVerify($name);
            if($r)
            {
                $this->returnData['code'] = 2011;
                $this->returnData['message'] = '该企业名称已经存在';                
            }
            else
            {
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';              
            }
            exit(json_encode($this->returnData));
        }

        //账户名检测
        if(!empty($account))
        {
            $user = D('RegUser');
            $r = $user->accountVerify($account);
            //如果邮箱存在，返回true
            if($r)
            {
                $this->returnData['code'] = 2012;
                $this->returnData['message'] = '该账户名已经存在';                      
            }
            else
            {
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';                      
            }
            exit(json_encode($this->returnData));
        }

    }

    /**
     * 企业会员(商户)签约申请详情接口
     * {"act":"1","method":"merchant","op":"merchantApplyDetail","data":{"merchant_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $list
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function merchantApplyDetail(){
        $merchant_id = $this->param->merchant_id;

        $m_mer = D('Merchant');
        $merchantDetail = $m_mer->getApplyInfo($merchant_id);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $merchantDetail;

        echo json_encode($this->returnData);
    }

    /**
     * 会员(商户)签约审核接口(通过/不通过)
     * {"act":"1","method":"merchant","op":"merchantVerify","data":{"merchant_id":"1","audit_status":"2"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $list
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function merchantVerify(){
        $merchant_id = $this->param->merchant_id;
        if($merchant_id > 0){
            $m_info = D('MerchantInfo');
            $m_info->startTrans();

            $d['audit_reason'] = $this->param->reason;
            $d['audit_status'] = $this->param->audit_status;
            $d['audit_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            $d['audit_user'] = $this->sessionId->account;


            $r = $m_info->saveData($d, $merchant_id);
            if($d['audit_status'] == 2 && $r == 1){
                D('Merchant')->create_Se_Code($merchant_id);
                D('MerchantPaymentChannel')->newMerchannt($merchant_id);
            }
            if($r!==false){
                $rr = D('RegUser')
                    ->join('merchant on merchant.merchant_id=reg_user.merchant_id')
                    ->where([
                        'reg_user.merchant_id'=> $merchant_id,
                    ])
                    ->field([
                        'reg_user.account',
                        'merchant.name as merchant_name',
                    ])
                    ->find();
                if(isset($rr['account'])){
                    $this->send_liveKey_email($rr['account'], $d['audit_status'], $d['audit_reason'],$rr['merchant_name']);
                    $m_info->commit();
                    $this->returnData['code'] = 200;
                    $this->returnData['message'] = 'success';
                }else{
                    $m_info->rollback();
                    $this->returnData['message'] = '未获取到用户邮箱';
                }
            }
            
        }else{
            $this->returnData['code'] = 2211;
            $this->returnData['message'] = '参数错误';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 发送liveKey激活结果邮件
     * @return bool
     */
    private function send_liveKey_email($account, $audit_status,  $reason, $merchant_name){
        $mail_config = ($audit_status == 2) ? 
            D('SysConfig')->LIVEKEY_SUCCESS :
            D('SysConfig')->LIVEKEY_FAIL;
        if($mail_config['active'] != 1) return true;
        $subject = $mail_config['subject'];
        $content = str_replace("{#merchant_name}",$merchant_name,$mail_config['content']);
        $content = str_replace("{#reason}",$reason,$content);

        return $this->send_mail($account, $subject, $content);
    }
}