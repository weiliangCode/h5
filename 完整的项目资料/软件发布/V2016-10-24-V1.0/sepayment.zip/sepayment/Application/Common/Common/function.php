<?php
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

/**
 * 组合签名
 *
 * @params array $params 签名参数
 * @params string/$key  签名密钥
 *
 * @return string/FALSE
 */
function sign($params, $key){
    $str = NULL;
    if(empty($params) || empty($key)){
        return false;
    }
    if(is_array($params)){
        $str = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        $str_array = array('%7E','%21','%2A','%28','%29');
        $replace_array = array('~','!','*','(',')');
        $str = str_replace( $str_array,$replace_array, $str);
        //秘钥组合组合式md5签名
        $str = md5(md5($str).$key);
    }
    return $str;
}

/**
 * 远程curl请求
 * @params unkonw $url
 * @params unkonw $data
 */

function curl_post($url,$data)
{
	if($url && $data)
	{
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, $url);  
        curl_setopt($ch, CURLOPT_POST, 1);        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);            
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);  
        $return = curl_exec($ch); 
        curl_close($ch);

        return $return?$return:false; 
	}
}

/**
 *  判断当前项目所属环境
 */
function think_server(){
    if(isset($_SERVER['SERVER_ADDR'])){
        if(in_array($_SERVER['SERVER_ADDR'], C('SERVER_PROD')))
            return 'PROD';
        if(in_array($_SERVER['SERVER_ADDR'], C('SERVER_TEST')))
            return 'TEST';
        if(in_array($_SERVER['SERVER_ADDR'], C('SERVER_DEV')))
            return 'DEV';
    }
    return 'DEV';
}
 