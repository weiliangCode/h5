<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->zhouer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class MerchantKeyController extends HomeController{
    public function getInfo(){
        $merchant_id = $this->sessionId->merchant_id;
//        $re = D('Merchant')->where(['merchant_id'=>$this->sessionId->merchant_id])->field(['se_payment_code'])->find();
        $re = D('MerchantInfo')
            ->join('merchant ON merchant.merchant_id=merchant_info.merchant_id')
            ->where(['merchant_info.merchant_id'=> $merchant_id])
            ->field(['merchant_info.audit_status','merchant.se_payment_code'])
            ->find();
        if(!$re){
            $this->returnData['code'] = 200;
            $this->returnData['data']['status'] = 0;
            $this->returnData['message'] = 'liveKey资料未提交';
            exit(json_encode($this->returnData));
        }else {
            $this->returnData['data']['se_payment_code'] = $re['se_payment_code'];
            $this->returnData['data']['status'] = $re['audit_status'];
        }

        $de = D('MerchantPaymentKey')->getInfo($merchant_id);
        $this->returnData['data']['se_payment_key'] = isset($de['se_payment_key']) ? $de['se_payment_key'] : '';
        $this->returnData['data']['se_private_key'] = isset($de['se_private_key']) ? $de['se_private_key'] : '';

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }

    public function createKey(){
        $re = D('Merchant')->where(['merchant_id'=>$this->sessionId->merchant_id])->field(['se_payment_code'])->find();
        if(!$re){
            $this->returnData['message'] = '商户未激活!';
            exit(json_encode($this->returnData));
        }

        if(!is_null($this->param->se_payment_key)){
           $se_private_key = \Think\Crypt::paymentKey($this->param->se_payment_key, C('SESSION_ID_KEY'));;
        }

        $data = [
            'merchant_id' => $this->sessionId->merchant_id,
            'se_payment_key' => $this->param->se_payment_key,
            'se_private_key' => $se_private_key,
            'active' => 1,
            'created_ts' => date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] ),
        ];
        $de = D('MerchantPaymentKey')->getInfo($this->sessionId->merchant_id);
        if($de)
            D('MerchantPaymentKey')->data($data)->where(['merchant_id'=>$this->sessionId->merchant_id])->save();
        else D('MerchantPaymentKey')->add($data);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        exit(json_encode($this->returnData));
    }
}