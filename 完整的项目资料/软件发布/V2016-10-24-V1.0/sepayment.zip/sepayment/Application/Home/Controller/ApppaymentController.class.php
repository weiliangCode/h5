<?php
namespace Home\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team ->test
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class ApppaymentController extends HomeController{
    /**
     * 支付渠道信息选择接口
     * {"act":"2","method":"Apppayment","op":"chooseAppPayment","data":{"active":"includeotherinfo","merchant_app_id":"72","payment_type_id":"1","scenary_id":"2","sessionId":"V1ZwVFdoY1BRRndCRHdRQlVsSURCUWxRRUFkV1F4SlBXd3haRTBsWFJCWlBYUTBFVVZFTVVBRmNVVlJRVWdsVkNWVlhWMTlSQmxnTFVGQlFEZ1VEWEY0TEFCTVJGVlVWUlVzT0FVUU5YMUZaREdwSEZROVJVUWxWR1FRSkd3WlZFd2dERUZFZ0FWWVZDM0lGVUVkQ1UxYzlRRUFEUUR3SVhGNERBUjliVWhkYlVWRmJGajVkQlEwTUN3PT0="},"sign":"456678wewqesa45d64sa56wqe45"}     */
    public function chooseAppPayment(){
        if(!is_null($this->param->payment_type_id) && !is_null($this->param->scenary_id) && !is_null($this->param->merchant_app_id)){
            // 区别是否填充其他应用的配置信息
            $func = ($this->param->active == 'includeotherinfo') ? 'getListTwo' : 'getList';
            // 给前端标识 表单提交是 insert or update
            $update = 1;
            $where = [
                'payment_parameter_define.payment_type_id' => $this->param->payment_type_id,
                'payment_parameter_define.scenary_id' => $this->param->scenary_id
            ];
            $r = D('MerchantInfo')->where(['merchant_id'=>$this->sessionId->merchant_id])->field(['contact_mobile'])->find();
            $payment = D('paymentType')->where(['payment_type_id'=>$this->param->payment_type_id])->field(['name'])->find();
            $this->returnData['data']['list'] = D('PaymentParameterDefine')->$func($where,$this->param->merchant_app_id,$this->sessionId->merchant_id,$update );
            $this->returnData['data']['contact_mobile'] = $r['contact_mobile'];
            $this->returnData['data']['payment_type_name'] = $payment['name'];
            $this->returnData['data']['update'] = $update;
            $this->returnData['code'] = 200 ;
            $this->returnData['message'] = 'success' ;
        }
        exit(json_encode($this->returnData));
    }

    //支付渠道信息添加接口
    public function insertAppPayment(){
        if(!is_null($this->param->merchant_app_id) &&
            !is_null($this->param->payment_type_id) &&
            !is_null($this->param->scenary_id) &&
            !is_null($this->param->valueArray) ){
            $obj = D('MerchantPaymentConfig');
            $r = json_decode( json_encode( $this->param->valueArray),true);
            if(empty($r)){
                $this->returnData['code'] = 0;
                $this->returnData['message'] = '此渠道没有可用的配置信息,可能暂未开放';
                exit(json_encode($this->returnData));
            }
            // 查询 ( 应用 ) 可用的支付渠道
//            $this->checkPayment($this->param->merchant_app_id, $this->param->payment_type_id);
            $obj->startTrans();
            // 添加对应的应用管理数据(app_payment_channel)
            $add = D('AppPaymentChannel')->data([
                'merchant_app_id' => $this->param->merchant_app_id,
                'payment_type_id' => $this->param->payment_type_id,
                'scenary_id' => $this->param->scenary_id,
                'active_status' => 3,
                'apply_user' => $this->sessionId->account,
                'audit_user' => 'system',
                'audit_reason' => '商户首次为应用添加支付渠道',
                'audit_ts' => date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"]),
                'apply_ts' => date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"])
            ])->add();
            // 排除
            if($add===false){
                $add = D('AppPaymentChannel')->where([
                    'merchant_app_id' => $this->param->merchant_app_id,
                    'payment_type_id' => $this->param->payment_type_id,
                    'scenary_id' => $this->param->scenary_id
                ])->find();
            }

            $i = 0;
            $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            foreach($this->param->valueArray as $k=>$v){
                $where = [
                    'merchant_app_id' => $this->param->merchant_app_id,
                    'para_define_id' => $k,
                    'created_ts' => $time,
                    'modified_ts' => $time,
                    'para_value' => $v
                ];
                $re = $obj->add_save($where);
                if($re === false)
                    $i ++;
            }
            if(($i===0) && ($add!==false) && $obj->commit()){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }else {
                $obj->rollback();
                $this->returnData['data'] = [
                    $i,$add
                ];
                $this->returnData['message'] = '数据插入出错,请重试!';
            }
        }
        exit(json_encode($this->returnData));
    }

    //支付渠道信息修改接口
    public function updateAppPayment(){
        if(!is_null($this->param->merchant_app_id) &&
            !is_null($this->param->valueArray) ){
            $obj = D('MerchantPaymentConfig');
            $r = json_decode( json_encode( $this->param->valueArray),true);
            if(empty($r)){
                $this->returnData['code'] = 0;
                $this->returnData['message'] = '此渠道没有可用的配置信息,可能暂未开放';
                exit(json_encode($this->returnData));
            }
            // 查询 ( 应用 ) 可用的支付渠道
//            $this->checkPayment($this->param->merchant_app_id, $this->param->payment_type_id);
            $obj->startTrans();
            $i = 0;
            $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
            foreach($this->param->valueArray as $k=>$v){
                $where = [
                    'merchant_app_id' => $this->param->merchant_app_id,
                    'para_define_id' => $k
                ];
                $data = [
                    'modified_ts' => $time,
                    'para_value' => $v
                ];
//                $re = $obj->where($where)->save($data);
                $re = $obj->save_add($where, $data);
//                $where = [
//                    'merchant_app_id' => $this->param->merchant_app_id,
//                    'para_define_id' => $k,
//                    'created_ts' => $time,
//                    'modified_ts' => $time,
//                    'para_value' => $v
//                ];
//                $re = $obj->add($where);
                if($re === false)
//                    echo $obj->getLastSql();exit;
                    $i ++;
            }
            if( ($i===0) && $obj->commit()){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }else $obj->rollback();
        }
        exit(json_encode($this->returnData));
    }

    // 查询 ( 应用 ) 可用的支付渠道
    private function checkPayment($merchant_app_id, $payment_type_id){
        $re = D('PaymentType')
            ->join('merchant_app ON merchant_app.merchant_app_id = "'.$merchant_app_id.'"')
            ->join('merchant_payment_channel ON payment_type.payment_type_id = merchant_payment_channel.payment_type_id AND merchant_payment_channel.merchant_id=merchant_app.merchant_id AND merchant_payment_channel.active_status = 3')
            ->join('app_payment_channel ON payment_type.payment_type_id = app_payment_channel.payment_type_id AND app_payment_channel.merchant_app_id ="'.$this->param->merchant_app_id.'" AND app_payment_channel.active_status = 3','LEFT')
            ->field([
                'payment_type.payment_type_id',
                'payment_type.name',
                'payment_type.code',
                'payment_type.active',
                'payment_type.is_transfer',
                'payment_type.type'
            ])
            ->where([
                'payment_type.active'=>1,
                'payment_type.payment_type_id'=> $payment_type_id
            ])
            ->find();
        if($re) return true;
        else {
            $this->returnData['message'] = '该支付渠道,在当前应用下暂不可用';
            exit(json_encode($this->returnData));
        }
    }
}