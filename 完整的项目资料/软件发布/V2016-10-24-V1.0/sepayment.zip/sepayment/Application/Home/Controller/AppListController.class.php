<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->test
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class AppListController extends HomeController{
    //添加应用
    //{"act":"2","method":"AppList","op":"createAppInfo","data":{"app_name":"yyy","sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function createAppInfo(){
        //插入数据
        $create = array();
        if(is_null($this->param->app_name) || is_null($this->param->app_image) ){
            $this->returnData['message'] = '缺少必要参数 app_name or app_image ';
            exit(json_encode($this->returnData));
        }

        $create['app_name'] = $this->param->app_name;
        {// 同商户下的应用名查重;
            $re = D('MerchantApp')->where([
                'app_name' => $this->param->app_name,
                'status_del' => 0,
                'merchant_id' => $this->sessionId->merchant_id
            ])->find();
            if($re !== null){
                $this->returnData['message'] = '应用名不可以重复';
                exit(json_encode($this->returnData));
            }
        }
        $create['app_image'] = $this->param->app_image;
        if($this->sessionId->merchant_id){
            $create['merchant_id'] = $this->sessionId->merchant_id;
            $create['status_flag'] = 2;
        }
        else $create['merchant_id'] = $this->sessionId->merchant_id;
        $create['apply_date'] = date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"]);
        $create['status_ts'] = date('Y-m-d H:i:s', $_SERVER["REQUEST_TIME"]);
        $create['app_code'] = \Think\Code::code();

        $data = D('MerchantApp')->setCreateData($create);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $data;

        exit(json_encode($this->returnData));
    }

    //应用列表
    //{"act":"2","method":"AppList","op":"getAppInfo","data":{"app_name":"yyy"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getAppInfo(){
        //插入条件
        $merchantId = $this->sessionId->merchant_id;
//        $merchantId = 33;
        $app = D('MerchantApp');
        $this->pageSql();
        //返回数据
        $data = $app->getByMerchantId($merchantId,$this->limit);
        $this->returnData['data']['pages']['total_count'] = D('MerchantApp')->getCount($merchantId);

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        if($this->returnData['data']['pages']['total_count'] == 0)
            $this->returnData['data']['list'] = [];
        else $this->returnData['data']['list'] = $this->makeArr($data);

        exit(json_encode($this->returnData));
    }

    //删除应用
    public function delAppInfo(){
        //获取登录的商户ID值
        $merchantId = $this->sessionId->merchant_id;

        if(!is_null($this->param->merchant_app_id)){
            $where = ['merchant_id' => $merchantId, 'merchant_app_id' => $this->param->merchant_app_id];
            D('MerchantApp')->delApp($where);
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }
    // 我的应用
    //{"act":"2","method":"AppList","op":"getAppById","data":{"merchant_app_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function getAppById(){
        $re = D('MerchantApp')
//            ->join('app_payment_channel on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id AND app_payment_channel.active_status=3', 'LEFT')
//            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id AND payment_type.active=1', 'LEFT')
            ->join('app_payment_channel on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id', 'LEFT')
            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id', 'LEFT')
            ->join('payment_scenary on app_payment_channel.scenary_id=payment_scenary.scenary_id', 'LEFT')
            ->field('app_payment_channel.scenary_id,payment_scenary.name as scenary_name,merchant_app.merchant_app_id,merchant_app.app_code,payment_type.`name` as payment_type_name,payment_type.payment_type_id,merchant_app.app_name,merchant_app.app_image')
            ->where([
                'merchant_app.merchant_app_id'=> $this->param->merchant_app_id,
                'merchant_app.merchant_id'=> $this->sessionId->merchant_id
//                ,'merchant_app.merchant_id'=> 13
            ])
            ->select();
//      var_dump($re);
        $temp = [];
        $payment_type = [];
        foreach($re as $v){
            if($v['payment_type_id'] !== null){
                $temp['payment_type_id'] = $v['payment_type_id'];
                $temp['scenary_id'] = $v['scenary_id'];
                $temp['scenary_name'] = $v['scenary_name'];
                $temp['payment_type_name'] = $v['payment_type_name'];
                $temp['show_name'] = $v['payment_type_name'].$v['scenary_name'];
                foreach($payment_type as $v){
                    if($v == $temp){
                        goto loop;
                    }
                }
                $payment_type[] = $temp;
                loop : ;
            }
        }
        $arr['merchant_app_id'] = $re[0]['merchant_app_id'];
        $arr['app_code'] = $re[0]['app_code'];
        $arr['app_image'] = $re[0]['app_image'];
        $arr['app_name'] = $re[0]['app_name'];
        $arr['payment_type'] = $payment_type;

        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data'] = $arr;
        exit(json_encode($this->returnData));
    }
    // 更改应用名 更改应用信息
    // {"act":"2","method":"AppList","op":"updateName","data":{"merchant_app_id":"1","app_name":"rrrrrrrrrrrrrr"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function updateName(){
        if(is_null($this->param->app_name) || is_null($this->param->app_image)){
            $this->returnData['code'] = 0;
            $this->returnData['message'] = '请输入有效的应用名,logo地址';
            exit(json_encode($this->returnData));
        }
        {// 同商户下的应用名查重;
            $re = D('MerchantApp')->where([
                'app_name' => $this->param->app_name,
                'status_del' => 0,
                'merchant_id' => $this->sessionId->merchant_id
            ])
                ->where('merchant_app_id!="'.$this->param->merchant_app_id.'"')
                ->find();
            if($re !== null){
                $this->returnData['message'] = '应用: '.$this->param->app_name.' 已存在';
                $this->returnData['debug'] =  D('MerchantApp')->getLastSql();
                exit(json_encode($this->returnData));
            }
        }

        $re = D('MerchantApp')
            ->data([
                'app_name'=>$this->param->app_name,
                'app_image'=>$this->param->app_image
            ])
            ->where([
                'merchant_app_id'=> $this->param->merchant_app_id,
                'merchant_id'=> $this->sessionId->merchant_id
            ])
            ->save();
        if($re !== false){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 根据分页条件,拼sql,返回数组[共用模块]
     * @author bingqian tengyuan
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 6);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array('page_index' => $page, 'page_size' => $pageSize);
        return true;
    }
    private function makeArr($arr){
        $obj = D('AppPaymentChannel');
        foreach($arr as $k=>$v){
            $arr[$k]['name'] = $obj->getPaymentsByAppId($v['merchant_app_id']);
        }
        return $arr;
    }
}
