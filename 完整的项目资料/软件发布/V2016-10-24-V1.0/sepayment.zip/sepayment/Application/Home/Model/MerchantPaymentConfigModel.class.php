<?php
namespace Home\Model;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
class MerchantPaymentConfigModel extends HomeModel{
    // 插入不成功 则更新数据
    public function add_save($pars){
        $re = $this->add($pars);
        if(!$re){
            $where = [
                'merchant_app_id' => $pars['merchant_app_id'],
                'para_define_id' => $pars['para_define_id'],
            ];
            $data = [
                'modified_ts' => $pars['modified_ts'],
                'para_value' => $pars['para_value'],
            ];
            $re = $this->where($where)->save($data);
        }
        return $re;
    }
    // 更新不成功 则插入数据
    public function save_add($where , $data){
        $re = $this->where($where)->save($data);
        if(!$re){
            $pars = [
                'merchant_app_id' => $where['merchant_app_id'],
                'para_define_id' => $where['para_define_id'],
                'created_ts' => $data['modified_ts'],
                'modified_ts' => $data['modified_ts'],
                'para_value' => $data['para_value']
            ];
            $re = $this->add($pars);
        }
        return $re;
    }
}