<?php
namespace Home\Model;
/**
 * Class PayRequestModel 对应数据表 pay_request
 * @package Operate\Model
 * @author  tengyuan
 */
class PayRequestModel extends HomeModel {
    public function getOneDayById(array $where = array()){
        $re = $this
            ->join('refund_request on refund_request.pay_request_id=pay_request.pay_request_id','left')
            ->field(['pay_request.pay_request_id,pay_request.status_id','pay_request.amount','refund_request.status_id as refund_status_id','sum(refund_request.amount) as refund_amount'])
            ->where($where)
            ->group('pay_request.pay_request_id')
            ->select();
//        echo $this->getlastsql();
//        var_dump($re);exit;
        return $re;
    }
    public function getInfoByIdEvevyPaymenttype(array $where = array()){
        $re = $this
            ->join('payment_type on payment_type.payment_type_id=pay_request.payment_type_id')
            ->field(['round(sum(pay_request.amount),2) as amount','pay_request.payment_type_id','payment_type.name'])
            ->where($where)
            ->group('pay_request.payment_type_id')
            ->select();
//                echo $this->getlastsql();
        //        var_dump($re);exit;
        return $re;
    }
//    public function getInOneDay($where){
//        $re = $this
//            ->join('payment_type on payment_type.payment_type_id=pay_request.payment_type_id')
//            ->field([
//                'pay_request.bill_id',
//                'pay_request.created_ts',
//                'pay_request.amount',
//                'pay_request.payment_type_id',
//                'pay_request.description',
//                'payment_type.name'
//            ])
//            ->where($where)
//            ->select();
//        //                echo $this->getlastsql();
//        //        var_dump($re);exit;
//        return $re;
//    }

    /**
     * 根据查询条件,返回2维数组
     * @param array  $key
     * @param array  $where
     * @param string $order
     * @param string $limit
     *
     * @return mixed 2维数组
     */
    public function searchData( array $key = array(), array $where = array(), $order = '',$limit=''){
        $re = $this
            ->field($key)
            ->join('payment_type on payment_type.payment_type_id = pay_request.payment_type_id')
            ->where($where)
            ->limit($limit)
            ->order($order)
            ->select();
        //        echo $this->getlastsql();
        //        var_dump($re);exit;
        return $re;
    }
    public function getCount(array $where = array()){
        $re = $this
            ->field('count(*) as a')
            ->join('payment_type on payment_type.payment_type_id = pay_request.payment_type_id')
            ->where($where)
            ->select();
        //        echo $this->getlastsql();
        //        var_dump($re);exit;
        if($re)
            return $re[0]['a'];
        return 0;
    }
}