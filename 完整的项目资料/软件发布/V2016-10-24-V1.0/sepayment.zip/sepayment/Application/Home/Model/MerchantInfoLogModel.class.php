<?php
namespace Home\Model;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class MerchantInfoLogModel extends HomeModel {
    public function getLogByMerchantId($merechant_id, $limit){
        return $this->where(['merchant_id'=>$merechant_id])
            ->limit($limit)
            ->order('apply_ts desc')
            ->select();
    }
    public function getCountByMerchantId($merechant_id){
        $re = $this
            ->field('count(*) as a')
            ->where(['merchant_id'=>$merechant_id])
            ->find();
        return is_null($re) ? 0 : $re['a'];
    }
//    public function updateByMerchantId($merchant_id, $data){
//        return $this
//        ->where([
//            'merchant_info_action.merchant_id'=> $merchant_id
//        ])
//        ->data($data)
//        ->save();
//    }
}