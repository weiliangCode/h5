<?php
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

/**
 * 商户表模型
 * 
 * 用来操作商户信息的表
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
require_once("lib/alipay_core.function.php");
require_once("lib/alipay_rsa.function.php");

class AliPay {
	private $data = "";
    private $AliPay = array();
    const SERVICE = 'mobile.securitypay.pay';   //接口名称
    const CHARSET = 'utf-8';   //参数编码字符集
    const SIGN_TYPE = 'RSA';   //签名方式
    const PAYMENT_TYPE = '1';   //支付类型
    
	public function __construct($data)
	{
		$this->data = $data;
	}	
	/**
	 * 支付
	 */
	public function pay(){
        $payment_type = $this->data['payment_type']['code'];    //支付类型
        $client_type = $this->data['client_type'];               //设备场景
        $pay_merchant_data = $this->data['pay_merchant_data'];             //商户信息
        $pay_request_data = $this->data['pay_request_data'];     //流水数据
        $merchant_payment_info = $this->data['merchant_payment_info'];  //商户配置信息

        // $account_mer_id = $pay_merchant_data['merchant_id'];//商户ID
        $payment_type_id = $this->data['payment_type']['payment_type_id'];//支付类型ID
        $app_id = $this->data['pay_request_data']['auth_app_id'];//应用ID
        $scenary_id = $this->data['pay_request_data']['scenary_id'];//场景I
        $module_url = get_module_url();
		//如果是测试地址，就改为测试域名
		if(strstr($module_url,'172.16.30.13')){
			$module_url = 'http://opgdev.weilian.cn/payment';
		}
		//订单号
		$pay_no = $pay_request_data['pay_no'];
		$subject = $pay_request_data['subject'];
        $body = $pay_request_data['description'];
		//异步回调地址
        $notify_url =  $module_url."/pay/notify_url/se_val/$payment_type_id-$payment_type-$client_type-$app_id-$scenary_id";

        $paras['partner'] =  '"'.trim($merchant_payment_info['alipay_partner']).'"';
        $paras['seller_id'] = '"'.trim($merchant_payment_info['alipay_seller']).'"';
        $paras['out_trade_no'] = '"'.$pay_no.'"';
        $paras['subject'] = '"'.$subject.'"';
        $paras['body'] = '"'.$body.'"';
        $paras['total_fee'] = '"'.$pay_request_data['amount'].'"';
        $paras['notify_url'] = '"'.$notify_url.'"';
        $paras['service'] =  '"'.self::SERVICE.'"';
        $paras['payment_type'] = '"'.self::PAYMENT_TYPE.'"';
        $paras['_input_charset'] = '"'.self::CHARSET.'"';            

        //把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        $prestr = createLinkstring($paras);

        //RSA加密
        // $mysign = rsaSign($prestr, trim($merchant_payment_info['rsa_private_key.pem']));
        $mysign = rsaSign($prestr, dirname(__FILE__).'/key/rsa_private_key.pem');

        $this->AliPay['service'] =  self::SERVICE;
        $this->AliPay['partner'] =  trim($merchant_payment_info['alipay_partner']);
        $this->AliPay['_input_charset'] = self::CHARSET;
        $this->AliPay['notify_url'] = $notify_url;
        $this->AliPay['out_trade_no'] = $pay_no;
        $this->AliPay['subject'] = $subject;
        $this->AliPay['payment_type'] = self::PAYMENT_TYPE;
        $this->AliPay['seller_id'] = trim($merchant_payment_info['alipay_seller']);
        $this->AliPay['total_fee'] = $pay_request_data['amount'];
        $this->AliPay['body'] = $body;
        //签名结果与签名方式加入请求提交参数组中    
        $this->AliPay['sign'] = urlencode($mysign);
        $this->AliPay['sign_type'] = self::SIGN_TYPE;
        
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';   
        $this->returnData['data'] = $this->AliPay;

        echo json_encode($this->returnData);
		exit;		
	}	
	
	public function display_result(){
		
	}



}