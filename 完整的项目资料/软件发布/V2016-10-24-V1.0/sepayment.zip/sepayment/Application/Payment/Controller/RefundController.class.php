<?php
namespace Payment\Controller;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;

/**
 * 退款控制器
 * 
 * 这是退款的入口
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
class RefundController extends PaymentController {
	
	/**
	 * 支付号, 商户第二次回调请求会带支付号过来。
	 * 
	 * @type string
	 */
	protected $pay_no = '';
	
	/**
	 * 支付请求id
	 * 
	 * @type int
	 */
	protected $pay_request_id = '';
	
	/**
	 * 支付类型ID
	 * 
	 * @type int
	 */
	protected $payment_type_id = '';
	
	/**
	 * 退款号, 商户第二次回调退款会带支付号过来。
	 * 
	 * @type string
	 */
	protected $refund_no = '';
	
	/**
	 * 退款请求id
	 * 
	 * @type int
	 */
	protected $refund_request_id = '';	
	
	
	/**
	 * 构造类
	 */
    public function __construct()
    {
        parent::__construct(); 
        $this->param = I('get.') ? I('get.') : I('post.');
    }
    
    /**
     * 退款的入口
     * 
     * a. 商户站点退款请求的入口
     * b. 请求到第三方退款接口
     */
    public function index()
    {
		//1. 检查退款参数合法性
		$this->check_params(true);
		if($this->has_err())
		{ 
			$this->errlog('verify params failed for first refund request');
		}
		//是否返回json格式数据
		$this->use_json = (isset($this->param['use_json']) && $this->param['use_json'] ==1) ? true :false;
		//2.1 如果是第一次请求应该创建退款请求并返回退款号
		if(!$this->refund_no)
		{
			//3. 创建退款请求记录
			$this->create_refund_request();
			
			//4. 返回退款号, 中断程序
			if(!empty($this->refund_no))
			{
				echo $this->refund_no;
				
				exit;
			}
			else
			{
				$this->errlog('create refund request failed');
			}
			
		}
		//2.2 如果是有退款号的请求(第二次)直接进入第三方支付退款页面(商户退款页面)
		else
		{ 
			//3. 这里需要检查当前是否是SE默认账户收款款的商户, 
			//   如果商户是用SE默认账户收款, 则退款需要发送邮件给SE运营人员,并退出
			//   如果商户是自己的账户收款,则退款直接调入下面的4,5的流程进行自行退款.
			//3.1 如果退款是SE账户, 则发送退款邮件
			
			//先接入商户都是有账号的商户，暂注释
/*			if($this->refund_data['is_self_account'] != TRUE && !$this->refund_data['se_refund'])
			{
				$time = time();
				$se_sign = md5($this->refund_data['refund_no'].$time.$this->refund_data['se_payment_key']);
				$r = $this->send_refund_email($this->refund_data['refund_no'], $time, $se_sign);
				if($r)
				{
					//更新发送邮件字段状态
					$rr_m = D('RefundRequest');
					$r1 = array();
					$r1['refund_request_id'] = $this->refund_data['refund_request_id'];
	    			$r1['is_send_email'] = 1;	    			
	    			$r = $rr_m->save_data($r1);

					$this->assign('refund_data', $this->refund_data); 
					//手机
					if(is_mobile()){
						if($this->refund_data['merchant_account_id'] == '2'){
							$this->assign('text','你好, 目前银联支付暂不支持手机版的退款功能！');
							$this->display('wap_warn');							
						}else{
			          		  $this->display('wap_success');
						}
			        //web
			        }else{
			            $this->display('web_success');
			        }					
					
				}
				else
				{
					//碰到发邮件的异常报错
					$this->errlog();
				}
				
				exit;
			}*/
			//3.通知商户的有退款请求
			// $userInfo = D('RegUser')->get_account_by_id($this->refund_data['merchant_id']);
			
			//4. 更新状态为  13, 14  //退款号请求验证成功, 退款号请求验证失败
			$this->update_status('RefundRequest', $this->refund_no, 13, 14);
					
			if($this->has_err())
			{
				$this->errlog('verify params failed for second refund request');
			}				
			
			//5. 请求第三方退款网关
			$this->request_third_refund();
		}
		
		exit;
    }
    
    /**
     * FLOW 校验参数 (该流程校验不会退出程序,只有记录入库后才根据状态去决定是否退出)
     * 
     * a. 如果验证失败则直接返回错误调用到商户站点回调页
     * b. 更新会话记录状态 '11/12 | 13/14', 新增支付请求流水记录状态为'11/12 | 13/14'
     * @and_check_refund  true 判断是否已经退款
     * @return boolean TRUE 继续执行, FALSE 回调告诉错误,并终止逻辑
     */
    protected function check_params($and_check_refund = false)
    {
		//得到退款的配置
		$conf = C('refund');
		//定义配置
		$pconf = '';
		$merchantInfo = '';
		
		//检查是否是第一次退款请求(没有退款号)
		if(!isset($this->param['refund_no']))
		{
			//判断是否已退款
/*			if($and_check_refund){	
				$is_refunded = D('RefundRequest')->get_by_pay_no($this->param['refund_no'],15);
				if(!empty($is_refunded)){
					$this->set_status('INVALID_REFUND_PAY_NO', 'this is refunded of pay_no: ' . $this->param['refund_no']);
					return FALSE;					
				}
				//验证有无账号商户
				// $m_mer = D('Merchant');
				// $merchant_data = $m_mer->get_merchant_pay_data_by_pay_no($p['pay_no']);
				$is_refunded = D('RefundRequest')->get_by_pay_no($this->param['refund_no'],1);
				$is_send_email = $is_refunded[0]['is_send_email'];

				if(!empty($is_refunded) && $is_send_email == TRUE){
			         $this->set_status('REFUND_REQUEST_HAS_BEEN_SENT', 'this is refunded of pay_no: ' . $this->param['refund_no']);
			         return FALSE;				
				}
			}*/

    		//得到返回url,供返回使用
    		$this->return_url = $this->param['return_url'];
 
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payresult'];
    		
			//验证参数的合法性
			$r = $this->verify_all_params($this->param, $pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错
				return FALSE;
			}   
			//验证授权号
			$m_mer = D('Merchant');	
			$pay_data = $m_mer->get_merchant_pay_data_by_pay_no($this->param['pay_no']);

/*			$pay_data['institution_number'] = $p['institution_number'];
			$pay_data['AccountType'] = $p['AccountType'];
			$pay_data['BankID'] = $p['BankID'];
			$pay_data['AccountName'] = $p['AccountName'];
			$pay_data['AccountNumber'] = $p['AccountNumber'];
			$pay_data['BranchName'] = $p['BranchName'];
			$pay_data['Province'] = $p['Province'];
			$pay_data['City'] = $p['City'];*/
			//得到返回url,供返回使用
    		$this->return_url = isset($pay_data['return_url']) ? $pay_data['return_url'] : '';

			if(!isset($pay_data['se_payment_code']) || !isset($pay_data['se_private_key'])
			  || empty($pay_data['se_payment_code']) || $pay_data['se_payment_code']!=$this->param['se_payment_code']
			)
			{
				$this->set_status('INVALID_MERCHANT', 'there is invalid se_payment_code: ' . $this->param['se_payment_code']);
				return FALSE;			
			}

			$payment_type = D('PaymentType')->get_data_by_id($pay_data['payment_type_id']);

			//验证签名
			$se_sign = $this->build_sign($this->param, $pconf, $pay_data['se_private_key']);
			
		    if(!$se_sign || $this->param['se_sign'] != $se_sign)
		    {
		    	$this->set_status('INVALID_SIGN', 'there is invalid sign: ' . $this->param['se_sign']);
		    	return FALSE;
		    }					

	    	//赋值支付数据
	    	$this->pay_data = $pay_data;
			$this->payment_type = $payment_type;

		    //如果验证通过，将商户信息和支付方式加入请求数据当中
			$this->param['merchant_id'] = $this->pay_data['merchant_id'];
			$this->param['payment_type_id'] = $this->pay_data['payment_type_id'];

	    	return TRUE;
	    	
		}
		
		//验证第二次请求(检查包含退款号的请求)
		else
		{
			//赋值退款号给当前类
			$this->refund_no = $this->param['refund_no'];
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payno'];    			

			//验证授权号
			$m_mer = D('Merchant');
			$refund_data = $m_mer->get_merchant_refund_data_by_refund_no($this->param['refund_no']);

			//验证商户以及应用是否存在
			if($refund_data['merchant_id'] && $refund_data['auth_app_id'])
			{
				$this->param['app_code'] = $this->get_app_id(intval($refund_data['auth_app_id']),$refund_data['merchant_id']);
				$this->param['se_payment_code'] = $refund_data['se_payment_code'];

				//获取商户密钥
				$this->pay_merchant_data = $merchantInfo = $this->get_merchant_info($refund_data['se_payment_code']);
				$refund_data['se_private_key'] = $merchantInfo['se_private_key'];
			}
			//验证参数的合法性
			$r = $this->verify_all_params($this->param, $pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错				
				return FALSE;
			} 		

			//中金支付参数
/*			$refund_data['institution_number'] = $this->param['institution_number'];
			$refund_data['AccountType'] = $this->param['AccountType'];
			$refund_data['BankID'] = $this->param['BankID'];
			$refund_data['AccountName'] = $this->param['AccountName'];
			$refund_data['AccountNumber'] = $this->param['AccountNumber'];
			$refund_data['BranchName'] = $this->param['BranchName'];
			$refund_data['Province'] = $this->param['Province'];
			$refund_data['City'] = $this->param['City'];*/

			//得到返回url,供返回使用
    		$this->return_url = isset($refund_data['return_url']) ? $refund_data['return_url'] : '';

			if(!isset($refund_data['se_payment_code']) || !isset($refund_data['se_private_key'])
			  || empty($refund_data['se_payment_code'])
			)
			{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $this->param['se_payment_code'] . '(' . $this->refund_no . ')');
				return FALSE;			
			}

			$se_sign = $this->build_sign($this->param, $pconf, $refund_data['se_private_key']);
	
	    	if(!$se_sign || $this->param['se_sign'] != $se_sign)
	    	{
	    		
	    		//再检查下是否用SE账户退款, 下面是SE账户退款
	    		if(!empty($refund_data['account_mer_id']) && !$refund_data['is_self_account'])
	    		{
	    			//此项时进展SE账户退款流程
	    			$refund_data['se_refund'] = 1;
	    		}
	    		else
	    		{
					$this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $this->param['se_sign'] . '), (' . $this->refund_no . ')');
		    		return FALSE;
	    		}
	    	}
			
			//赋值退款数据
			$this->refund_data = $refund_data;
			$payment_type = D('PaymentType')->get_data_by_id($refund_data['payment_type_id']);
			$this->payment_type = $payment_type;
	    	return TRUE;				
	    	
		}

    }


    //---------------------------------------------------------------------------------------------------------------------------//
    //----------------------------------------------- 回调接口, 支持同步回调,异步回调方法 ---------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    /**
     * 同步回调
     * 
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     * 
     * @return void
     */
	public function return_url($se_val='')
	{
		//分解参数
		if(empty($se_val))
		{
			$this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: ' . json_encode($_GET));
			$this->errlog();			
		}
		
		//分解参数 $account_mer_id-$se_payment_type-$se_client_type
		$params_arr = explode('-', $se_val);
		if(count($params_arr)!=3){
			$this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url' . json_encode($_GET));
			$this->errlog();
		}
		$account_mer_id = $params_arr[0];
		$se_payment_type = $params_arr[1];
		$se_client_type = $params_arr[2];
		//组合账户数据的客户端目录
		$data['merchant_data_path'] = MER_DATA_PATH.$account_mer_id.'/'.$se_payment_type.'/';
		$data['merchant_data_ctype_path'] = $data['merchant_data_path'].$se_client_type.'/';	

		//1. 载入第三方支付接口的回调业务处理类去处理
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';
		$cls = load_pm_lib('payment/'.$se_payment_type.'/'.$se_client_type.'/refund_return_url', FALSE, $data);
		
		//2. 检查回调参数并返回结果的状态联数组
		/*
		return array(
			//SE支付网关退款号
			'refund_no' => 'xxx',			
			//第三方退款批次号
			'third_batch_no' => 'xxx',	
			//第三方需求自定义批次号 (如果没有 refund_no 和 third_batch_no 的返回值,此值一定需要返回.)
			'batch_no' => 'xxx',					
			//SE支付网关的状态 
			'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
			//SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
			'status_msg' => '签名错误'
		);
		*/
		$this->result = $cls->check_params();
		$this->check_third_return_val($this->result);
		
		//3. 更新状态和返回第三方退款批次号结果
		//3.1 如果有批次号返回,则以批次号为准更新当前状态
		$refund_no = $this->result['refund_no'];
		$refund_data = '';
		if(!empty($this->result['refund_no'])){
			$update_data['third_batch_no'] = isset($this->result['third_batch_no']) ? $this->result['third_batch_no'] : '';
			$this->update_status('RefundRequest', $refund_no, 31, 32, $update_data);		
			$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);
		}else
		//3.2 如果是自定义批次号,则以自定义批次号为准更新当前状态
		if(!empty($this->result['batch_no'])){
			$batch_no = $this->result['batch_no'];
			$refund_data = D('RefundRequest')->get_by_batch_no($batch_no);
			$refund_no = $refund_data['refund_no'];
			if($refund_data)
			{
				$this->update_status('RefundRequest', $refund_data['refund_no'], 31, 32, $update_data);		
			}	
		}
		
		//4. 如果有错误,则返回到错误页面
		if($this->has_err())
		{
			//在SE支付平台显示错误信息	
			if(empty($refund_data) || !isset($refund_data['return_url']) || empty($refund_data['return_url']))
			{
				$this->errlog();
			}
			//把错误信息返回到第三方平台
			else
			{
				$this->refund_data = $refund_data;
				$return_result = $this->get_return_result();
				header('Location:'.$refund_data['return_url'].'?'.http_build_query($return_result));				
			}
			exit;			
		}		

		//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
		$result = $cls->notify_result();
		$this->check_third_return_val($result);
		$this->update_status('RefundRequest', $refund_no, 51, 52);		
		
		//6. 回调商户的同步回调return_url
		//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
		
		if( !isset($refund_data['return_url']) || empty($refund_data['return_url']) )
		{
			$this->assign('refund_data', $refund_data);
			if(is_mobile()){
	            $this->display('wap_success');
	        }else{
	            $this->display('web_success');         
	        }
			exit;
		}
		//6.2 如果商户有回调url,则调用回调url		
		else
		{
			$this->refund_data = $refund_data;
			$return_result = $this->get_return_result();
			header('Location:'.$refund_data['return_url'].'?'.http_build_query($return_result));			
		}

	}
	
    /**
     * 异步回调
     * 
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     * 
     * @return void
     */
	public function notify_url($se_val='')
	{
		//分解参数
		if(empty($se_val))
		{
			$this->set_status('EMPTY_PARAMS', 'there is an empty params for notify_url: ' . json_encode($_GET));
			$this->errlog();			
		}
		
		//分解参数 $account_mer_id-$se_payment_type-$se_client_type
		$params_arr = explode('-', $se_val);
		if(count($params_arr)!=5){
			$this->set_status('INVALID_PARAMS', 'there is an invalid params for notify_url' . json_encode($_GET));
			$this->errlog();
		}
		$payment_type_id = $params_arr[0];
		$se_payment_type = $params_arr[1];
		$se_client_type = $params_arr[2];
		$app_id = $params_arr[3];
		$scenary_id = $params_arr[4];
		//组合账户数据的客户端目录
		// $data['merchant_data_path'] = MER_DATA_PATH.$account_mer_id.'/'.$se_payment_type.'/';
		// $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$se_client_type.'/';	
		// 获取商户支付配置信息
		$data['merchant_payment_info'] = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($scenary_id,$app_id,$payment_type_id); 
		//1. 载入第三方支付接口的回调业务处理类去处理
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';

		// $cls = load_pm_lib('payment/'.$se_payment_type.'/'.$se_client_type.'/refund_notify_url', FALSE, $data);
		$cls = load_pm_lib($data['third_lib_path'].'refund_notify_url', FALSE, $data);

		//2. 检查回调参数并返回结果的状态联数组
		/*
		return array(
			//SE支付网关退款号
			'refund_no' => 'xxx',			
			//第三方退款批次号
			'third_batch_no' => 'xxx',	
			//第三方需求自定义批次号 (如果没有 refund_no 和 third_batch_no 的返回值,此值一定需要返回.)
			'batch_no' => 'xxx',					
			//SE支付网关的状态 
			'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
			//SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
			'status_msg' => '签名错误'
		);
		*/
		$this->result = $cls->check_params();
		$this->check_third_return_val($this->result);

		//3更新状态和返回第三方退款批次号结果
		//3.1 如果有批次号返回,则以批次号为准更新当前状态
		$refund_no = $this->result['refund_no'];
		$refund_data = '';
		if(!empty($this->result['refund_no'])){
			$update_data['third_batch_no'] = isset($this->result['third_batch_no']) ? $this->result['third_batch_no'] : '';
			$update_data['batch_no'] = isset($this->result['batch_no']) ? $this->result['batch_no'] : '';
			$this->update_status('RefundRequest', $refund_no, 31, 32, $update_data);		
			$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);
		}else
		//3.2 如果是自定义批次号,则以自定义批次号为准更新当前状态
		if(!empty($this->result['batch_no'])){
			$update_data['third_batch_no'] = isset($this->result['third_batch_no']) ? $this->result['third_batch_no'] : '';
			$batch_no = $this->result['batch_no'];
			$refund_data = D('RefundRequest')->get_by_batch_no($batch_no);
			$refund_no = $refund_data['refund_no'];
			if($refund_data)
			{
				$this->update_status('RefundRequest', $refund_data['refund_no'], 31, 32, $update_data);		
			}	
		}

		//4. 如果有错误,则返回到错误页面
		if($this->has_err())
		{
			//在SE支付平台显示错误信息	
			if(empty($refund_data) || !isset($refund_data['notify_url']) || empty($refund_data['notify_url']))
			{
				//$this->errlog();
				exit;
			}
			//把错误信息返回到第三方平台
			else
			{
				$this->refund_data = $refund_data;
				$return_result = $this->get_return_result();
				header('Location:'.$refund_data['notify_url'].'?'.http_build_query($return_result));				
			}
			exit;			
		}		

		//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
		$result = $cls->notify_result();
		$this->check_third_return_val($result);
		$this->update_status('RefundRequest', $refund_no, 51, 52);		

		//6. 回调商户的同步回调return_url
		//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
		$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);	
	
		if(!isset($refund_data['notify_url']) || empty($refund_data['notify_url']))
		{
			exit;
		}
		//6.2 如果商户有回调url,则调用回调url		
		else
		{
			$this->refund_data = $refund_data;
			$return_result = $this->get_return_result();
			header('Location:'.$refund_data['notify_url'].'?'.http_build_query($return_result));			
		}
	}
    
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 ------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    
    /**
     * 创建第一次退款请求 (带refund_no的退款请求)
     * 
     * @return void
     */
    protected function create_refund_request()
    {
    	//创建退款流水
    	if($this->param)
    	{
			//初始状态模型类
			$m_status = D('Status');
			$m_request = D('RefundRequest');   
			
			//组装流水参数
			$refundRequest = array();
			$refundRequest['refund_request_id'] = '';
			$refundRequest['refund_no'] = '';
			$refundRequest['pay_request_id'] = $this->pay_data['pay_request_id'];
			$refundRequest['description'] = $this->param['description'];
			$refundRequest['return_url']	= $this->param['return_url'];	
			$refundRequest['notify_url']	= $this->param['notify_url'];
			$refundRequest['status_id'] = $m_status->get_status_id('10');	//初始状态
			$refundRequest['currency_code'] = (isset($this->param['currency_code']) && !empty($this->param['notify_url'])) ? $this->param['currency_code'] : 'CNY';
			$refundRequest['amount'] = $this->param['amount'];
			$refundRequest['created_ts'] = date('Y-m-d H:i:s');
			$refundRequest['modified_ts'] = date('Y-m-d H:i:s');
			$refundRequest['merchant_id'] = $this->param['merchant_id']; //商户ID
			$refundRequest['payment_type_id'] = $this->param['payment_type_id'];  //支付类型ID
			$refundRequest['scenary_id'] = $this->pay_data['scenary_id'];  //支付类型ID
			$refundRequest['auth_app_id'] = $this->get_app_id($this->param['app_code'],$refundRequest['merchant_id']);  //获取应用ID
			
			//新增状态流水表
			if($m_request->save_data($refundRequest))
			{
				//取到当前自增ID值
				$refundRequest['refund_request_id'] = $m_request->getLastInsID();
				//组装流水号
				$refundRequest['refund_no'] = $this->refund_no = $this->get_idno($refundRequest['refund_request_id'], C('refund_no_prefix'));
				//更新流水表，插入流水号
				$result = $m_request->save_data(array('refund_request_id'=>$refundRequest['refund_request_id'],'refund_no'=>$this->refund_no));

				if($result)
				{
					self::$redis->set("{$this->refund_no}_request",$refundRequest);
					//插入流水状态表记录
					D('RefundRequestFlow')->save_data(array('refund_request_id'=>$refundRequest['refund_request_id'],'status_id'=>$refundRequest['status_id'],'created_ts'=>date('Y-m-d H:i:s')));					
					//如果是标准API返回形式
					if($this->use_json)
					{
					    $this->returnData['code'] = 200;
				        $this->returnData['message'] = 'success';   
				        $this->returnData['data']['refund_no'] = $this->refund_no;
				        exit(json_encode($this->returnData));
					}
					return $result;				
				}
			}

    	}

    	return FALSE;
    }     

    /**
     * 请求第三方退款
     * 
     * @return void
     */    
    protected function request_third_refund()
    {
    	if($this->param)
    	{
    		if($this->pay_merchant_data)
    		{
    			//获取场景
				// $scene = checkScene();
    			// $scene = 'WAP';
				$merchant_app_id = $this->get_app_id($this->param['app_code'],$this->pay_merchant_data['merchant_id']);
				//获取对应支付场景的支付渠道配置信息
/*                if(isset($this->param['scenary_id']) && !empty($this->param['scenary_id']))
                    $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($this->param['scenary_id'],$merchant_app_id,$this->refund_data['payment_type_id']);
                else
                    $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info($scene,$merchant_app_id,$this->refund_data['payment_type_id']);*/
                $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($this->refund_data['scenary_id'],$merchant_app_id,$this->refund_data['payment_type_id']);    
     
				if($merchant_payment_info)
				{
					// $scene = $this->get_scene_type($scene);
					$scene = $this->get_scene_type($this->refund_data['scenary_id']);
					//组装交易参数
					$refundData = array();
					$refundData['payment_type'] = $this->payment_type;  //支付渠道类型信息
					$refundData['client_type'] = $scene;                   //支付场景
					$refundData['pay_merchant_data'] = $this->pay_merchant_data;      //商户信息
					$refundData['refund_request_data'] = $this->refund_data; //支付流水
					$refundData['merchant_payment_info'] = $merchant_payment_info;  //商户支付配置信息

					//加载指定第三方支付类
					$cls = load_pm_lib("payment/{$this->payment_type['code']}/{$scene}/{$this->payment_type['code']}", FALSE, $refundData);

					//2.1  检查是否退款禁止
					if(method_exists($cls, 'disabled_refund'))
					{
						$res = $cls->disabled_refund();
						$is_disabled = (isset($res['result']) && $res['result']) ? $res['result'] : FALSE;
						$text = isset($res['text']) ? $res['text'] : FALSE;
						if($is_disabled)
						{
							if($data['client_type'] == 'wap')
							{
								$this->assign('text', $text);
								$this->display('Refund/wap_warn');
							}
							else
							{
								$this->display('Refund/web_warn');
							}
							exit;
						}
					}

					//2.2 如果第三方需要自定义格式的退款批次号,则生成批次号号
					if(method_exists($cls, 'create_refund_batch_no'))
					{
						$batch_no = $cls->create_refund_batch_no();
						$is_err = false;
						$n = 0;
						//最多5次生成,如果还有重复则报错!
						while(D('RefundRequest')->get_by_batch_no($batch_no))
						{
							$batch_no = $cls->create_refund_batch_no();
							++$n;
							if($n==5)
							{
								$is_err = true;
								break;
							}
						}
						
						if($is_err)
						{
							$this->set_status('INVALID_PARAMS', 'duplicate batch_no');
							$this->errlog();
						}
						else
						{
							//保存批次号
							$d['batch_no'] = $batch_no;
							$d['refund_request_id'] = $this->refund_data['refund_request_id'];
							$r = D('RefundRequest')->save_data($d);
							if(!$r)
							{
								$this->set_status('INVALID_PARAMS', 'save new batch_no failed');
								$this->errlog();					
							}
						}
					}

					//2.3 检查回调参数并返回结果的状态联数组		
					$this->result = $cls->refund();
					$this->check_third_return_val($this->result);					

					//3更新状态和返回第三方退款批次号结果
					//3.1 如果有批次号返回,则以批次号为准更新当前状态
					$refund_no = $this->result['refund_no'];
					$refund_data = '';
					if(!empty($this->result['refund_no'])){
						$update_data['third_batch_no'] = isset($this->result['third_batch_no']) ? $this->result['third_batch_no'] : '';
						$this->update_status('RefundRequest', $refund_no, 31, 32, $update_data);		
						$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);
					}else
					//3.2 如果是自定义批次号,则以自定义批次号为准更新当前状态
					if(!empty($this->result['batch_no'])){
						$batch_no = $this->result['batch_no'];
						$refund_data = D('RefundRequest')->get_by_batch_no($batch_no);
						$refund_no = $refund_data['refund_no'];
						if($refund_data)
						{
							$this->update_status('RefundRequest', $refund_data['refund_no'], 31, 32);		
						}	
					}		
				
					//4. 如果有错误,则返回到错误页面
					if($this->has_err())
					{
						//在SE支付平台显示错误信息	
						if(empty($refund_data) || !isset($refund_data['return_url']) || empty($refund_data['return_url']))
						{
							$this->errlog();
						}
						//把错误信息返回到第三方平台
						else
						{
							$this->refund_data = $refund_data;
							$return_result = $this->get_return_result();
							header('Location:'.$refund_data['return_url'].'?'.http_build_query($return_result));				
						}
						exit;
					}
					
					//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
					$result = $cls->notify_result();
					$this->check_third_return_val($result);
					$this->update_status('RefundRequest', $refund_no, 51, 52);		
				
					//6. 回调商户的同步回调return_url
					//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
					$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);	
					if(!isset($refund_data['return_url']) || empty($refund_data['return_url']))
					{
					    //返回json形式数据
						if($this->use_json)
						{
						    $this->returnData['code'] = ($this->status == TRUE) ? 200 : 0;
					        $this->returnData['message'] = 'success';   
					        $this->returnData['data']['refund_no'] = $refund_no;
					        exit(json_encode($this->returnData));				
			            }

						$this->assign('refund_data', $refund_data);
						if(is_mobile()){
				            $this->display('wap_success');
				        }else{
				            $this->display('web_success');         
				        }
						exit;
					}
					//6.2 如果商户有回调url,则调用回调url		
					else
					{
						$this->refund_data = $refund_data;
						$return_result = $this->get_return_result();
						header('Location:'.$refund_data['return_url'].'?'.http_build_query($return_result));			
					}										
				}                
    		}
    	}

    }    
    

    public function test()
    {

		$cls = load_pm_lib('payment/WeChatPay/web/WeChatPay', FALSE, $data="");

		$cls->display_result($this);
		
    } 

    /**
     * 得到返回结果
     * 
     * @return Array 
     */
    protected function get_return_result()
    {
    	$params = array(
    		'se_payment_code' => $this->refund_data['se_payment_code'],
			'refund_no'=> $this->refund_data['refund_no'], 
			'amonut'=> $this->refund_data['amonut'], 
			'created_ts' => time(),
			'result' => $this->status
		);
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['created_ts']).$this->refund_data['se_payment_key']);
		unset($params['se_payment_code']);
		
		return $params;
    }


	/**
	 * 退款申请页面
	 * 
	 * @params string $se_val = $refund_no-".$time."-$se_sign
	 * 
	 * 使用场景: 发送退款邮件申请的时候才能
	 */
	public function refund_application($se_val='')
	{
		
		//检查参数是否为空
		if(empty($se_val))
		{
			die('Illegal access1');
		}
		
		list($refund_no, $time, $se_sign) = explode('-', $se_val);
		
		//检查参数格式是否正确
		if(empty($refund_no) || empty($time) || empty($se_sign))
		{
			die('Illegal access2');
		}
		
		//检查是否过期(设置一天过期)
		if(time()-$time>86400)
		{
			die('Illegal access3');
		}
		
		//检查是否有refund_token, 有则进入退款页面, 否则进入SE的申请退款页面, refund_token 超时为10分钟内
		if(isset($_POST['refund_token']) && (time()-$_POST['refund_token']>600))	
		{
			die('Illegal access4');
		}
		
		$refund_data = D('Merchant')->get_merchant_refund_data_by_refund_no($refund_no);
		
		//检查时候有合法的退款号
		if(empty($refund_no) || empty($se_sign))
		{
			die('Illegal access5');
		}

		//检查当前的退款签名
		if(md5($refund_no.$time.$refund_data['se_payment_key']) !== $se_sign)
		{
			die('Illegal access6');
		}
		
		//检查是否有refund_token, 有则进入退款页面, 否则进入SE的申请退款页面
		if(isset($_POST['refund_token']))
		{
			//获取当前SE平台的账户
			$mer_info = D('Merchant')->get_by_id($refund_data['account_mer_id']);
			
			if(!$mer_info)
			{
				die('Refund failed!');
			}
			
    		// 重新封装退款号请求
    		$params = array(
    			'se_payment_code' => $mer_info['se_payment_code'],
				'refund_no'=>$refund_no,
            	//'is_embed'=>true, //是否嵌入式载入方式
				'created_ts' => time()
			);
    		$params['institution_number'] = $post['institution_number']; 
    		$params['AccountType'] = $post['AccountType']; 
    		$params['BankID'] = $post['BankID'];
    		$params['AccountName'] = $post['AccountName'];
    		$params['AccountNumber'] = $post['AccountNumber'];
    		$params['BranchName'] = $post['BranchName'];
    		$params['Province'] = $post['Province'];
    		$params['City'] = $post['City'];
			$params['se_sign'] = md5(md5($params['se_payment_code'].$params['refund_no'].$params['created_ts']).$mer_info['se_payment_key']);			
			unset($params['se_payment_code']);
			header('Location:'.$this->env_conf['site_url'].'/sepayment/payment/refund'.'?'.http_build_query($params));
		}
		
		//取出当前的退款记录
		$refund_data['payment_type'] = D('PaymentType')->get_data_by_id($refund_data['payment_type_id']);
		
		$this->assign('refund_data', $refund_data);
		$this->assign('refund_token', time());
		
		$refund_data_history = D('RefundRequest')->get_by_pay_no($refund_data['pay_no']);
		$this->assign('refund_data_history', $refund_data_history); 
		
		//显示退款页面
		$this->display('refund_application');
		
	}

	/**
	 * 发送退款邮件
	 * 
	 * 使用场景: 此函数只是针对收款账户为SE默认账户的商户, 当商户发起一次退款请求,就会发送邮件给到SE支付网关的运营人员.
	 * 
	 * @return bool
	 */
	protected function send_refund_email($refund_no, $time, $se_sign)
	{
		//如果退款号不合法则不进行退款.
		if(empty($refund_no) || empty($time) || empty($se_sign) || strlen($se_sign)!=32)
		{
			$this->set_status('INVALID_PARAMS', 'invalid params for send refund email!');
			return FALSE;
		}
		//主题
		$subject = 'SUNEEE OPG 退款邮件';
		//退款url
		$refund_url = $this->env_conf['site_url']."/opg/payment/refund/refund_application/se_val/$refund_no-$time-$se_sign";
		//内容
		$content  = '请打开此链接进行确认退款: <a href="'.$refund_url.'">请点击退款链接</a><br>';
		$content .= '如果看不到HTML链接按钮,请复制此链接到浏览器中: '.$refund_url;

    	return $this->send_mail($this->env_conf['mail']['from'], $subject, $content);
	}

    /**
     * 得到类型,用来给模板区分具体的动作
     */
    public function get_type()
    {
    	return 'refund';
    }
    
}