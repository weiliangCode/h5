<?php
namespace Payment\Controller;

use Think\Log;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;

/**
 * 商家DEMO
 *
 * 商户调用SUNEEE支付网关的DEMO
 *
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/

class DemoController extends PaymentController {

	const host = 'http://localhost/sepayment/payment';  //配置请求地址  //172.19.6.115
    const host4 = 'http://172.16.30.13:9008/payment';
    const host3 = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment';
    const host2 = 'http://opgdev.weilian.cn/payment';
    const host5 = 'http://opgtest.weilian.cn/payment';

	public $conf = array();   //配置参数

	public $data = array();	//请求参数

	/**
	 * 商户调用SUNEEE支付的入口
	 */
    public function __construct()
    {
        parent::__construct('DEV');
        if($_SERVER['HTTP_HOST'] == '172.19.5.55'){
            $this->getConf_test(self::host3);
        }elseif($_SERVER['HTTP_HOST'] == 'opgdev.weilian.cn' || $_SERVER['SERVER_ADDR'] == '172.16.30.13'){
            $this->getConf_test(self::host4);
        }
        elseif($_SERVER['HTTP_HOST'] == 'opgtest.weilian.cn' || $_SERVER['SERVER_ADDR'] == '172.19.6.115'){
            $this->getConf_test(self::host5);
        }
        else 
		//初始化相关配置地址
		$this->getConf();
		//设置运行环境
		$_SERVER['OPG_ENV'] = 'DEV';
    }
    public function getConf_test($host){
        $this->conf = array(
            'pay_url' =>$host.'/pay',
            'pay_return_url' => $host.'/demo/pay_return_url',
            'pay_notify_url' => $host.'/demo/pay_notice_url',
            'refund_url' => $host.'/refund',
            'refund_url1' =>$host. '/refund',
            'tie_url' => $host.'/tie',
            'bang_url' => $host.'/bang',
            'send_url' => $host.'/send',
            'send_return_url' => $host.'/demo/pay',
            'refund_return_url' => $host.'/demo/refund_return_url',
            'refund_notify_url' => $host.'/demo/refund_notice_url',
            'tie_return_url' => $host.'/demo/tie_return_url',
            'tie_notify_url' => $host.'/demo/tie_notice_url',
            'transfer_url' => $host.'/Transfer',
            'transfer_url1' => $host.'/transfer',
            'se_payment_code' => 'af70891aa4b8cc068dfd2af60c6270d7',
            'se_private_key' => 'd2f68eb0a0e3342e3a75846d3b39a83f',
            'se_payment_code3' => 'eccbc87e4b5ce2fe28308fd9f2a7baf3',
            'se_payment_key3' => '3631578538a2d6ba5879b31a9a42f290',
        );
    }

	/**
	 *  基础配置信息
	 */
	public function getConf()
	{

		 $this->conf = array(
			//形成流水号
			'pay_url' =>self::host.'/pay',
			//'pay_url' => U('/pay'),
			//支付URL
			//'pay_url1' => self::host.'/pay',

			//同步回调页面
			'pay_return_url' => self::host.'/demo/pay_return_url',

			//异步回调页面
			'pay_notify_url' => self::host.'/demo/pay_notice_url',

			//形成流水号
			'refund_url' => self::host.'/refund',
			//退款URL
			'refund_url1' =>self::host. '/refund',

			//绑卡短信验证码URL
			'tie_url' => self::host.'/tie',

			//绑卡短信验证码URL
			'bang_url' => self::host.'/bang',

			//中金支付发送验证码URL
			'send_url' => self::host.'/send',

			//中金支付发送验证码回调URL
			'send_return_url' => self::host.'/demo/pay',

			//同步回调页面
			'refund_return_url' => self::host.'/demo/refund_return_url',

			//异步回调页面
			'refund_notify_url' => self::host.'/demo/refund_notice_url',

			//同步回调页面
			'tie_return_url' => self::host.'/demo/tie_return_url',

			//异步回调页面
			'tie_notify_url' => self::host.'/demo/tie_notice_url',

			//形成流水号
			'transfer_url' => self::host.'/Transfer',
			//转账URL
			'transfer_url1' => self::host.'/transfer',

			//商家授权号   2f5cc53277fcf5f24c8ecb93c366b9a1
			'se_payment_code' => 'af70891aa4b8cc068dfd2af60c6270d7',
			// 'se_payment_code' => 'bdbab11da984ef047b269616ae9d888a', //尚龙
			//商家秘钥
			'se_private_key' => 'd2f68eb0a0e3342e3a75846d3b39a83f',
			// 'se_payment_key' => 'db695bb1754ba6778c3a63d18b728f32',//尚龙

			//无账户的商家授权号 (测试数据)
			'se_payment_code3' => 'eccbc87e4b5ce2fe28308fd9f2a7baf3',

			'se_payment_key3' => '3631578538a2d6ba5879b31a9a42f290',
		);
	}

    /**
     * 商户接口列表
     */
    public function index()
    {
    	//载入公用函数库,用于加载第三方支付接口
    	$this->display();
    }

    //----------------------------------------------------------------------------/
    //---------------------------------- 支付 --------------------------------------/
    //----------------------------------------------------------------------------/

    /**
     * 商户支付的form表单
     */
    public function pay()
    {
    	$this->display('test_pay');
    }

    /**
     * 商家同步回调url
     */


    public function pay_return_url()
    {
    	$m_mer = D('Merchant');
		$pay_data = $m_mer->get_merchant_pay_data_by_pay_no($_GET['pay_no']);
		$this->assign('pay_data', $pay_data);

        //载入pm模块公用函数库, 为了加载第三方类库使用
        // require(APP_PATH.'/'.MODULE_NAME.'/Common/common.php');
        //检查是否是wap/web请求
        if(is_mobile()){
            $this->display('paywap_return_success');
        }else{
            $this->display('pay_return_success');
        }
    }

    /**
     * 商家异步回调url
     */
    public function pay_notify_url()
    {

    }

    /**
     * 提交表单生成参数进行SE支付
     */
    public function submit_form_pay()
    {
		//处理请求参数
		$this->getData();

		if($this->data['is_embed'])
		{
			//a. 嵌入式载入
			$response = $this->curl($this->conf['pay_url'], $this->data, 'GET');
		}else{
			header('Location:'.$this->conf['pay_url'].'?'.http_build_query($this->data));
		}
    }


	/**
	 * 组装支付请求参数
	 * @param array $param
	 */
	public function getData(){
		if($this->param){
			//查看是否为请求API
			if($this->param['apiType']){
				$this->getApi($this->param['apiType']);
			}

			//有帐号商户，需要填写商户号，密钥 。 该参数由翌支付系统生成（商户中心可查）
			if($this->param['merchant_id']==2)
			{
				if($this->param['se_payment_code'] && $this->param['se_private_key'])
				{
					$this->conf['se_payment_code'] = $this->param['se_payment_code'];
					$this->conf['se_private_key'] = $this->param['se_private_key'];
				}else{
					$this->success('商户参数错误');
				}
			}

			//封装请求参数
			$this->data = array(
				'app_code'=>$this->param['app_code'],
				'se_payment_code' => $this->conf['se_payment_code'],
				'bill_id'=>$this->param['bill_id'],
				'bill_type_id'=>$this->param['bill_type_id'],
				'amount' => $this->param['amount'],
				'created_ts' => time(),
				'return_url' => $this->param['pay_return_url'],
				'notify_url' => $this->param['pay_notify_url'],
				'show_url' => $this->param['pay_show_url'],
				'payment_type_id' => $this->param['payment_type_id'],  //选择支付方式
				'subject' => $this->param['subject'],
				'description' => $this->param['description'],
                'app_type' => $this->param['app_type'],//ios 或者 android 
                'use_json' => 0, // 是否返回json,1--是;0--不是
			);

			//签名
			$this->data['se_sign'] = md5(md5($this->data['app_code'].$this->data['se_payment_code'].$this->data['bill_id'].$this->data['bill_type_id'].$this->data['amount'].$this->data['created_ts']).$this->conf['se_private_key']);

			$pay_no  = trim($this->curl($this->conf['pay_url'], $this->data,'POST',true));

			if(isset($pay_no) && (empty($pay_no) || !preg_match('/^\w+$/', $pay_no)))
			{
				$this->success("｛$pay_no｝:交易号错误，请重新生成");
			}

			//重新组装请求参数
			$this->data = array(
				'pay_no'=>$pay_no,
				//'is_embed'=>true, //是否嵌入式载入方式
				//'app_code'=>$this->param['app_code'],
                // 'use_json'=>0,
                // 'sdk' => 'ios',//是否为sdk支付商户
				'created_ts' => time()
			);

			//如果已选支付方式是中金支付
			if($this->param['payment_type_id']==6)
			{
				if($this->param['institution_number']&&$this->param['PayerName']&&$this->param['message_code'])
				{
					$this->data['payment_type_id'] = $this->param['payment_type_id'];
					$this->data['institution_number'] = $this->param['institution_number'];
					$this->data['PayerName'] = $this->param['PayerName'];
					$this->data['message_code'] = $this->param['message_code'];
				}else{
					$this->success('中金支付参数错误');
				}
			}

			//重新生成签名
			$this->data['se_sign'] = md5(md5($this->param['app_code'].$this->conf['se_payment_code'].$this->data['pay_no'].$this->data['created_ts']).$this->conf['se_private_key']);
            // echo '<pre>';var_dump($this->data)
			//exit($this->param['app_code'].$this->conf['se_payment_code'].$this->data['pay_no'].$this->data['created_ts']);
		}
	}

	public function getApi($apiType)
	{
		switch($apiType)
		{
			case '1':
				//支付方式列表接口
				break;
			case '2':
				//选择支付方式直接支付的接口
				break;
			case '3':
				//SDK选择支付方式调用接口
				break;
		}
	}
    /**
     * 直接测试支付接口
     */
    public function test_pay(){
    	$this->update_conf_by_env();

    	//1. 组装参数请求
    	$params = array(
    		'se_payment_code' => $this->conf['se_payment_code'],
			'bill_id'=>time(),
			'bill_type_id'=>'订单',
			'amount' => 0.01,
			'created_ts' => time(),
			'return_url' => $this->conf['return_url'],
			'notify_url' => $this->conf['notify_url'],
			'show_url' => $this->conf['show_url'],
		);


		$params['subject'] = '测试订单';
		$params['description'] = '订单明细, a商品, b商品';

		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['bill_id'].$params['bill_type_id'].$params['amount'].$params['created_ts']).$this->conf['se_payment_key']);

		if(!$params['se_sign']){
			die('sign failed!');
		}

    	$response = $this->curl($this->conf['pay_url'], $params);

    	//2. 得到参数号并验证
    	if(isset($response) && (empty($response) || !preg_match('/^\w+$/', $response)))
    	{
    		die($response);
    	}
    	$pay_no = $response;

    	//3. 商家应该保存当前交易号
    	//save_pay_no();

    	//4. 重新封装交易号请求
    	$params = array(
    		'se_payment_code' => $this->conf['se_payment_code'],
			'pay_no'=>$pay_no,
			'created_ts' => time()
		);
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['created_ts']).$this->conf['se_private_key']);

		//5. 从$params参数数组中移除不需要的商家授权号参数
		unset($params['se_payment_code']);

		//6. 以GET方式请求到支付类型选择页面
		//a. 嵌入式载入
		//$response = $this->curl($conf['pay_url'], $params, 'GET');
		//echo $response;
		//b. 跳转载入
    	header('Location:'.$this->conf['pay_url1'].'?'.http_build_query($params));

    	exit;
    }



    //----------------------------------------------------------------------------/
    //---------------------------------- 退款 --------------------------------------/
    //----------------------------------------------------------------------------/

    /**
     * 商户退款的form表单
     */
    public function refund(){

    	$this->display('test_refund');
    }

    /**
     * 提交退款表单
     */
    public function submit_form_refund()
    {
        //处理请求参数
        $this->getRefundData();

        if($this->data['is_embed'])
        {
            //a. 嵌入式载入
            $response = $this->curl($this->conf['refund_url'], $this->data, 'GET');
        }else{
            header('Location:'.$this->conf['refund_url1'].'?'.http_build_query($this->data));
        }

/*    	$this->update_conf_by_env();
		$post = I('post.');
		if(empty($post))
		{
			exit;
		}

		//切换测试用户
		if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
		{
			$this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
			$this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
		}

    	//1. 组装参数请求
    	$params = array(
    		'se_payment_code' => $this->conf['se_payment_code'],
    		'pay_no' => $post['pay_no'],
			'amount' => $post['amount'],
			'created_ts' => time(),//time(),
			// 'return_url' => $this->conf['return_url'],
            'return_url' => $post['refund_return_url'],
			// 'notify_url' => $this->conf['notify_url'],
            'notify_url' => $post['refund_notify_url'],
		);
    	$params['institution_number'] = $post['institution_number'];
    	$params['AccountType'] = $post['AccountType'];
    	$params['BankID'] = $post['BankID'];
    	$params['AccountName'] = $post['AccountName'];
    	$params['AccountNumber'] = $post['AccountNumber'];
    	$params['BranchName'] = $post['BranchName'];
    	$params['Province'] = $post['Province'];
    	$params['City'] = $post['City'];
		$params['subject'] = $post['subject'];
		$params['description'] = $post['description'];
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['amount'].$params['created_ts']).$this->conf['se_payment_key']);

		if(!$params['se_sign'])
		{
			die('sign failed!');
		}

		//2. 请求退款
    	$response = $this->curl($this->conf['refund_url'], $params);



    	//3. 得到退款号并验证
    	if(isset($response) && (empty($response) || !preg_match('/^\w+$/', $response)))
    	{
    		die($response);
    	}
    	$refund_no = $response;

    	//3. 商家应该保存当前交易号
    	//save_refund_no();

    	//4. 重新封装退款号请求
    	$params = array(
    		'se_payment_code' => $this->conf['se_payment_code'],
			'refund_no'=>$refund_no,
            //'is_embed'=>true, //是否嵌入式载入方式
			'created_ts' => time()
		);
        $params['institution_number'] = $post['institution_number'];
    	$params['AccountType'] = $post['AccountType'];
    	$params['BankID'] = $post['BankID'];
    	$params['AccountName'] = $post['AccountName'];
    	$params['AccountNumber'] = $post['AccountNumber'];
    	$params['BranchName'] = $post['BranchName'];
    	$params['Province'] = $post['Province'];
    	$params['City'] = $post['City'];
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['refund_no'].$params['created_ts']).$this->conf['se_payment_key']);
		//5. 从$params参数数组中移除不需要的商家授权号参数
		unset($params['se_payment_code']);

		//6. 以GET方式请求到支付类型选择页面
		//a. 嵌入式载入
		//$response = $this->curl($conf['refund_url'], $params, 'GET');
		//echo $response;
		//b. 跳转载入
    	header('Location:'.$this->conf['refund_url1'].'?'.http_build_query($params));

    	//7. 记录支付是否成功
    	exit;*/
    }
    /**
     * 组装退款请求参数
     * @param array $param
     */
    public function getRefundData()
    {
        if($this->param)
        {
            //有帐号商户，需要填写商户号，密钥 。 该参数由翌支付系统生成（商户中心可查）
            if($this->param['merchant_id']==2)
            {
                if($this->param['se_payment_code'] && $this->param['se_payment_key'])
                {
                    $this->conf['se_payment_code'] = $this->param['se_payment_code'];
                    $this->conf['se_payment_key'] = $this->param['se_payment_key'];
                }else{
                    $this->success('商户参数错误');
                }
            }

            //封装请求参数
            $this->data = array(
                'app_code'=>$this->param['app_code'],
                'se_payment_code' => $this->conf['se_payment_code'],
                'pay_no'=>$this->param['pay_no'],
                'amount' => $this->param['amount'],
                'created_ts' => time(),
                'return_url' => $this->param['refund_return_url'],
                'notify_url' => $this->param['refund_notify_url'],
                'subject' => $this->param['subject'],
                'description' => $this->param['description'],
                'use_json' => 0, // 是否返回json,1--是;0--不是            
            );  

            //签名
            $this->data['se_sign'] = md5(md5($this->data['app_code'].$this->data['se_payment_code'].$this->data['pay_no'].$this->data['amount'].$this->data['created_ts']).$this->conf['se_private_key']);

            //请求退款
            $refund_no  = trim($this->curl($this->conf['refund_url'], $this->data,'POST',true));

            if(isset($refund_no) && (empty($refund_no) || !preg_match('/^\w+$/', $refund_no)))
            {
                $this->success("｛$refund_no｝:交易号错误，请重新生成");
            }

            //重新组装请求参数
            $this->data = array(
                'refund_no'=>$refund_no,
                //'is_embed'=>true, //是否嵌入式载入方式
                //'app_code'=>$this->param['app_code'],
                // 'use_json' => 1, // 是否返回json,1--是;0--不是   
                'created_ts' => time()
            );

            //如果已选支付方式是中金支付
/*            if($this->param['institution_number']&&$this->param['PayerName']&&$this->param['message_code'])
            {
                $this->data['payment_type_id'] = $this->param['payment_type_id'];
                $this->data['institution_number'] = $this->param['institution_number'];
                $this->data['PayerName'] = $this->param['PayerName'];
                $this->data['message_code'] = $this->param['message_code'];
            }else{
                $this->success('中金支付参数错误');
            }*/

            //重新生成签名
            $this->data['se_sign'] = md5(md5($this->param['app_code'].$this->conf['se_payment_code'].$this->data['refund_no'].$this->data['created_ts']).$this->conf['se_private_key']);
        }
    }
    /**
     * 商户转账的form表单
     */
    public function transfer(){
        $this->display('test_transfer');
    }

    /*
        转账测试
    */
    public function transfer_test(){
        $j=100;
        $data = array();
        $data['rec_account_no']='6222024000072983949';
        $data['rec_account_name']='汪伟';
        $data['subject']='转账';
        $data['amount']='0.01';
        $data['transfer_return_url']='';
        $data['transfer_notify_url']='';
        $data['description']='转账详情';
        $data['merchant_id']='2';

        //$this->paymentParams=$data;

        for($i=1;$i<=$j;$i++)
        {
           $params = $this->submit_form_transfer($data);
           $response = $this->curl($this->conf['transfer_url'], $params);
           echo ("{$i}:{$response}");
        }
    }

    /**
     * 提交转账表单
     */
    // public function submit_form_transfer($params=array())
    public function submit_form_transfer(){
        $post = I('post.');
//        var_dump($post['use_json']);exit;
        if(empty($post)) exit;
        //切换测试用户
        if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
        {
            $this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
            $this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
        }
        //1. 组装参数请求
        $params = [
            'app_code' => $post['app_code'],
            'se_payment_code' => $this->conf['se_payment_code'],
//            'se_private_key' => $this->conf['se_private_key'],
            'rec_account_no' => $post['rec_account_no'],
            'rec_account_name' => $post['rec_account_name'],
            'amount' => $post['amount'],
//            'use_json' => $post['use_json'],
            'created_ts' => time(),
            'return_url' => $post['transfer_return_url'],
            'notify_url' => $post['transfer_notify_url'],
            'payment_type_id' => $post['payment_type_id'],
            'OrderNo' => $post['OrderNo'],
            'institution_number' => $post['institution_number'],
            'AccountType'=> $post['AccountType'],
            'BankID' => $post['BankID'],
            'subject'=> $post['subject'],
            'description'=> $post['description']
        ];
        //$params['SerialNumber'] = $post['SerialNumber'];
//        $params['OrderNo'] = $post['OrderNo'];
//        $params['institution_number'] = $post['institution_number'];
//        $params['AccountType'] = $post['AccountType'];
//        $params['BankID'] = $post['BankID'];
       /*  $params['AccountName'] = $post['AccountName'];
        $params['AccountNumber'] = $post['AccountNumber'];
        $params['BranchName'] = $post['BranchName'];
        $params['Province'] = $post['Province'];
        $params['City'] = $post['City'];*/
//        $params['subject'] = $post['subject'];
//        $params['description'] = $post['description'];
        $params['se_sign'] = md5(md5($params['app_code'].$params['se_payment_code'].$params['rec_account_no'].$params['amount'].$params['created_ts']).$this->conf['se_private_key']);

        //2. 请求转账
//        var_dump($this->conf['transfer_url']);exit;
        $transfer_no = trim($this->curl($this->conf['transfer_url'], $params));
//var_dump($transfer_no);exit;
        //3. 得到转账号并验证
//        if(isset($transfer_no) && (empty($transfer_no) || !preg_match('/^\w+$/', $transfer_no)))
//        {
//            die($transfer_no);
//        }

        //3. 商家应该保存当前交易号
        //save_refund_no();

        //4. 重新封装转账号请求
        $params2 = [
            'transfer_no'=>$transfer_no,
            'se_payment_code'=>$this->conf['se_payment_code'],
            'app_code'=>$post['app_code'],
            'use_json' => $post['use_json'],
            //'is_embed'=>true, //是否嵌入式载入方式
//            'institution_number' => $post['institution_number'],
            'created_ts' => time()
        ];
        //$params['SerialNumber'] = $post['SerialNumber'];
//        $params['OrderNo'] = $post['OrderNo'];
//        $params['institution_number'] = $post['institution_number'];
//        $params['AccountType'] = $post['AccountType'];
//        $params['BankID'] = $post['BankID'];
      /*   $params['AccountName'] = $post['AccountName'];
        $params['AccountNumber'] = $post['AccountNumber'];
        $params['BranchName'] = $post['BranchName'];
        $params['Province'] = $post['Province'];
        $params['City'] = $post['City']; */
        $params2['payment_type_id'] = $post['payment_type_id'];
        $params2['se_sign'] = md5(md5($params2['app_code'].$params2['se_payment_code'].$params2['transfer_no'].$params2['created_ts']).$this->conf['se_private_key']);
        //5. 从$params参数数组中移除不需要的商家授权号参数
//        unset($params['se_payment_code']);

        // return  $params;
        //6. 以GET方式请求到支付类型选择页面
        //a. 嵌入式载入
        //$response = $this->curl($conf['refund_url'], $params, 'GET');
        //echo $response;
        //b. 跳转载入
        header('Location:'.$this->conf['transfer_url'].'?'.http_build_query($params2));

        //7. 记录支付是否成功
        exit;
    }


    /**
     * 商户中金绑卡短信验证码的form表单
     */
    public function tie()
    {
    	$this->display('test_tie');
    }


 	/**
     * 提交表单生成参数进行SE支付
     */
    public function submit_form_tie()
    {


    	$this->update_conf_by_env();

		$post = I('post.');

		if(empty($post))
		{
			exit;
		}

		//切换测试用户
		if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
		{
			$this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
			$this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
		}

    	//1. 组装参数请求
    	$params = array(
    		'se_payment_code' => $this->conf['se_payment_code'],
    		'institution_number' => $post["institution_number"],
    		'binding_number' => $post["binding_number"],
			'created_ts' => time(),
    		'BankID' => $post["BankID"],
    		'AccountName' => $post["AccountName"],
    		'AccountNumber' => $post["AccountNumber"],
    		'IdentificationType' => $post["IdentificationType"],
    		'IdentificationNumber' => $post["IdentificationNumber"],
    		'PhoneNumber' => $post["PhoneNumber"],
    		'CardType' => $post["CardType"],
    		'return_url' => $post['tie_return_url'],
    		'notify_url' => $post['tie_notify_url'],
		);
		$params['ValidDate'] = isset($post['ValidDate'])?$post['ValidDate']:'';
		$params['CVN2'] = isset($post['CVN2'])?$post['CVN2']:'';
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['institution_number'].$params['binding_number'].$params['created_ts']).$this->conf['se_payment_key']);

		if(!$params['se_sign'])
		{
			die('sign failed!');
		}

		// 跳转载入
    	header('Location:'.$this->conf['tie_url'].'?'.http_build_query($params));

    	exit;
    }


    /**
     * 商户中金支付发送验证码的form表单
     */
    public function send()
    {
    	$this->display('test_send');
    }


    /**
     * 中金支付第一次提交
     */
    public function submit_form_send()
    {


    	$this->update_conf_by_env();

    	$post = I('post.');

    	if(empty($post))
    	{
    		exit;
    	}

    	//切换测试用户
    	if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
    	{
    		$this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
    		$this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
    	}

    	//1. 组装参数请求
    	$params = array(
    			'se_payment_code' => $this->conf['se_payment_code'],
    			'bill_id'=>$post['bill_id'],
    			'bill_type_id'=>$post['bill_type_id'],
    			'amount' => $post['amount'],
    			'created_ts' => time(),
    			// 'return_url' => $this->conf['pay_return_url'],
    			'return_url' => $post['pay_return_url'],
    			// 'notify_url' => $this->conf['pay_notify_url'],
    			'notify_url' => $post['pay_notify_url'],
    			'payment_type_id' => '5',
    	);

    	//提交中金支付必须数据（秉谦）
    	$params['institution_number'] = $post['institution_number'];
    	$params['binding_number'] = $post['binding_number'];
    	$params['subject'] = $post['subject'];
    	$params['description'] = $post['description'];
    	$params['se_sign'] = md5(md5($params['se_payment_code'].$params['bill_id'].$params['bill_type_id'].$params['amount'].$params['created_ts']).$this->conf['se_payment_key']);

    	if( $params['se_sign'] === FALSE )
    	{
    		die('sign failed!');
    	}

    	if(isset($params['institution_number']))
    	{
    		if(empty($params['pay_no']))
    		{
    			$response = $this->curl($this->conf['send_url'], $params,'POST',true);  //获取流水号
    			if(substr($response,0,3)=="NULL"){
    				$response=substr($response,5);
    			}
    			$pay_no = $response;

    			//4. 重新封装交易号请求
    			$params = array(
    					'se_payment_code' => $this->conf['se_payment_code'],
    					'pay_no'=>$pay_no,
    					//'is_embed'=>true, //是否嵌入式载入方式
    					'created_ts' => time()
    			);

    			//提交中金支付必须数据（秉谦）
    			$params['institution_number'] = $post['institution_number']; //中金支付必需参数
    			$params['binding_number'] = $post['binding_number'];
    			$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['created_ts']).$this->conf['se_payment_key']);
    			//5. 从$params参数数组中移除不需要的商家授权号参数
    			unset($params['se_payment_code']);

    			//header('Location:'.$this->conf['send_url'].'?'.http_build_query($params));
    			//中金发送短信验证码($params);

    			$result = $this->message($params);  //短信验证接口返回结果

    			if($result['status']=='1')  //如果有结果为真
    			{
    				$params = array(
    						'pay_no'=>$result['pay_no'],
    						'bill_id'=>$result['bill_id'],
    						'bill_type_id'=>$result['bill_type_id'],
    						'subject'=>$result['subject'],
    						'amount'=>$result['amount'],
    						'institution_number'=>$result['institution_number']
    						);
    				header('Location:'.$this->conf['send_return_url'].'?'.http_build_query($params));
    				exit; //返回流水号
    			}else{
    				$send_data = $result;
    				$this->assign('send_data', $send_data);
    				if(is_mobile()){
    					$this->display('wap_error');
    				}else{
    					$this->display('web_error');
    				}
    			}
    		}
    	}
    }

    /**
     * 商户中金绑卡的form表单
     */
    public function bang()
    {
    	$this->display('test_bang');
    }


    /**
     * 提交表单生成参数进行SE支付
     */
    public function submit_form_bang()
    {


    	$this->update_conf_by_env();

    	$post = I('post.');

    	if(empty($post))
    	{
    		exit;
    	}

    	//切换测试用户
    	if(isset($post['merchant_id']) && !empty($post['merchant_id']) && $post['merchant_id']==3)
    	{
    		$this->conf['se_payment_code'] = $this->conf['se_payment_code3'];
    		$this->conf['se_payment_key'] = $this->conf['se_payment_key3'];
    	}

    	//1. 组装参数请求
    	$params = array(
    			'se_payment_code' => $this->conf['se_payment_code'],
    			'institution_number' => $post["institution_number"],
    			'binding_number' => $post["binding_number"],
    			'created_ts' => time(),
    			'message_code' => $post["message_code"],
    			'return_url' => $post['tie_return_url'],
    			'notify_url' => $post['tie_notify_url'],
    	);
    	$params['se_sign'] = md5(md5($params['se_payment_code'].$params['institution_number'].$params['binding_number'].$params['created_ts']).$this->conf['se_payment_key']);

    	if(!$params['se_sign'])
    	{
    		die('sign failed!');
    	}

    	// 跳转载入
    	header('Location:'.$this->conf['bang_url'].'?'.http_build_query($params));

    	exit;
    }

    //中金快捷支付发送短信验证码调用方法
    public function message($params){
    	include_once './SendController.class.php';

    	$object = new SendController($params);

    	return $object->index();
    }

}