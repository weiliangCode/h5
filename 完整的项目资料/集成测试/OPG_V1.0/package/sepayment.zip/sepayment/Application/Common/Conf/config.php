<?php
return array(

	//---------------------------------------------------------------------------------------------------//
	//-------------------------------------------  信息配置    ------------------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	//版本配置
//	'SE_PAYMENT_VERSION' => '1.0.0',

	//平台名称
//	'SE_PAYMENT_NAME' => 'SUNEEE Payment',


	//---------------------------------------------------------------------------------------------------//
	//------------------------------------------- 系统配置  -------------------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	//系统相关开启
	//'SHOW_RUN_TIME'    => true, // 运行时间显示
	//'SHOW_ADV_TIME'    => true, // 显示详细的运行时间
	//'SHOW_DB_TIMES'    => true, // 显示数据库查询和写入次数
	//'SHOW_CACHE_TIMES' => true, // 显示缓存操作次数
	//'SHOW_USE_MEM'     => true, // 显示内存开销
	//'SHOW_LOAD_FILE'   => true, // 显示加载文件数
	//'SHOW_FUN_TIMES'   => true, // 显示函数调用次数

	//---------------------------------------------------------------------------------------------------//
	//------------------------------------------- 数据库配置  ------------------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	//生产环境数据库配置信息
	'DB_PROD' => array(
		'DB_TYPE'   => 'mysql', // 数据库类型
//        'DB_HOST'   => '10.1.48.13', // 服务器地址
        'DB_HOST'   => '10.1.48.9', // 服务器地址 vip
		'DB_NAME'   => 'suneee_payment', // 数据库名
		'DB_USER'   => 'root', // 用户名
		'DB_PWD'    => 'suneee@mysql768', // 密码
		'DB_PORT'   => 3306, // 端口
		'DB_PREFIX' => '', // 数据库表前缀
		'DB_CHARSET'=> 'utf8', // 字符集
		'DB_DEBUG'  =>  TRUE, // 数据库调试模式 开启后可以记录SQL日志 3.2.3新增
	),

	//测试环境数据库配置信息
	'DB_TEST' => array(
		'DB_TYPE'   => 'mysql', // 数据库类型
		'DB_HOST'   => '172.19.6.115', // 服务器地址
		'DB_NAME'   => 'suneee_payment', // 数据库名
		'DB_USER'   => 'root', // 用户名
		'DB_PWD'    => 'suneee@mysql768', // 密码
		'DB_PORT'   => 3306, // 端口
		'DB_PREFIX' => '', // 数据库表前缀

		'DB_CHARSET'=> 'utf8', // 字符集
		'DB_DEBUG'  =>  TRUE, // 数据库调试模式 开启后可以记录SQL日志 3.2.3新增
	),

	//开发环境数据库配置信息
	'DB_DEV' => array(
		'DB_TYPE'   => 'mysqli', // 数据库类型
		'DB_HOST'   => '172.16.30.13', // 服务器地址
		'DB_USER'   => 'gdmall', // 用户名
		'DB_PWD'    => '123456', // 密码
		/*'DB_HOST'   => '172.19.6.125', // 服务器地址
		'DB_USER'   => 'root', // 用户名
		'DB_PWD'    => 'suneee@mysql768', // 密码*/

		'DB_NAME'   => 'suneee_payment', // 数据库名
		'DB_PORT'   => 3306, // 端口
		'DB_PREFIX' => '', // 数据库表前缀
		'DB_CHARSET'=> 'utf8', // 字符集
		'DB_DEBUG'  =>  TRUE, // 数据库调试模式 开启后可以记录SQL日志 3.2.3新增
		/*
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '172.19.6.125', // 服务器地址
        'DB_NAME'   => 'suneee_payment', // 数据库名
        'DB_USER'   => 'root', // 用户名
        'DB_PWD'    => 'suneee@mysql768', // 密码
        'DB_PORT'   => 3306, // 端口
        'DB_PREFIX' => '', // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
        'DB_DEBUG'  =>  TRUE, // 数据库调试模式 开启后可以记录SQL日志 3.2.3新增
        */
	),
	

	//发送邮件
	'PORT' => 84,
	'REGISTER_SUBJECT' => '注册账户',
	'REGISTER_CONTENT' => '<h2>欢迎加入翌支付</h2><br>
							请点击以下按钮进行邮箱账号确认，24小时内确认均有效。<br>
							<a href={#register_url}>确认账号</a><br>
							如果按钮无效，请复制以下链接在浏览器中打开完成账号确认。<br>
							<a href={#register_url}>{#register_url}</a><br>',
	'RESET_SUBJECT' => '重置密码',
	'RESET_CONTENT' => '<h2>重 置 密 码</h2><br>
						你可以在2小时内点击下方重置密码按钮进行密码的重置。<br><br>
						如果这不是你本人发起的动作，请检查你的信息是否泄露。如有疑问，请联系象翌QQ客服。<br><br>
						<a href={#reset_url}>重置密码</a><br>
						如果按钮无效，请复制以下链接到浏览器打开进行密码重置<br>
						<a href={#reset_url}>{#reset_url}</a><br>',

    'RESET_ACCOUNT_SUBJECT' => '修改登入邮箱',
    'RESET_ACCOUNT_CONTENT' => '<h2>您的登入账号发生更改</h2><br>
						原此邮箱所登入的翌支付平台账号已经失效。新的登入邮箱为:{#account}<br><br>
						如果这不是你本人发起的动作，请检查你的信息是否泄露。如有疑问，请联系象翌QQ客服。<br><br>',

    'LIVEKEY_SUCCESS_SUBJECT' => 'liveKey激活结果',
    'LIVEKEY_SUCCESS_CONTENT' => '<h2>{#merchant_name}，您好！<h2><br>
                        您提交的企业签约资料已审核通过，现已签约成功，可进行支付渠道开通。请知悉！<br><br>
                        如有疑问，请联系象翌QQ客服。<br><br>
                        <div style="float:right">翌支付</div><br>',

    'LIVEKEY_FAIL_SUBJECT' => 'liveKey激活结果',
    'LIVEKEY_FAIL_CONTENT' => '<h2>{#merchant_name}，您好！<h2><br>
                        遗憾, 您在翌支付提交的企业签约资料信息经审核未通过。<br><br>
                        原因 : {#reason}。<br><br>
                        如有疑问，请联系象翌QQ客服。<br><br>
                        <div style="float:right">翌支付</div><br>',

    'INFO_SUCCESS_SUBJECT' => '我的资料修改结果',
    'INFO_SUCCESS_CONTENT' => '<h2>{#merchant_name}，您好！<h2><br>
                        恭喜, 您在翌支付提交的"我的资料"信息已经审核通过。<br><br>
                        现在企业签约资料信息已更新。如有疑问，请联系象翌QQ客服。<br><br>
                        <div style="float:right">翌支付</div><br>',

    'INFO_FAIL_SUBJECT' => '我的资料修改结果',
    'INFO_FAIL_CONTENT' => '<h2>{#merchant_name}，您好！<h2><br>
                        遗憾, 您在翌支付提交的企业签约资料信息经审核未通过。<br><br>
                        原因 : {#reason}。如有疑问，请联系象翌QQ客服。<br><br>
                        <div style="float:right">翌支付</div><br>',
	//文件上传
//	'URL' => 'http://10.0.0.144:8081/file-service/',
//	'UPLOAD_URL' => 'http://10.0.0.144:8081/file-service/file-api.upload?domain=OPG&type=user',
//	'DOWNLOAD_URL' => 'http://10.0.0.144:8081/file-service/file-api.download?domain=OPG&type=user',

	//短信接口地址
//	'MESSAGE_HOST' => 'http://172.16.1.9:8280/sms_frontend/services/senderPhpWebService?wsdl',
//	'SERVICECODE' => 'WL_COMMUNITY',
//	'SMSCONTENT' => '【翌支付】您的手机验证码为{#number}，请尽快验证！系统短信请勿回复！',
    
    //redis配置 生产环境
    'REDIS_PROD' => array(
        'REDIS_HOST' => '10.1.48.16',
        'REDIS_PORT' => '6379',
        'DATA_CACHE_TIMEOUT' => 3600,
        'DATA_CACHE_PREFIX' => 'opg_',
    ),
    //redis配置 测试环境
    'REDIS_TEST' => array(
        'REDIS_HOST' => '172.19.6.105',
        'REDIS_PORT' => '6379',
        'DATA_CACHE_TIMEOUT' => 3600,
        'DATA_CACHE_PREFIX' => 'opg_',
    ),
    //redis配置 开发环境
    'REDIS_DEV' => array(
        'REDIS_HOST' => '172.19.6.105',
        'REDIS_PORT' => '6379',
        'DATA_CACHE_TIMEOUT' => 3600,
        'DATA_CACHE_PREFIX' => 'opg_',
    ),
    // sessionId 过期时间(秒)
    'SESSIONID_TIMEOUT' => 600,
    // php 正式环境集群
    'SERVER_PROD' =>array(
        '10.1.48.12',
        '10.1.48.14',
    ),// php 开发环境集群
    'SERVER_DEV' =>array(
        '172.16.30.13'
    ),// php 测试环境集群
    'SERVER_TEST' =>array(
        '172.19.6.115'
    ),
    // 支付渠道类型定义
//    'PAYMENT_TYPE_NAME' => [
//        '1' => '第三方支付',
//        '2' => '银行',
//        '3' => '银联'
//    ],
    //应用编码前缀
//    'APP_CODE_PREFIX'=> 'SUNEEE',
    // 退款时效  RefundDay 15 天
//    'REFUNDDAY' => 15,
    // 短信验证码时效 short_message_time 600 秒
//    'SHORT_MESSAGE_TIME' =>600,
    //se_code过期时间
//    'SE_CODE_TIMEOUT' => 1800,
    //邮件过期时间
//    'EMAIL_TIMEOUT' => 7200,
    // 订单及退款单的状态码
//    'PAYMENTSTATUS' =>  [
//        '处理中' => [1,2,4,6,7,9,10,12,13],
//        '失败' => [3,5,8,11,14,16],
//        '成功' => [15,17,18]
//    ],

	'ENV' => array(

		//正式环境
		'PROD' => array(
			//支付号前缀
			'pay_no_prefix' => 'P',
			//退款号前缀
			'refund_no_prefix' => 'R',
			//转账号前缀
			'transfer_no_prefix' => 'T',
			//站点域名
			'site_url' => 'http://opg.suneee.com',

			//运营邮件配置
//			'mail' => array(
//				'host' => 'mail.suneee.com',
//				'username' => 'boyue@suneee.com',
//				'password' => 'qinkangta',
//				'replyTo' => 'boyue@suneee.com',
//				'from' => 'boyue@suneee.com',
//			),

		),

		//测试环境
		'TEST' => array(
			'pay_no_prefix' => 'C',
			'refund_no_prefix' => 'D',
			'transfer_no_prefix' => 'T',
			'site_url' => 'http://172.19.6.115/', //如果没有配置则自动识别

			//运营邮件配置
//			'mail' => array(
//				'host' => 'mail.suneee.com',
//				'username' => 'zhuoer@suneee.com',
//				'password' => 'hgw10834008',
//				'replyTo' => 'zhuoer@suneee.com',
//				'from' => 'zhuoer@suneee.com',
//			),
		),
		//开发在本机开发
		'DEV' => array(
			'pay_no_prefix' => 'A',
			'refund_no_prefix' => 'B',
			'transfer_no_prefix' => 'T',
			// 'site_url' => 'http://dev.opg.suneee.com', //如果没有配置则自动识别
			'site_url' => 'http://localhost',
			//运营邮件配置
//			'mail' => array(
//				'host' => 'mail.suneee.com',
//				'username' => 'zhuoer@suneee.com',
//				'password' => 'hgw10834008',
//				'replyTo' => 'zhuoer@suneee.com',
//				'from' => 'zhuoer@suneee.com',
//			),
		),
	),
);