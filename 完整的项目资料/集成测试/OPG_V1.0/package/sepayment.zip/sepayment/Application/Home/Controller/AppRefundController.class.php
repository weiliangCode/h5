<?php
namespace Home\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->tengyuan
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class AppRefundController extends HomeController{
    // 退款时限 15 天
    static $RefundDay = 15;
    // 退款接口地址
    static $refund_url = '';
    static $status = [
        '处理中' => [1,2,4,6,7,9,10,12,13],
        '失败' => [3,5,8,11,14,16],
        '成功' => [15,17,18]
    ];
    public function __construct(){
        parent::__construct();
        self::$RefundDay = D('Operate/SysConfig')->REFUNDDAY;
        self::$status = D('Operate/SysConfig')->PAYMENTSTATUS;
        if($_SERVER['SERVER_ADDR'] == '172.19.5.55'){
            self::$refund_url = 'http://172.19.5.55/suneee/OPG/web/trunk/sepayment/payment/';
        }elseif($_SERVER['SERVER_ADDR'] == 'opgdev.weilian.cn'){
            self::$refund_url = 'http://opgdev.weilian.cn/payment/';
        }elseif($_SERVER['SERVER_ADDR'] == '172.16.30.13'){
            self::$refund_url = 'http://172.16.30.13:9008/payment/';
        }else {
            self::$refund_url = 'http://172.19.6.115:9008/payment/';
        }
    }
    //退款申请(form)
    //{"act":"2","method":"AppRefund","op":"RefundRequestForm","data":{"merchant_app_id":"1","bill_id":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function RefundRequestForm(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->pay_no)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id or pay_no ';
            exit(json_encode($this->returnData));
        }

        $where['pay_request.pay_no'] = $this->param->pay_no;
        $where['pay_request.auth_app_id'] = $this->param->merchant_app_id;

        $data = $this->getData($where);
//        var_dump($data);
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $data;
        exit(json_encode($this->returnData));
    }

    //退款申请(active)
    //{"act":"2","method":"AppRefund","op":"RefundRequestActive","data":{"merchant_app_id":"1","pay_no":"1"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function RefundRequestActive(){
        if(is_null($this->param->merchant_app_id) || is_null($this->param->pay_no)){
            $this->returnData['message'] = '缺少必要参数 merchant_app_id or pay_no ';
            exit(json_encode($this->returnData));
        }

        $where['pay_request.pay_no'] = $this->param->pay_no;
        $where['pay_request.auth_app_id'] = $this->param->merchant_app_id;
// 方便开发临时关闭
        $reg['merchant_id'] = $this->sessionId->merchant_id;
        $reg['passwd'] = md5($this->param->passwd);
        $k = D('RegUser')->where($reg)->select();
        if(is_null($k)){
            $this->assign('message', '密码错误! ');
            $this->display('error');
            exit;
//            $this->returnData['message'] = '密码错误! ';
//            exit(json_encode($this->returnData));
        }

        // 验证本次退款是否合法
        $data = $this->getData($where);
//        var_dump($data);
        if($data['pay_request_status'] !== '成功'){

            $this->assign('message', '当前订单尚未完成! ');
            $this->display('error');
            exit;
//            $this->returnData['message'] = '当前订单尚未完成! ';
//            exit(json_encode($this->returnData));
        }
        if($data['status'] === '处理中'){

            $this->assign('message', '当前订单存在尚未完成的退款! ');
            $this->display('error');
            exit;
//            $this->returnData['message'] = '当前订单存在尚未完成的退款! ';
//            exit(json_encode($this->returnData));
        }
        if(bccomp((float)$this->param->new_amount,(float)$data['Max_Refund_amount'],2) == 1){

            $this->assign('message', '本次退款额度不应超过 '.$data['Max_Refund_amount'].'你提交是为'.$this->param->new_amount);
            $this->display('error');
            exit;
//            $this->returnData['message'] = '本次退款额度不应超过 '.$data['Max_Refund_amount'].'你提交是为'.$this->param->new_amount;
//            exit(json_encode($this->returnData));
        }
        if( ($_SERVER['REQUEST_TIME'] - strtotime($data['created_ts'])) > (self::$RefundDay*3600*24) ){

            $this->assign('message', '订单距今已超过'.self::$RefundDay.'天');
            $this->display('error');
            exit;
//            $this->returnData['message'] = '订单距今已超过'.self::$RefundDay.'天';
//            exit(json_encode($this->returnData));
        }
        //////// 调用翌支付api
        //封装请求参数
        // 商户相关信息
        $merchantInfo = D('Merchant')->getMerchantInfoByAppId($this->param->merchant_app_id);
//var_dump($merchantInfo);exit;
        ///
        $refundData = array(
            'app_code'=> $merchantInfo['app_code'],
            'se_payment_code' => $merchantInfo['se_payment_code'],
            'pay_no'=> $this->param->pay_no,
            'amount' => $this->param->new_amount,
            'created_ts' => time(),
            'return_url' => '',
            'notify_url' => '',
            'subject' => '',
            'description' => '翌支付商户平台退款',
            'use_json' => 0, // 是否返回json,1--是;0--不是
        );
        //签名
        $refundData['se_sign'] = md5(md5($refundData['app_code'].$refundData['se_payment_code'].$refundData['pay_no'].$refundData['amount'].$refundData['created_ts']).$merchantInfo['se_private_key']);
        //请求退款
        $refund_no  = trim($this->curl(self::$refund_url.'refund', $refundData,'POST',true));
//var_dump($refund_no);exit;
        if(isset($refund_no) && (empty($refund_no) || !preg_match('/^\w+$/', $refund_no))){
            exit($refund_no);
//            $this->returnData['message'] = '退款号获取失败,'.$refund_no;
//            exit(json_encode($this->returnData));
        }
        //重新组装请求参数
        $refundData2 = array(
            'refund_no'=>$refund_no,
            //'is_embed'=>true, //是否嵌入式载入方式
            //'app_code'=>$this->param['app_code'],
            'use_json' => 0, // 是否返回json,1--是;0--不是
            'created_ts' => time()
        );
        //重新生成签名
        $refundData2['se_sign'] = md5(md5($refundData['app_code'].$refundData['se_payment_code'].$refundData2['refund_no'].$refundData2['created_ts']).$merchantInfo['se_private_key']);
        header('Location:'.self::$refund_url.'refund'.'?'.http_build_query($refundData2));
    }

    private function getData($where){
        $data = D('RefundRequest')->RefundRequestForm($where);
//        echo D('RefundRequest')->getLastSql();exit;
//        var_dump($data);exit;
        if($data){
            $Max_Refund_amount = $data[0]['amount'];
            $refunding_amount = 0; // 正在退款
            $already_refund_amount = 0.00;  // 已经退款
            $status = is_null($data[0]['refund_status_id']) ? '未发生退款': $data[0]['refund_status_id'] ;
            foreach($data as $k=>$v){
                if(in_array($v['refund_status_id'], self::$status['成功']))
                    $already_refund_amount += isset($v['refund_amount']) ? $v['refund_amount'] : 0.00;
                if(in_array($v['refund_status_id'], self::$status['处理中']))
                    $refunding_amount += isset($v['refund_amount']) ? $v['refund_amount'] : 0.00;
            }
            $Max_Refund_amount = ( $Max_Refund_amount - $already_refund_amount );
            foreach(self::$status as $k=> $v){
                if(in_array($status, $v)){
                    $status = $k;
                    break;
                }
            }
            $arr = [
                'bill_id'    => $data[0]['bill_id'],
                'pay_request_id'    => $data[0]['pay_request_id'],
                'amount' => $data[0]['amount'],
                'refund_amount' => $data[0]['amount'] - $Max_Refund_amount,
                'created_ts' => $data[0]['created_ts'],
                'refunding_amount' => $refunding_amount,
                'Max_Refund_amount' => $Max_Refund_amount,
                'payment_type_name' => $data[0]['payment_type_name'],
                'payment_type_id' => $data[0]['payment_type_id'],
                'scenary_id' => $data[0]['scenary_id'],
                'last_refund_ts' => $data[0]['last_refund_ts'],
                'status' => $status
            ];
            foreach(self::$status as $k=> $v){
                if(in_array($data[0]['status_id'], $v)){
                    $arr['pay_request_status'] = $k;
                    break;
                }
            }
        }else{
            $this->returnData['message'] = '无效的 merchant_app_id or pay_no ';
            exit(json_encode($this->returnData));
        }
        return $arr;
    }
    /**
     * curl请求提交模式
     *
     * @params string 提交地址
     * @params array 需要提交的参数
     *
     * @parmas string 提交方式 post/get
     *         提交到客户端都需要用 sign 签名字段
     */
    private function curl($url, $params = array(), $type = 'POST', $proxy = false){
        $is_ssl = false;
        $port = false;
        if(preg_match('/^(http|https):\/\/([\w\.]+)(:(\d+))?\//', $url, $m)){
            $is_ssl = true;
        }
        else{
            die('curl error['.$type.']: invalid url => '.$url);
        }
        $ch = curl_init();
        if($port){
            curl_setopt($ch, CURLOPT_PORT, $port);
        }
        //指定以非2进制(multipart/form-data)头部格式传送
        $this_header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);
        if(isset($_SERVER['HTTP_USER_AGENT'])){
            curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        }
        $opts = array(CURLOPT_TIMEOUT => 60, CURLOPT_RETURNTRANSFER => 1, //CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $this_header, CURLOPT_ENCODING => 'gzip,deflate',);
        if($is_ssl){
            $opts[ CURLOPT_SSL_VERIFYHOST ] = true;
            $opts[ CURLOPT_SSL_VERIFYPEER ] = false;
        }
        switch( $type ){
            case 'POST' :
                $opts[ CURLOPT_URL ] = $url;
                $opts[ CURLOPT_POST ] = 1;
                $opts[ CURLOPT_POSTFIELDS ] = http_build_query($params); // 貌似这类参数会报错: 'a=1&b=1';
                break;
            case 'GET':
                $get_params_str = '';
                if($params){
                    $get_params_str = '&';
                    if(strpos($url, '?') === false)
                        $get_params_str = '?';
                    $get_params_str = $get_params_str.http_build_query($params);
                }
                $opts[ CURLOPT_URL ] = $url.$get_params_str;
                break;
        }
        //curl请求
        curl_setopt_array($ch, $opts);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        curl_setopt($ch, CURLOPT_URL, $opts[ CURLOPT_URL ]);
        $output = curl_exec($ch);
        $error = curl_error($ch);
        if($error){
            die('curl error['.$type.']: '.$error.' | '.$opts[ CURLOPT_URL ]);
        }
        curl_close($ch);
        return $output;

    }
}
