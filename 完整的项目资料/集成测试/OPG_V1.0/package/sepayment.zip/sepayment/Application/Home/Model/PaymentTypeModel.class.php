<?php
namespace Home\Model;
class PaymentTypeModel extends HomeModel{
}