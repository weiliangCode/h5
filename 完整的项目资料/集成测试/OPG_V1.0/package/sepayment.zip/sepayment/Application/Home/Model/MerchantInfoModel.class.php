<?php
namespace Home\Model;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class MerchantInfoModel extends HomeModel {
    /**
     * 保存商户相关信息
     * @params array $data 商户请求数据
     * @return bool
     */
    public function addData($data){
        return $this->add($data);
    }
    public function update($data){
        return $this->where('merchant_id='.$data['merchant_id'])->save($data);
    }

    public function getInfo($merchant_id){
        $r = $this
            ->join('merchant ON merchant.merchant_id=merchant_info.merchant_id')
            ->where(['merchant.merchant_id'=>$merchant_id])
            ->field([
                'merchant.name as merchant_name',
                'merchant_info.*'
            ])
            ->find();
        return $r;
    }

}