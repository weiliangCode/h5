<?php
namespace Home\Model;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

class MerchantModel extends HomeModel {
    /**
     * 检测所修改企业名称是否存在
     * @params array $data 编辑商户信息
     * @return bool
     */
    public function nameVerify($name){
        $r = $this
            ->join('merchant_info_action ON merchant_info_action.merchant_id=merchant.merchant_id','LEFT')
            ->where('merchant_info_action.merchant_name = \''.$name.'\' OR merchant.name=\''.$name.'\'')
            ->find();
//        if(empty($name)){
//            return FALSE;
//        }
//        $r = $this->where('name = \''.$name.'\'')->find();
//        echo $this->getLastSql();exit;
        return $r;
    }

    /**
     * 保存商户相关信息
     * @params array $data 商户请求数据
     * @return bool
     */
    public function saveData($data){
        if(isset($data['merchant_id']) && !empty($data['merchant_id'])){
            //更新
            return $this->where('merchant_id='.$data['merchant_id'])->save($data);
        }else{
            //创建
            return $this->add($data);
        }
    }

    /**
     * 根据转账号(transfer_no),获取信息
     * @param $transfer_no
     */
    public function getMerchantInfoByAppId($merchant_app_id){
        $re = $this
            ->field([
                'merchant_payment_key.se_private_key',
                'merchant.name as merchant_name',
                'merchant.se_payment_code',
                'merchant_app.app_code',
            ])
            ->join('merchant_payment_key ON merchant_payment_key.merchant_id=merchant.merchant_id')
            ->join('merchant_app ON merchant.merchant_id=merchant_app.merchant_id')
            ->where([
                'merchant_app.merchant_app_id' => $merchant_app_id
            ])
            ->find();
        return $re;
    }
}