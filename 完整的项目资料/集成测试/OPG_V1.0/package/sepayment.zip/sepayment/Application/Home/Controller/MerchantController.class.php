<?php
namespace Home\Controller;
use Think\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team ->zhouer
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
class MerchantController extends HomeController{
    private static $short_message_time = 300; // 短信有效时间
    private static $time = 60; // 短信间隔时间

    public function __construct(){
        parent::__construct();
        self::$short_message_time = D('Operate/SysConfig')->SHORT_MESSAGE_TIME;
    }

    /**
     * 激活Live Key
     * Enter description here ...
     * {"act":"2","method":"merchant","op":"ActLiveKey","data":{"account":"379214306@qq.com","name":"suneee5","reg_address":"广东深圳","work_address":"软件产业基地","contact_name":"卓尔","contact_mail":"zhuoer@suneee.com"},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function ActLiveKey(){
        //表单提交
        $name = $this->param->merchant_name;
        $di['merchant_id'] = $this->sessionId->merchant_id;
        $di['reg_address'] = $this->param->reg_address; //注册地址
        $di['work_address'] = $this->param->work_address; //办公地址
        $di['lisence_image'] = $this->param->lisence_image; //企业营业执照副本
        $di['org_image'] = $this->param->org_image; //组织机构代码
        $di['contact_name'] = $this->param->contact_name; //联系人姓名
        $di['contact_mail'] = $this->param->contact_mail; //联系人邮箱
        $di['contact_mobile'] = $this->param->contact_mobile; //联系人手机号码
        $di['apply_user'] = $this->sessionId->account;
        $di['apply_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
        $di['audit_status'] = 1;    //1 资料已提交，待审核

        $obj = D('MerchantInfo');
        $obj->startTrans();

        $e = D('Merchant')->saveData([
            'merchant_id' => $this->sessionId->merchant_id,
            'name'          => $name
//            ,
//            'se_payment_code'          => md5($name)
        ]);
        $r = D('MerchantInfo')->add($di);
        if( $e && $r){
            $obj->commit();
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }

    /**
     * 发送短信验证码接口
     * Enter description here ...
     * {"act":"2","method":"merchant","op":"sendMessageCode","data":{"contact_mobile":"18617121103","sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function sendMessageCode(){
        $sms = D('Operate/SysConfig')->SMS;
        if($sms['active'] != 1){
            $this->returnData['message'] = '短信功能已被禁用,如有疑问请联系翌支付';
            exit(json_encode($this->returnData));
        }
        $reg_user_id = $this->sessionId->reg_user_id;//当前用户账号ID
        {// 短信间隔控制
            $t = self::$redis->get('YZM_time'.$reg_user_id);
            if($t != false){
                $time = self::$time - (time() - $t);
                $this->returnData['code'] = 230;
                $this->returnData['data']=[
                    'less_time' => $time
                ];
                $this->returnData['message'] = '短信功能尚在冷却,请等待'.$time.'秒';
                exit(json_encode($this->returnData));
            }
        }
        //短信接口地址
        $ws = D('Operate/SysConfig')->MESSAGE_HOST;
        $client = new \SoapClient($ws);
        //验证码
        $number = rand(100000, 999999);
        $send['arg0'] = $this->param->contact_mobile;
        $smsContent = $sms['content'];
//        $smsContent = $number;
        $send['arg1'] = str_replace("{#number}",$number,$smsContent);
        // $send['arg2'] = '';
        // $send['arg3'] = '';
        $send['arg4'] = D('Operate/SysConfig')->SERVICECODE;
///////////////////// test start ///////////////////////////
//        $test = [
//            'serivceCode' => D('Operate/SysConfig')->SERVICECODE,
//            'mobiles' => $this->param->contact_mobile,
//            'smsContent' => str_replace("{#number}",$number,$smsContent),
//            'sendTime' => '',
//            'downCode' =>''
//        ];
//        $return = $client->sendBatchSms($test);
//        var_dump($test);
//        var_dump($return);exit;
////////////////////// test end /////////////////
        $return = $client->sendBatchSms($send);

        /**
         *
         * var_dump($return) 成功返回如下;
        object(stdClass)#18 (1) {
        ["return"]=>
        object(stdClass)#19 (4) {
        ["flag"]=>
        bool(true)
        ["reCode"]=>
        string(4) "1000"
        ["reMsg"]=>
        string(15) "发送成功。"
        ["reObj"]=>
        string(60) "[{"smsId":"15549100301","mobile":"15549100301","satus":"1"}]"
        }
        }
         */

        $reObj = $return->return->reObj;
        $reObj = json_decode($reObj, true);

        $status = $reObj[0]['satus'];
        if($status == 1){
            // 缓存发送间隔
            $t = self::$redis->set('YZM_time'.$reg_user_id, time() , self::$time );
            // 缓存验证码
            $r = self::$redis->set('YZM'.$reg_user_id, $number, self::$short_message_time );
            if($r){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }
        }else
            $this->returnData['message'] = '短信发送失败,请稍后重试';
        exit(json_encode($this->returnData));
    }

    /**
     * 根据用户账号ID获取商户审核信息
     * Enter description here ...
     * {"act":"2","method":"merchant","op":"getLiveKeyInfo","data":{"sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}
     *
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function getLiveKeyInfo(){
        $merchant_id = $this->sessionId->merchant_id;//当前用户账号ID

        $MerchantInfo = D('merchantInfo')->getInfo($merchant_id);

        if($MerchantInfo){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            $this->returnData['data']['list'] = $MerchantInfo;
        }
        echo json_encode($this->returnData);
    }

    /**
     * 激活Live Key资料修改接口
     */
    public function updateLiveKey(){
        //表单提交
        $name = $this->param->merchant_name;
        $di['merchant_id'] = $this->sessionId->merchant_id;
        $di['reg_address'] = $this->param->reg_address; //注册地址
        $di['work_address'] = $this->param->work_address; //办公地址
        $di['lisence_image'] = $this->param->lisence_image; //企业营业执照副本
        $di['org_image'] = $this->param->org_image; //组织机构代码
        $di['contact_name'] = $this->param->contact_name; //联系人姓名
        $di['contact_mail'] = $this->param->contact_mail; //联系人邮箱
        $di['contact_mobile'] = $this->param->contact_mobile; //联系人手机号码
        $di['apply_user'] = $this->sessionId->account;
        $di['apply_ts'] = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME'] );
        $di['audit_status'] = 1;    //1 资料已提交，待审核

        $obj = D('MerchantInfo');
        $obj->startTrans();

        $e = D('Merchant')->saveData([
            'merchant_id' => $this->sessionId->merchant_id,
            'name'          => $name
//            ,
//            'se_payment_code'          => md5($name)
        ]);
        $r = D('MerchantInfo')->update($di);

        if(($e!==false) && ($r!==false) && $obj->commit()){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        echo json_encode($this->returnData);
    }

    /**
     * 验证 企业名称 or 验证码
     * Enter description here ...
     * {"act":"2","method":"merchant","op":"verifyFormInfo","data":{"sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ=="},"sign":"456678wewqesa45d64sa56wqe45"}

     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function verifyFormInfo(){
        $name = $this->param->merchant_name;  //企业名称
        $short_message = $this->param->short_message;  //验证码
        $reg_user_id = $this->sessionId->reg_user_id;//当前用户账号ID 

        //企业名称检测
        if(!empty($name)){
            $m_mer = D('Merchant');
            $r_verify = $m_mer->nameVerify($name);
            if($r_verify){
                $this->returnData['code'] = 2011;
                $this->returnData['message'] = '该企业名称已经存在';
            }
            else{
                $this->returnData['code'] = 200;
                $this->returnData['message'] = 'success';
            }
            exit(json_encode($this->returnData));
        }
        //验证码检测
        if(!empty($short_message)){
            $r = self::$redis->get('YZM'.$reg_user_id);
            if(!$r){
                $this->returnData['code'] = 2013;
                $this->returnData['message'] = '验证码已失效';
            }elseif($r == $short_message){
                $this->returnData['code'] = 200;
                $this->returnData['message'] = '验证码正确';
            }else{
                $this->returnData['code'] = 2012;
                $this->returnData['message'] = '验证码不正确';
            }
//            $reg_user = D('RegUser');
//            $d['reg_user_id'] = $reg_user_id;
//            $d['short_message'] = $short_message;
//
//            $s_verify = $reg_user->shortMessageVerify($d);
//            if(!$s_verify){
//                $this->returnData['code'] = 2012;
//                $this->returnData['message'] = '验证码不正确';
//            }
//            elseif(($_SERVER['REQUEST_TIME']-(int)$s_verify[0]['time_message']) > self::$short_message_time ){
//                $this->returnData['code'] = 2013;
//                $this->returnData['message'] = '验证码已过期';
//            }
//            else{
//                $this->returnData['code'] = 200;
//                $this->returnData['message'] = '验证码正确';
//            }
            exit(json_encode($this->returnData));
        }
        $this->returnData['code'] = 0;
        $this->returnData['message'] = '参数错误';
        exit(json_encode($this->returnData));
    }

    /**
     * 解析sessionId,取得用户信息录入的情况
     */
    public function getInfoBySesssionid(){
        // 当前app存在有效的支付渠道
        $app_payment = false;
        // 未提交我的资料 0 ,我的资料修改审核中 1 ,我的资料修改审核不通过 2
        $merchant_active = 0;

        
        $msg = [
            0 => 'liveKey资料未提交',
            1 => 'liveKey资料已提交，待审核',
            2 => 'liveKey资料审核通过，已签约',
            3 => 'liveKey资料审核不通过'
            ,4 => '资料修改审核中,资料审核需1至2个工作日,请耐心等待'
            ,5 => '资料修改审核不通过,您可继续修改!'

            ,6 => 'liveKey审核通过，当前app存在有效的支付渠道'
            ,7 => 'liveKey审核通过，当前app不存在有效的支付渠道'
            ,8 => '我的资料修改审核中, 原liveKey仍然生效,当前app存在有效的支付渠道'
            ,9 => '我的资料修改审核中, 原liveKey仍然生效,当前app不存在有效的支付渠道'
            ,10 => '我的资料修改审核不通过, 原liveKey仍然生效,当前app存在有效的支付渠道'
            ,11 => '我的资料修改审核不通过, 原liveKey仍然生效,当前app不存在有效的支付渠道'
        ];
        $return = function($status) use ($msg){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
            $this->returnData['data']['status'] = $status;
            $this->returnData['data']['message'] = $msg[$status];
            exit(json_encode($this->returnData));
        };
        $merchant_id = $this->sessionId->merchant_id;

        $r = D('MerchantInfo')
            ->where(['merchant_info.merchant_id'=> $merchant_id])
            ->field(['audit_status'])
            ->select();
        if(!$r){
            $return(0);
        }
        $status = $r[0]['audit_status'];
        if($status != 2 )
            $return($status);
        {// 我的资料状态赋值 $merchant_active
            $re = D('MerchantInfoAction')
                ->where(['merchant_id'=> $merchant_id])
                ->field(['audit_status'])
                ->order('apply_ts desc')
                ->find();
            if($re){
                if($re['audit_status'] == 1)
                    $merchant_active = 1;
                elseif($re['audit_status'] == 3)
                    $merchant_active = 2;
            }
        }
        if(!is_null($this->param->merchant_app_id)){
            {// 前app存在有效的支付渠道 $app_payment 赋值;
                $e = D('MerchantPaymentConfig')
                    ->where(['merchant_app_id'=> $this->param->merchant_app_id])
                    ->select();
                if($e) $app_payment = true;
            }
            if($merchant_active ===0)
                $app_payment===true ? $return(6):$return(7) ;
            elseif($merchant_active ===1)
                $app_payment===true ? $return(8):$return(9) ;
            elseif($merchant_active ===2)
                $app_payment===true ? $return(10):$return(11) ;
        }
        if($merchant_active === 1)
            $return(4);
        elseif($merchant_active === 2)
            $return(5);
        else $return(2);
    }
}