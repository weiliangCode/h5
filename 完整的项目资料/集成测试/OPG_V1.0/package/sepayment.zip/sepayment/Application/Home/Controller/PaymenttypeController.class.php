<?php
namespace Home\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team ->test
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
// 支付渠道管理
class PaymenttypeController extends HomeController{
    // 平台支付渠道启用状态
    private $paymentType = [];
    private $search = [];
    private $searchString = '1';
    private $limit = '';
    private $order = '';
    // 商户的支付渠道查询接口, 需要返回的字段
    private $key = [
        'payment_type.payment_type_id',
        'payment_type.name as pname',
        'merchant_payment_channel.active_status',
        'merchant_payment_channel.admin_op',
        'merchant_payment_channel.audit_reason',
        'payment_type.active'
    ];
    public function __construct(){
        parent::__construct();
        $temp = D('PaymentType')->field(['payment_type_id','active'])->select();
        foreach($temp as $k=>$v){
            $this->paymentType[$v['payment_type_id']] = $v['active'];
        }
    }
    // 商户的支付渠道查询接口
    // {"act":"2","method":"Paymenttype","op":"paymentsList","data":{"merchant_id":"1","payment_type_id":"1","active_status":"1","audit_reason":"test!!"},"sign":"456678wewqesa45d64sa56wqe45"}
    public function paymentsList(){
        if($this->searchSql() && $this->pageSql() && $this->getData() ){
            $this->returnData['code'] = 200;
            $this->returnData['message'] = 'success';
        }
        exit(json_encode($this->returnData));
    }
    /**
     * 根据查询条件,
     * @return $this->search
     */
    private function searchSql(){
        $this->search['merchant_payment_channel.merchant_id'] = $this->sessionId->merchant_id;
//        $this->search['merchant_payment_channel.merchant_id'] = 33;
        if(!is_null($this->param->payment_type_id))
            $this->search['payment_type.payment_type_id'] = $this->param->payment_type_id;
        if(!is_null($this->param->status)){
            if($this->param->status === '已开启' || $this->param->status === '已启用'){
                $this->searchString = 'payment_type.active=1 AND merchant_payment_channel.active_status=3';
            }elseif($this->param->status === '已关闭' || $this->param->status === '已禁用'){
                $this->searchString = 'payment_type.active!=1 OR merchant_payment_channel.active_status!=3';
            }
        }
        return true;
    }
    /**
     * 根据分页条件,
     * @return $this->order
     */
    private function pageSql(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $this->limit .= $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize);
        return true;
    }
    /**
     * 数据操作
     * @return $this->returnData
     */
    private function getData(){
        $obj = D('MerchantPaymentChannel');
        $this->returnData['data']['pages']['total_count'] = $obj->getCount($this->search, $this->searchString);
        $temp = $obj->searchData($this->key, $this->search, '('.$this->searchString.')', $this->order, $this->limit);
//echo $obj->getLastSql();
//        var_dump($temp);exit;

        foreach($temp as $k=> $v){
            $re = D('AppPaymentChannel')
                ->where([
                    'merchant_app.merchant_id' => $this->sessionId->merchant_id,
                    'merchant_app.status_del' => 0,
                    'app_payment_channel.payment_type_id' => $v['payment_type_id']
                ])
                ->join('merchant_app on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id')
                ->field([
                    'merchant_app.merchant_app_id',
                    'merchant_app.app_name'
                ])
                ->group('merchant_app.merchant_app_id')
                ->select();
            if($re)
                $temp[$k]['apps'][] = $re;
            else $temp[$k]['apps'] = [];

            if( $this->paymentType[$v['payment_type_id']] == '0'){
                $temp[$k]['active_status'] = '5';
            }
            elseif( ($v['active_status'] != '3' )  && ($v['admin_op'] == '1'))
                $temp[$k]['active_status'] = '7';
        }
        /////////////
//        foreach ($temp as $k=>$v){
//            if( $this->paymentType[$v['payment_type_id']] == 0 ){
//                $temp[$k]['active_status'] = '5';
//                continue;
//            }
//            if(isset($this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']])){
//                loop : if($this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']] != 3){
//                    $temp[$k]['active_status'] = '6';
//                }
//            }else{
//                $where = [
//                    'merchant_id'=>$v['merchant_id'],
//                    'payment_type_id'=>$v['payment_type_id'],
//                ];
//                $tmp =  D('MerchantPaymentChannel')
//                    ->field('active_status')
//                    ->where($where)
//                    ->select();
//                $this->paymentTypeCompany[$v['merchant_id']][$v['payment_type_id']] = $tmp[0]['active_status'];
//                goto loop;
//            }
//        }
        ///////////////////
        $this->returnData['data']['list'] = $temp;
        return true;
    }
//--------------------------------------------- 支付渠道下的应用查询接口 ----------------------------------------------//
//{"act": "2","data": {"page_no":"1","page_size":"10","payment_type_id":"1","sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ"},"method": "Paymenttype","op":"appListByPayment","sign": "6243550b82f2697caeb88393992e630d"}
    public function appListByPayment(){
        $this->returnData['data']['pages'] = array('page_index' => 1, 'page_size' => 5);
        $page = intval($this->param->page_no) < 1 ? $this->returnData['data']['pages']['page_index'] : intval($this->param->page_no);
        $pageSize = intval($this->param->page_size) < 1 ? $this->returnData['data']['pages']['page_size'] : intval($this->param->page_size);
        $offset = ($page - 1) * $pageSize;
        $limit = $offset.','.$pageSize;
        $this->returnData['data']['pages'] = array(
            'page_index' => $page,
            'page_size' => $pageSize
        );
        $count = D('AppPaymentChannel')
            ->where([
                'app_payment_channel.payment_type_id' => $this->param->payment_type_id,
                'merchant_app.merchant_id' => $this->sessionId->merchant_id
            ])
            ->field('count(*) as a')
            ->join('merchant_app on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id AND status_del=0')
            ->join('merchant_payment_channel on merchant_app.merchant_id=merchant_payment_channel.merchant_id AND merchant_payment_channel.payment_type_id="'.$this->param->payment_type_id.'"')
//            ->group('merchant_app.merchant_app_id')
            ->select();

//        $num = count($count);
//        $this->returnData['data']['pages']['total_count'] = $num;
        $this->returnData['data']['pages']['total_count'] = $count[0]['a'];

        $temp = D('AppPaymentChannel')
            ->where([
                'app_payment_channel.payment_type_id' => $this->param->payment_type_id,
                'merchant_app.merchant_id' => $this->sessionId->merchant_id
            ])
            ->join('merchant_app on merchant_app.merchant_app_id=app_payment_channel.merchant_app_id AND status_del=0')
            ->join('merchant_payment_channel on merchant_app.merchant_id=merchant_payment_channel.merchant_id AND merchant_payment_channel.payment_type_id="'.$this->param->payment_type_id.'"')
            ->join('payment_scenary on payment_scenary.scenary_id=app_payment_channel.scenary_id')
            ->field([
                'merchant_app.merchant_app_id',
                'merchant_app.app_name',
                'merchant_payment_channel.active_status as merchant_active_status',
                'merchant_payment_channel.admin_op as merchant_admin_op',
                'app_payment_channel.active_status',
                'app_payment_channel.audit_reason',
                'app_payment_channel.admin_op',
                'app_payment_channel.payment_type_id',
                'app_payment_channel.scenary_id',
                'payment_scenary.name as scenary_name'
            ])
//            ->group('merchant_app.merchant_app_id')
            ->limit($limit)
            ->select();
//        echo D('AppPaymentChannel')->getLastSql();
//        var_dump($temp);exit;
        foreach ($temp as $k=>$v){
            if( $this->paymentType[$v['payment_type_id']] == 0 ){
                $temp[$k]['active_status'] = '5';
                continue;
            }
            elseif($v['merchant_active_status'] != 3){
                $temp[$k]['active_status'] = $v['merchant_admin_op'] == 1 ? '7' : '6';
                continue;
            }
            elseif( ($v['active_status'] !=3 ) && ($v['admin_op'] == 1 )){
                $temp[$k]['active_status'] = '8';
                continue;
            }
        }
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
        $this->returnData['data']['list'] = $temp;
        exit(json_encode($this->returnData));
    }

//----------------------------------------------- 查询 ( 应用 ) 可用的支付渠道 -------------------------------------------//
    //{"act":"2","data": {"merchant_app_id":"3","sessionId":"U2x4WGFoY1NVUk52VVZjTlUwZGRVMElCWFZJSVJqd0lYRjRGRTFoVlZBcE5WMFFJR0FsQkRsVktGZ1JTRWtWWVZRZFFIUVZkRGtkTEYxVkJURVVLVkE9PQ"},"method": "Paymenttype","op":"getPaymenttypeByAppId","sign": "6243550b82f2697caeb88393992e630d"}

    public function getPaymenttypeByAppId(){
        $payment_type_name = D('Operate/SysConfig')->PAYMENT_TYPE_NAME;
        if(!is_null($this->param->merchant_app_id)){
            $data = D('PaymentType')
                ->join('merchant_app ON merchant_app.merchant_app_id = "'.$this->param->merchant_app_id.'"')
                ->join('merchant_payment_channel ON payment_type.payment_type_id = merchant_payment_channel.payment_type_id AND merchant_payment_channel.merchant_id=merchant_app.merchant_id AND merchant_payment_channel.active_status = 3')
                ->join('app_payment_channel ON payment_type.payment_type_id = app_payment_channel.payment_type_id AND app_payment_channel.merchant_app_id ="'.$this->param->merchant_app_id.'" AND app_payment_channel.active_status = 3','LEFT')
                ->field([
                    'payment_type.payment_type_id',
                    'payment_type.name',
                    'payment_type.code',
                    'payment_type.active',
                    'payment_type.is_transfer',
                    'payment_type.type'
                ])
                ->where(['payment_type.active'=>1])
                ->select();
        }elseif(!is_null($this->param->active)){
            $data = D('PaymentType')
                ->field([
                    'payment_type.payment_type_id',
                    'payment_type.name',
                    'payment_type.code',
                    'payment_type.active',
                    'payment_type.is_transfer',
                    'payment_type.type'
                ])
                ->where(['payment_type.active'=>1])
                ->select();
        }
        else $data = D('PaymentType')->select();
        foreach($data as $k => $v){
            $data[$k]['type_name'] = $payment_type_name[$v['type']];
        }
        $this->returnData['data']['list'] = $data;
        $this->returnData['code'] = 200;
        $this->returnData['message'] = 'success';
//        echo D('PaymentType')->getLastSql();exit;
//        var_dump($this->returnData['data']['list']);exit;
        exit(json_encode($this->returnData));
    }
}