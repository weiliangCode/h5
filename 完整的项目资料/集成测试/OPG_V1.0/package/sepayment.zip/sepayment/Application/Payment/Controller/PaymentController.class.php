<?php
namespace Payment\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

use Think\Log;
use Think\Controller;

//载入公用函数库,用于加载第三方支付接口
require(APP_PATH.MODULE_NAME.'/Common/common.php');

/**
 * 支付网关的父控制器
 * 
 * 主要封装了所要用到的基本业务方法,比如参数验证, 签名, 回调
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
abstract class PaymentController extends Controller {
	
	/**
	 * 当前环境
	 */
	protected $env;

	/**
	 * 当前环境配置
	 */
	protected $env_conf = '';
	
	/**
	 * 当前site url
	 */
	 protected $site_url = '';
	
	
	/**
	 * 记录状态, TRUE,1,为正常状态, 其它的包括 FALSE, 0 为系统异常状态, 'String' 为具体的程序错误状态
	 * 
	 * @type string 记录当前具体的错误状态
	 */
	
	protected $status = 1;
	
	/**
	 * 记录状态信息
	 */
	protected $status_msg = 'success';
	
	/**
	 * 商户信息
	 */
	protected $merchant_info = '';	
	
	/**
	 * se同步通知url, 是给第三方支付平台的同步url
	 */
	protected $return_url = '';
	
	/**
	 * se异步通知接口
	 * 
	 * @type string
	 */
	protected $notify_url = '';
	
	/**
	 * 商户数据信息
	 * 
	 * 包括商户的认证号,私钥等信息
	 * 
	 * @type object
	 */
	protected $merchant_data = '';
	
	/**
	 * 流水数据
	 * 
	 * @type string
	 */
	protected $pay_request_data = array();

	/**
	 * @var array
	 * 商户信息
	 */
	protected $pay_merchant_data = array();

	/**
	 * @var array
	 * 支付类型数据
	 */
	protected $pay_type_data = array();
	/**
	 * 支付的入口方法
	 */
    public function __construct($env='')
    {
    	parent::__construct();
    	//得到当前环境
    	if($_SERVER['OPG_ENV'])
    	{
    		$this->env = $_SERVER['OPG_ENV'];
    	}
    	 $this->env_conf = C('ENV')[$this->env];

    	//得到环境中的site_url
    	$site = C('ENV.'.$this->env);
    	$this->site_url = $site['site_url'];
    	$this->assign('env', $this->env);
    	$this->assign('site_url', $this->site_url);
    	//因为有非模板类型的直接输出,则设置当前header的默认编码信息
    	header("content-type:text/html;charset=utf-8");

		//请求参数
		//$this->param;
    	//1. 检查协议
		// $this->_check_protocal();
		
    }
    
    /**
     * 检查协议层, 只能https进行调试
     * 
     * @return void
     */
    private function _check_protocal()
    {
    	//判断协议是否请求https, 如果否拒绝
        if($_SERVER['HTTPS'] != "on")	//目前是调试阶段采用 http
        {
        	exit('Illegal access');
        }
    }

    
    /**
     * curl请求提交模式
     * 
     * @params string 提交地址
     * @params array 需要提交的参数
     * @parmas string 提交方式 post/get
     * 
     * 提交到客户端都需要用 sign 签名字段
     */
    protected function curl($url, $params = array(), $type='POST',$proxy=FALSE)
    {
    	return curl($url, $params, $type,$proxy);
    }
    /**
     * curl请求提交模式
     *
     * @params string 提交地址
     * @params json 需要提交的参数
     * @parmas string 提交方式 post/get
     *
     */
    protected function curl_json($url, $data_string)
    {
    	if($url && $data_string)
	   {
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, $url);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");     
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);           
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );        
        $return = curl_exec($ch); 
        curl_close($ch);

        return $return?$return:false; 
	   }
    }    
    /**
     * 组合签名
     * 
     * @params array $params 签名参数
     * @params string/array $params_conf 签名配置
     * 
     * @return string/FALSE
     */
    protected function build_sign($params, &$params_conf, $key){

        if(empty($params) || empty($params_conf) || empty($key)){
            $this->set_status('EMPTY_SIGN_PARAMS', 'there is empty params for sign');
            return false;
        }

        $str = '';

        //组合签名
        if(is_array($params_conf)){
            foreach( $params_conf as $k => $v ){
                //配置了参数
                if(isset($v['is_sign']) && $v['is_sign']){
                    //如果为空则返回
                    if(isset($params[ $k ]) && !empty($params[ $k ])){
                        $str .= $params[ $k ];    //组合签名值
                    }
                    else{
                        $this->set_status('EMPTY_SIGN_VALUE', 'there is empty value for sign('.$k.')');
                        return false;
                    }
                }
            }

        }
        else{
            $this->set_status('INVALID_PARAMS_CONF', 'there is invalid conf for sign');
            return false;
        }

        if(empty($str)){
            $this->set_status('EMPTY_SIGN_PARAMS', 'there is empty sign params');
            return false;
        }
        //秘钥组合组合式md5签名
        $str = md5(md5($str).$key);

        return $str;
    }
    
     /**
     * 校验所有参数
     * 
     * @params array $p 需要验证的参数数组
     * @params array $pconf 参数格式配置
     * 
     * @return bool
     */
    protected function verify_all_params(&$p, &$pconf){
//        var_dump(func_get_args());exit;
        //检查各个需要的参数是否都存在于$_POST
        foreach( $pconf as $k => $t ){

            //如果参数不存在或则为空
            if(!isset($p[ $k ])){
                //如果必填,参数不存在则报错
                if(isset($t['is_request']) && $t['is_request']){
                    $this->set_status('REQUIRED_PARAMS', "the params $k is required");
                    return false;
                }
                //如果不必填, 则初始一个默认值
                else{
                    if(isset($t['default'])){
                        $p[ $k ] = $t['default'];
                    }
                    else{
                        $p[ $k ] = '';
                    }
                }
            }
            //校验参数格式是否正确
            $r = $this->verify_params($p[ $k ], $t);
            if(!$r){
                $this->set_status('INVALID_PARAMS', "the params $k verify failed");
                return false;
            }
        }
        return true;
    }
    
    
    /**
     * 校验参数
     * 
     * @params string $pval 参数值
     * @params array $verify_rule 验证规则
     * 
     * @return bool
     */
    protected function verify_params($pval, &$verify_rule)
    {
    	//检查基本参数是否合法
    	if(empty($verify_rule) || !is_array($verify_rule))
    	{
    		return FALSE;
    	}

    	//--检查具体的参数规则
    	
    	//检查是否必填
    	$is_required = FALSE;
    	if(isset($verify_rule['is_required']))
    	{
    		$is_required = $verify_rule['is_required'];
    	}

    	//验证必填
    	if($is_required)
    	{
    		if($is_required==2)
    		{
    			return TRUE;
    		}
    		//如果必填值为空则返回FALSE (不能只包含空格)
    		if(empty($pval) || trim($pval)=='')
    		{
    			return FALSE;
    		}
    	}
    	//验证非必填
    	else
    	{
    		//如果非必填,值为空直接返回TRUE (如果有空格,也要进行下面格式和范围的校验)
    		if(empty($pval))
    		{
    			return TRUE;
    		}    		
    	}

    	//检查整型类型
    	$type = 'string';
    	if(isset($verify_rule['type']))
    	{
    		$type = $verify_rule['type'];
    	}

    	$min_size = 0;
    	$max_size = 0;
    	$has_size = FALSE;
    	if(isset($verify_rule['size']) && !empty($verify_rule['size']))
    	{
    		$s = explode(',',$verify_rule['size']);
    		$min_size = (int)$s[0];
    		$max_size = isset($s[1]) ? (int)$s[1] : (int)$s[0];
    		$has_size = TRUE;
    	}


    	switch($type)
    	{
    		//字符串
    		case 'string':
    			if(!is_string($pval))
    			{
    				return FALSE;
    			}
    			$len = strlen($pval);

    			if($has_size && ($len<$min_size || $len>$max_size))
    			{
    				return FALSE;
    			}	
    			break;
    		//整型(整数位11个)
    		case 'int':
    			if(!preg_match('/^[1-9]\d{0,10}$/', $pval))
    			{
    				return FALSE;
    			}
    			$v = (int)($pval);
    			if($has_size && ($v<$min_size || $v>$max_size))
    			{
    				return FALSE;
    			}    			
    			break;
    			
    		//浮点型(整数位11个, 小数位4位内)
    		case 'float':
    			if(!preg_match('/^((\d)|([1-9]\d{0,10}))(\.\d{1,4})?$/', $pval))
    			{
    				return FALSE;
    			}
    			$v = (float)($pval);
    			if($has_size && ($v<$min_size || $v>$max_size))
    			{
    				return FALSE;
    			}
    			break;
    			
    		//时间戳(1440927045)
    		case 'time':
    			if(!is_numeric($pval))
    			{
    				return FALSE;
    			}
    			$len = strlen($pval);
    			if($len != 10)
    			{
    				return FALSE;
    			}
    			break;
    		
    		//时间串(Y-m-d H:i:s, 2015-08-31:20:00:00)
    		case 'datetime':
    			//
    			if(!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $pval))
    			{
    				return FALSE;
    			}
    			$len = strlen($pval);
    			if($len != 19)
    			{
    				return FALSE;
    			}
  		
    			break;
    	}

    	return TRUE;
    }

	/**
	 * 更新状态
	 * 需要在业务model层去实现update_status
	 * 
	 * @params string $model_name 模块名
     * @params string $request_no 请求号
     * @params string $suc_code 成功状态编码
     * @params string $failed_code 失败状态编码
     * @params array 更新$update_data表的字段值
     * @params string $result 错误状态 error status
     * 
     * @return bool
	 */
	protected function update_status($model_name, $request_no, $success_code, $failed_code, $update_data=array())
	{
		//记录错误状态
		if($this->has_err())
		{
			return D($model_name)->update_status($request_no, $success_code, $failed_code, $update_data, $this->errlog('', FALSE));
		}
		//记录正确状态
		else
		{
			 return D($model_name)->update_status($request_no, $success_code, $failed_code, $update_data);
		}
	}

	/**
	 * 是否有错误
	 * 
	 * @return bool
	 */
	protected function has_err()
	{
		if(empty($this->status) || $this->status==1)
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	/**
	 * 得到状态类型
	 * 
	 * @return string 得到错误类型
	 */	
	protected function get_status_type()
	{
		//正常值
		if($this->status === TRUE || $this->status==1)
		{
			return C('error_status')['1'];
		}
		//错误值
		if(!$this->status)
		{
			return C('error_status')['0'];
		}
		//错误状态
		return isset(C('error_status')[$this->status]) ? C('error_status')[$this->status] : 'UNKNOW_ERROR: '.$this->status;
		
	}
	
	/**
	 * 得到环境配置
	 * 
	 * @return array ENV 得到当前的环境
	 */
	protected function get_env_conf()
	{
		return $this->env_conf;
	}
	
	/**
	 * 设置状态
	 * 
	 * @params bool/string $status 状态代码
	 * @params string 状态消息
	 * 
	 * @return void
	 */
	protected function set_status($status=1, $msg='')
	{
		$this->status = $status;
		$this->status_msg = $msg;
	}
	
	/**
	 * 检查第三方返回状态
	 * 
	 * return array(
	 *     //SE支付网关的状态 
	 *     'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
	 *     //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
	 *     'status_msg' => '签名错误'
	 * );
	 * 
	 * @return void
	 */
	protected function check_third_return_val($result)
	{
		//状态为空则默认成功
		if(empty($result))
		{
			$this->set_status(TRUE, '');
			return;
		}
		//成功的状态值
		if($result['status']==1 || $result['status']==='SUCCESS')
		{
			$this->set_status(TRUE, '');
		}
		//错误状态
		else
		{
			$this->set_status($result['status'], $result['status_msg']);
		}		
	}
  
  
    /**
     * 生成id的编号字符串,需要加上$id种子 (默认16位置)
     * 
     * @params int $id //ID值
     * @params string $prefix //前缀
     * @params int $length //长度
     * 
     * return string 
     * 
     */
  	protected function get_idno($id, $prefix='', $length=16)
  	{
  		$total = $length-6;  //6为ymd年月日长度
  		$pflen = 0;
  		if(!empty($prefix))
  		{
  			$pflen = strlen($prefix); //前缀长度
  			$total -= $pflen;
  		}
  		
  		$yv = '1';	//最大求余基数
  		$n=0;
  		while($n<$total)
  		{
  			$yv .= '0';
  			++$n;
  		}
  		$yv*=1;
  		
  		//序号值=求余后的值
  		$no=$id%$yv;
 
		$nlen = strlen($no);
		
		//剩余字符位数=除去日期6位和前缀的位数
		$ln = $total-$nlen;
		$bstr = '';
		while($ln>0)
		{
			$bstr.='0';
			--$ln;
		}
		$bstr = $prefix.date('ymd').$bstr.$no;
		return substr($bstr, 0, $length);  		
  	}
  
    /**
     * 错误日志
     * 
     * @params string $msg 错误消息
     * @params boolean $is_display 是否显示错误
     * 
     * @return bool
     */
    protected function errlog($status_msg='', $is_display=TRUE)
    {
		$error = FALSE;
		$msg = '';
		//如果类状态消息不为空, 则赋值消息
		if(!empty($this->status_msg))
    	{
			$msg = '->' . $this->status_msg;
    	}
    	
		//如果消息不为空, 则赋值消息
		if(!empty($status_msg))
		{
			$msg = $msg . ', ' . $status_msg;
		}
		
		//如果有错误则记录到当前的日志  Error[错误状态类型]->[错误状态]
		if($this->has_err())
		{
			//得到错误信息,并记录到日志中
			$error = 'ERR[' . $this->get_status_type() . ']->[' . $this->status . ']' . $msg;
			\Think\Log::write($error, 'ERR');
			
			//是否退出,如果退出则显示错误页面,否则
			if($is_display == TRUE)
			{   	
				//默认为终止退出程序,并显示错误页面
				$is_mobile = is_mobile();

                $result['type'] = $this->get_type();
                $result['msg'] = $this->status_msg;
				$result['status'] = $this->status;
				$result['return_url'] = !empty($this->return_url) ? $this->return_url : "javascript:; return false;";
				$this->assign('result', $result);
				
				//显示web/wap的错误信息页面
				if($is_mobile)
				{
					$this->display('/Sys/wap_error');
				}
				else
				{
					$this->display('/Sys/web_error');
				}
				exit;
			}
		}
		//强行输出错误
		else
		{
			$this->set_status('FAILED', 'force to exit');
			//得到错误信息,并记录到日志中
			$error = 'ERR[' . $this->get_status_type() . ']->[' . $this->status . ']->' . $this->status_msg . $msg;
			\Think\Log::write($error, 'ERR');			
			
			//是否退出,如果退出则显示错误页面,否则
			if($is_display == TRUE)
			{ 
				//默认为终止退出程序,并显示错误页面
				$is_mobile = is_mobile();
				
				$result['type'] = $this->get_type();
				$result['status'] = FALSE;
				$result['return_url'] = $this->return_url;
				$this->assign('result', $result);
				
				//显示web/wap的错误信息页面
				if($is_mobile)
				{
					$this->display('/Sys/wap_error');
				}
				else
				{
					$this->display('/Sys/web_error');
				}
				exit;				
			}			
		}
		//返回错误信息
		return $error;
    }

    /**
     * 发送邮件
     * 
     * @return TRUE/error_msg
     */
    protected function send_mail($to_email, $title='', $content='')
    {
    	if(empty($to_email) || empty($title) || empty($content))
    	{
    		$this->set_status('SEND_MAIL_FAILED', 'send mail failed for invalid params.');
    		return FALSE;
    	}

    	$mail = load_pm_lib('phpmailer/PHPMailer'); //实例化phpmailer
    	
		try {
			$mail->IsSMTP();
			$mail->CharSet='UTF-8'; //设置邮件的字符编码，这很重要，不然中文乱码
			$mail->SMTPAuth   = true;                  //开启认证
			$mail->Port       = 25;                    
			$mail->Host       = $this->env_conf['mail']['host']; 
			$mail->Username   = $this->env_conf['mail']['username'];    
			$mail->Password   = $this->env_conf['mail']['password'];            
			//$mail->IsSendmail(); //如果没有sendmail组件就注释掉，否则出现“Could  not execute: /var/qmail/bin/sendmail ”的错误提示
			$mail->AddReplyTo($this->env_conf['mail']['replyTo']);//回复地址
			$mail->From       = $this->env_conf['mail']['from'];     
			$mail->FromName   = $title;
			$to = $to_email;
			$mail->AddAddress($to_email);
			$mail->Subject  = $title;
			$mail->Body = $content;
			//$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; //当邮件不支持html时备用显示，可以省略
			$mail->WordWrap   = 80; // 设置每行字符串的长度
			//$mail->AddAttachment("f:/test.png");  //可以添加附件
			$mail->IsHTML(true); 
			
			$r = $mail->Send();
			
			if($r!==true){
				$this->set_status('SEND_MAIL_FAILED', 'send mail failed.');
			}
			
			return $r;
			
		} catch (phpmailerException $e) {
			//echo "邮件发送失败：".$e->errorMessage();
			$this->set_status('SEND_MAIL_EXCEPTION', 'send mail exception, ' . $e->errorMessage());
			return FALSE;
		}    	
    	
    	
    }
    

    /**
     * 得到类型,用来给模板区分具体的动作
     */
    public function get_type()
    {
    	return '';
    }

	/**
	 * @param $app_code
	 * @param $merchant_id
	 * @return bool
	 * 获取应用ID/编码
	 *
	 */
 	public function get_app_id($app,$merchant_id)
	{
		if(!$app || !$merchant_id)
		{
			return false;
		}

		$appResult = self::$redis->get("{$merchant_id}_app_{$app}");

		if(!$appResult)
		{
			$appResult = D('MerchantApp')->get_by_app($app,$merchant_id);

			self::$redis->set("{$merchant_id}_app_{$app}",$appResult,C('cache_expire'));
		}
		return $appResult;
	}


	/**
	 * @param $se_payment_code
	 * @return bool
	 * 获取商户信息
	 */
	public function get_merchant_info($se_payment_code)
	{
		if(!$se_payment_code)
		{
			return false;
		}
		//是否存在缓存数据，没有则重新获取
		$merData = self::$redis->get($se_payment_code);
//        $merData = false;  // 开发关闭缓存
		if(!$merData)
		{
			$merData = D('Merchant')->get_by_payment_code($se_payment_code);
			self::$redis->set($se_payment_code,$merData);
		}
		return $merData;
	}

	/**
	 * @param $pay_no
	 * @return bool
	 * 获取流水数据
	 */
	protected function get_pay_info($pay_no)
	{
		if(!$pay_no)
		{
			return false;
		}
		//是否存在缓存数据，没有则重新获取
        $payInfo = self::$redis->get("{$pay_no}_request");
//        $payInfo = false; // 开发关闭缓存
		if(!$payInfo || $payInfo['pay_no']!=$pay_no)
		{
			$payInfo = D('Merchant')->get_merchant_pay_data_by_pay_no($pay_no);
			self::$redis->set("{$pay_no}_request",$payInfo,C('cache_expire'));
		}
		return $payInfo;
	}
    /**
     * 得到场景,用来加载支付渠道具体行为(待处理)
     */
    public function get_scene_type($scenary_id)
    {
    	switch ($scenary_id) {
    		case '1':
    			$scene = 'web';
    			break;
    		case '2':
    			$scene = 'wap';
    			break;
    		case '3':
    			$scene = 'ios';
    			break;
    		case '4':
    			$scene = 'android';
    			break;    			    			    		
    	}
    	// return $scene === 'PC'?'web':'wap';
    	return $scene;
    }	
}