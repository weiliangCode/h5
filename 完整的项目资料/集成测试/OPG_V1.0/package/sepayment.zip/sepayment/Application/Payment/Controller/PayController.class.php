<?php
namespace Payment\Controller;
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;
use Think\Log;
/**
 * 支付控制器
 * 
 * 这是支付的入口
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
class PayController extends PaymentController {
	
	/**
	 * 支付号, 商户第二次回调请求会带支付号过来。
	 * 
	 * @type string
	 */
	protected $pay_no = '';
	
	/**
	 * 支付请求id
	 */
	protected $pay_request_id = '';
	
	/**
	 * 支付类型ID
	 */
	protected $payment_type_id = '';

	/**
	 * @var array
	 * 支付类型信息
	 */
	protected $payment_type = array();

	/**
	 * @var array
	 * 支付请求数据
	 */
	protected $payment_data = array();
	/**
	 * @var \Model
	 * 模型对象
	 */
	protected $mer;
	/**
	 * 请求参数
	 */
	//protected $param;
	/**
	 * 构造
	 */
    public function __construct()
    {
        parent::__construct();
        $this->param = I('get.') ? I('get.') : I('post.');
		$this->mer = D('Merchant');
		//$this->param;   继承父类请求参数
    }
    
    /**
     * 支付的入口
     * 
     * a. 商户站点支付请求的入口
     * b. 得到支付号再次请求
     * c. 转向支付处理
     */
    public function index()
    {
		//1. 检查参数合法性, 验证通过才入库
		 $this->check_params();
	   // $this->payment_type_id=$p['payment_type_id'];//公共支付存在支付类型
		$this->use_json = (isset($this->param['use_json']) && $this->param['use_json'] ==1) ? true :false;
		//2.1 如果是第一次请求应该创建支付请求并返回支付请求号
		if(!$this->pay_no)
		{
            // 是否存在 '参数错误';
			if($this->has_err())
			{
				$this->errlog('verify params failed for first pay request');
			}
			//3. 记录一条新支付请求记录
			$this->create_pay_request();
			//4. 返回支付号, 中断程序
			if(!empty($this->pay_no))
			{
				exit($this->pay_no);
			} 
			else
			{
				$this->errlog('create pay request failed');
			}
			
			//3. 这里不做参数验证入库, 更新状态为  11, 12  请求验证成功, 请求验证失败
			//$r = $this->update_status('PayRequest', $this->pay_no, 11, 12);	
		}
		//2.2 如果是有支付号的请求(第二次)直接进入支付通道选择页面
		else
		{
			//3. 更新状态为  13, 14  //支付号请求验证成功, 支付号请求验证失败
			 $r = $this->update_status('PayRequest', $this->pay_no, 13, 14);
			if(!$r || $this->has_err())
			{
				$this->errlog('verify params failed for second pay request');
			}
			//发起支付
			$this->pay();
		}
		exit;
    }

	/**
	 *  处理支付请求
	 *	1.未选择支付方式，根据请求来源区分跳转web/wap收银台
	 * 	2.已选支付方式，直接发起该方式支付
	 *  3.API请求，返回json数据
	 */
	protected function pay()
	{
		if($this->pay_no)
		{
			$this->pay_request_data = $this->get_pay_info($this->pay_no);

			$this->payment_type_id = $this->pay_request_data['payment_type_id'];
			
			//是否是获取json返回数据
			if($this->use_json)
			{
/*				$pay_url = $_SERVER['HTTP_HOST'].'/payment/pay?'.'pay_no='.$this->param['pay_no'].'&created_ts='.$this->param['created_ts'].'&se_sign='.$this->param['se_sign'];
			    $this->returnData['code'] = 200;
		        $this->returnData['message'] = 'success';   
		        $this->returnData['data']['pay_url'] = $pay_url;
		        exit(json_encode($this->returnData));*/
		        $this->pay_app();				
			}

			//是否是SDK支付
			if($this->pay_request_data['scenary_id'] == 3 || $this->pay_request_data['scenary_id'] == 4)
			{
				$this->pay_sdk();
				exit;
			}

			//是否选择了支付方式
			if($this->payment_type_id)
			{
				//已选支付方式，直接进入该支付渠道
				$this->pay_api();
				exit;
			}
			// 响应当前的表单选择页面
			$this->display_pay_select();
		}
	}

    /**
     * FLOW 校验参数 (该流程校验不会退出程序,只有记录入库后才根据状态去决定是否退出)
     * 
     * a. 如果验证失败则直接返回错误调用到商户站点回调页
     * b. 更新会话记录状态 '11/12 | 13/14', 新增支付请求流水记录状态为'11/12 | 13/14'
     * 
     * @return boolean TRUE 继续执行, FALSE 回调告诉错误,并终止逻辑
     */
    protected function check_params()
    {
    	//得到需检查的参数  $this->param
		//$p = I('get.')?I('get.'):I('post.');

		//得到支付的配置
		$conf = C('pay');

		//定义配置
		$pconf = '';
		$merchantInfo = '';
    	//验证第一次请求(检查没有包含支付号的请求)
    	if(!isset($this->param['pay_no']))
    	{
    		//得到返回url,供返回使用
    		$this->return_url = $this->param['return_url'];
    		//添加支付方式
    		$this->payment_type_id = $this->param['payment_type_id'];
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payresult'];

			//验证参数的合法性
			$r = $this->verify_all_params($this->param,$pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错
				return FALSE;
			}

			//验证授权号
			//$merchant_info = $this->mer->get_by_payment_code($this->param['se_payment_code']);
			$merchantInfo = $this->get_merchant_info($this->param['se_payment_code']);
			if(!isset($merchantInfo['se_payment_code']) || !isset($merchantInfo['se_private_key']) || empty($merchantInfo['se_payment_code']) || $merchantInfo['se_payment_code']!=$this->param['se_payment_code'])
			{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code: ' . $this->param['se_payment_code']);
				return FALSE;

			}

			//验证签名
			 $se_sign = $this->build_sign($this->param, $pconf, $merchantInfo['se_private_key']);



	    	if(!$se_sign || $this->param['se_sign'] != $se_sign)
	    	{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_SIGN', 'this is invalid sign: ' . $this->param['se_sign']);
	    		return FALSE;
	    	}

			//如果验证通过，将商户信息加入请求数据当中
			$this->param['merchant_id'] = $merchantInfo['merchant_id'];


    	}
    	else
    	//验证第二次请求(检查包含支付号的请求)
		{
			//赋值交易号给当前类
			$this->pay_no = $this->param['pay_no'];
    		//得到参数格式配置
    		$pconf = $conf['merchat_to_se_payno'];

			//获取交易流水
			$pay_data = self::$redis->get("{$this->pay_no}_request");

			$pay_data = $pay_data?$pay_data:$this->mer->get_merchant_pay_data_by_pay_no($this->pay_no);

			//验证商户以及应用是否存在
			if($pay_data['merchant_id'] && $pay_data['auth_app_id'])
			{
				$this->param['app_code'] = $this->get_app_id(intval($pay_data['auth_app_id']),$pay_data['merchant_id']);
				$this->param['se_payment_code'] = $pay_data['se_payment_code'];

				//获取商户密钥
				$merchantInfo = $this->get_merchant_info($pay_data['se_payment_code']);
				$pay_data['se_private_key'] = $merchantInfo['se_private_key'];
			}
			//验证参数的合法性
			$r = $this->verify_all_params($this->param, $pconf);
			if($r === FALSE)
			{
				//如果验证不合法则报错				
				return FALSE;
			}

			$pay_data['institution_number'] = $this->param['institution_number'];//提交中金支付必须数据（秉谦）
			$pay_data['PayerName'] = $this->param['PayerName'];//提交中金支付必须数据（秉谦）
			$pay_data['payment_type_id'] = $this->param['payment_type_id'];//公共支付存在支付类型

			//得到返回url,供返回使用
    		$this->return_url = isset($pay_data['return_url']) ? $pay_data['return_url'] : '';
    		//print_r($pay_data);

			//验证授权号
			if(!isset($pay_data['se_payment_code']) || !isset($pay_data['se_private_key']) || empty($pay_data['se_payment_code']))
			{
				//如果验证不合法则输入错误状态并报错
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $pay_data['se_payment_code'] . '(' . $this->pay_no . ')');
				return FALSE;			
			}

			//验证签名
			 $se_sign = $this->build_sign($this->param, $pconf, $pay_data['se_private_key']);

	    	if(!$se_sign || $this->param['se_sign'] != $se_sign)
	    	{
				$this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $this->param['se_sign'] . '(' . $this->pay_no . ')');
	    		return FALSE;
	    	}
			//赋值支付数据
			$this->payment_data = $pay_data;
		}
    	
    	return TRUE;	
		
    }
    
    
    /**
     * 显示支付选择页面
     * 
     * a. 初始化商户请求的参数信息
     * b. 初始化签名
     * c. 初始化支付类型
     */
    protected function display_pay_select()
    {    	
    	//初始化支付的参数数据
		$m_pay_req = D('PayRequest');
		$pay_req_info = $m_pay_req->get_by_pay_no($this->pay_no);
		$this->assign('pay_request', $pay_req_info);

    	//生成签名和交易参数
    	$sign_data = array();
    	$conf = C('pay');
    	$pconf = $conf['merchat_to_se_payno'];

		$sign_data['app_code'] = $this->get_app_id($this->payment_data['auth_app_id'],$this->payment_data['merchant_id']);
		$sign_data['se_payment_code'] = $this->payment_data['se_payment_code'];
    	$sign_data['institution_number'] = $this->payment_data['institution_number']; //提交中金支付必须数据（秉谦）
    	$sign_data['PayerName'] = $this->payment_data['PayerName'];//提交中金支付必须数据（秉谦）
    	$sign_data['pay_no'] = $this->pay_no;
    	$sign_data['created_ts'] = time();
    	$sign_data['se_sign'] = $this->build_sign($sign_data, $pconf, $this->payment_data['se_private_key']);

    	//签名录入表单,准备下次提交验证
		$this->assign('sign_data', $sign_data);
    	
        //判断是否web/wap去调用对应的接口
        // $is_mobile = is_mobile();
        // $scenary = $is_mobile ? 2 : 1;
        // 保存支付场景
        // D('PayRequest')->where(['pay_no'=>$this->pay_no])->save(['scenary_id'=>$scenary]);
        // 获取当前app与场景 的可用的支付方式
        $payment_type = D('MerchantApp')->get_payment_by_appid_or_code($this->payment_data['auth_app_id'],$this->payment_data['scenary_id']);

    	//初始化支付方式
/*    	$m_pay_type = D('PaymentType');
    	$payment_type = $m_pay_type->get_id_data_list();*/
    	$this->assign('payment_type', $payment_type);
		$this->assign('result', $this->status);

		//判断是否web/wap去调用对应的接口
		//$is_mobile = is_mobile();
		if(checkScene() == 'PC')
		{
			$this->display('web_pay');
		}
		else
		{
			$this->display('wap_pay');
		}
    	
    	
    }

    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------- 回调接口, 支持同步回调,异步回调方法 ----------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    
    /**
     * 同步回调
     * 
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     * 
     * @return void
     */
	public function return_url($se_val='')
	{
		//分解参数
		if(empty($se_val))
		{
			$this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: ' . json_encode($_GET));
			$this->errlog();			
		}
		
		//分解参数 $account_mer_id-$se_payment_type-$se_client_type
		$params_arr = explode('-', $se_val);
		if(count($params_arr)!=5){
			$this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url' . json_encode($_GET));
			$this->errlog();
		}
		$payment_type_id = $params_arr[0];
		$se_payment_type = $params_arr[1];
		$se_client_type = $params_arr[2];
		$app_id = $params_arr[3];
		$scenary_id = $params_arr[4];
		//组合账户数据的客户端目录
		// $data['merchant_data_path'] = MER_DATA_PATH.$account_mer_id.'/'.$se_payment_type.'/';
		// $data['merchant_data_ctype_path'] = $data['merchant_data_path'].$se_client_type.'/';	
		// 获取商户支付配置信息
		$data['merchant_payment_info'] = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($scenary_id,$app_id,$payment_type_id);

		//1. 载入第三方支付接口的回调业务处理类去处理
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';
		$cls = load_pm_lib($data['third_lib_path'].'return_url', FALSE, $data);

		//2. 检查回调参数并返回结果的状态联数组
		/*
		return array(
			//SE支付网关交易号
			'pay_no' => 'xxx',
			//第三方交易号
			'third_trade_no' => 'xxx',			
			//SE支付网关的状态 
			'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
			//SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
			'status_msg' => '签名错误'
		);
		*/
		$this->result = $cls->check_params();
		$this->check_third_return_val($this->result);
		
		//3. 更新状态和返回第三方交易号结果
		$pay_no = $this->result['pay_no'];
		$update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
		$this->update_status('PayRequest', $pay_no, 31, 32, $update_data);
		$pay_data = $this->mer->get_merchant_pay_data_by_pay_no($pay_no);

		//4. 如果有错误,则返回到错误页面
		if($this->has_err())
		{
			//在SE支付平台显示错误信息		
			if(empty($pay_data) || !isset($pay_data['return_url']) || empty($pay_data['return_url']))
			{
				$this->errlog();
			}
			//把错误信息返回到第三方平台
			else
			{
				$this->payment_data = $pay_data;
				$return_result = $this->get_return_result();
				header('Location:'.$pay_data['return_url'].'?'.http_build_query($return_result));				
			}
			exit;
		}

		//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
		$result = $cls->notify_result();
		$this->check_third_return_val($result);
		$this->update_status('PayRequest', $pay_no, 51, 52);
		
		//6. 回调商户的同步回调return_url
		//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面	
		if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
		{
			//返回json形式数据
			if($this->use_json)
			{
			    $this->returnData['code'] = ($this->status == TRUE) ? 200 : 0;
		        $this->returnData['message'] = $this->status_msg;   
		        $this->returnData['data']['pay_no'] = $pay_no;
		        exit(json_encode($this->returnData));				
            }

			$this->assign('pay_data', $pay_data);
			if(is_mobile()){
	            $this->display('wap_success'); 
	        }else{
	            $this->display('web_success');         
	        }
			exit;
		}
		//6.2 如果商户有回调url,则调用回调url
		else
		{
			$this->payment_data = $pay_data;
			$return_result = $this->get_return_result();
			// header('Location:'.$pay_data['return_url'].'?'.http_build_query($return_result));
			$return_url = html_entity_decode($pay_data['return_url']);
			$res = parse_url($return_url);
			$glue = empty($res['query'])?'?':'&';
			$glue=($glue=='?'&&$return_url[strlen($return_url)-1]=='?')?'':$glue;
			$return_url =  $return_url.$glue.http_build_query($return_result);

			header('Location:'.$return_url);

		}
		
		
		//7. 回执更新最后结果状态 201, 202 (此状态暂时不调用, 异步更新会更新到 201, 202)
		//$this->update_status('PayRequest', $pay_no, 201, 202, '', $result);
	}
	
    /**
     * 异步回调
     * 
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     * 
     * @return void
     */
	public function notify_url($se_val='')
	{
		//分解参数
		if(empty($se_val))
		{
			$this->set_status('EMPTY_PARAMS', 'there is an empty params for notify_url: ' . json_encode($_GET));
			$this->errlog();			
		}
		//分解参数 $account_mer_id-$se_payment_type-$se_client_type
		$params_arr = explode('-', $se_val);
		if(count($params_arr)!=5){
			$this->set_status('INVALID_PARAMS', 'there is an invalid params for notify_url' . json_encode($_GET));
			$this->errlog();
		}
		$payment_type_id = $params_arr[0];
		$se_payment_type = $params_arr[1];
		$se_client_type = $params_arr[2];
		$app_id = $params_arr[3];
		$scenary_id = $params_arr[4];
		//组合账户数据的客户端目录
// 		$data['merchant_data_path'] = MER_DATA_PATH.$account_mer_id.'/'.$se_payment_type.'/';
// 		$data['merchant_data_ctype_path'] = $data['merchant_data_path'].$se_client_type.'/';	
		// 获取商户支付配置信息
		$data['merchant_payment_info'] = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($scenary_id,$app_id,$payment_type_id);        
		//1. 载入第三方支付接口的回调业务处理类去处理
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';

		$cls = load_pm_lib($data['third_lib_path'].'notify_url', FALSE, $data);	

		//2. 检查回调参数并返回结果的状态联数组
		/*
		return array(
			//支付号
			'pay_no' => 'xxx',
			//第三方支付号
			'third_trade_no' => '交易号',
			//SE支付网关的状态 
			'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
			//SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
			'status_msg' => '签名错误'
		);
		*/		
		$this->result = $cls->check_params();
		$this->check_third_return_val($this->result);
		
		//3. 更新状态和返回第三方交易号结果
		$pay_no = $this->result['pay_no'];
		$update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
		$this->update_status('PayRequest', $pay_no, 31, 32, $update_data);
		$pay_data = $this->mer->get_merchant_pay_data_by_pay_no($pay_no);

		//4. 如果有错误,则返回到错误页面
		if($this->has_err())
		{
			//在SE支付平台显示错误信息		
			if(!isset($pay_data['notify_url']) || empty($pay_data['notify_url']))
			{
				//$this->errlog();
				exit;
			}
			//把错误信息返回到第三方平台
			else
			{
				$this->payment_data = $pay_data;
				$return_result = $this->get_return_result();
				$this->curl($pay_data['notify_url'], $return_result);				
			}
		}
		
		//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
		$result = $cls->notify_result();
		$this->check_third_return_val($result);
		$this->update_status('PayRequest', $pay_no, 51, 52);
		
		//6. 回调商户的异步回调notify_url
		//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
		if(!isset($pay_data['notify_url']) || empty($pay_data['notify_url']))
		{
			$this->assign('pay_data', $pay_data);
			if(is_mobile()){
	            $this->display('wap_success');
	        }else{
	            $this->display('web_success');
	        }
			exit;
		}
		
		$this->payment_data = $pay_data;
		$return_result = $this->get_return_result();

		//7. 回执更新最后结果状态 201, 202 (此状态暂时不调用)
		$result = $this->update_status('PayRequest', $pay_no, 201, 202, '', $result);
		if($result)
		{	
			//7.1 如果商户有回调url,则调用回调url
			if(is_array($return_result)) {
				$return = $this->curl(html_entity_decode($pay_data['notify_url']), $return_result);
			}else{
				$return = $this->curl_json($pay_data['notify_url'], $return_result);
			}	
			exit(true);
		}
	}

    /**
     * 扫码支付异步回调
     * 
     * @params string 参数组合 $params=$account_mer_id-$se_payment_type-$se_client_type
     * 
     * @return void
     */
	public function qrpay_notify_url($se_val='')
	{
		//分解参数
		if(empty($se_val))
		{
			$this->set_status('EMPTY_PARAMS', 'there is an empty params for return_url: ' . json_encode($_GET));
			$this->errlog();			
		}
		//分解参数 $account_mer_id-$se_payment_type-$se_client_type
		$params_arr = explode('-', $se_val);
		if(count($params_arr)!=5){
			$this->set_status('INVALID_PARAMS', 'there is an invalid params for return_url' . json_encode($_GET));
			$this->errlog();
		}
		$payment_type_id = $params_arr[0];
		$se_payment_type = $params_arr[1];
		$se_client_type = $params_arr[2];
		$app_id = $params_arr[3];
		$scenary_id = $params_arr[4];

		// 获取商户支付配置信息
		$data['merchant_payment_info'] = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($scenary_id,$app_id,$payment_type_id);        
		//1. 载入第三方支付接口的回调业务处理类去处理
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';
	
		$cls = load_pm_lib($data['third_lib_path'].'qrpay_notify_url', FALSE, $data);

		$this->result = $cls->check_params();
		
		$this->check_third_return_val($this->result);
		
		//3. 更新状态和返回第三方交易号结果
		$pay_no = $this->result['pay_no'];
		$update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
		$this->update_status('PayRequest', $pay_no, 31, 32, $update_data);
		$pay_data = $this->mer->get_merchant_pay_data_by_pay_no($pay_no);

		//4. 如果有错误,则返回到错误页面
		if($this->has_err())
		{
			//在SE支付平台显示错误信息		
			if(!isset($pay_data['notify_url']) || empty($pay_data['notify_url']))
			{
				//$this->errlog();
				exit;
			}
			//把错误信息返回到第三方平台
			else
			{
				$this->payment_data = $pay_data;
				$return_result = $this->get_return_result();
				$this->curl($pay_data['notify_url'], $return_result);				
			}
		}
		
		//5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
		$result = $cls->notify_result();
		$this->check_third_return_val($result);
		$this->update_status('PayRequest', $pay_no, 51, 52);
		
		//6. 回调商户的异步回调notify_url
		//6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
		if(!isset($pay_data['notify_url']) || empty($pay_data['notify_url']))
		{
			exit;
		}
		
		$this->payment_data = $pay_data;
		$return_result = $this->get_return_result();

		//7. 回执更新最后结果状态 201, 202 (此状态暂时不调用)
		$result = $this->update_status('PayRequest', $pay_no, 201, 202, '', $result);
		if($result)
		{
			//7.1 如果商户有回调url,则调用回调url
			if(is_array($return_result)) {
				$return = $this->curl($pay_data['notify_url'], $return_result);
			}else{
				$return = $this->curl_json($pay_data['notify_url'], $return_result);
			}		
			exit(true);
		}
	}
	    
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 ------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    
    /**
     * 创建第一次支付请求 (未带pay_no的支付请求)
     * 
     * @return void
     */
    protected function create_pay_request()
    {
		//创建支付流水
		if($this->param)
		{
			//初始模型类
			$m_status = D('Status');  //状态
			$m_request = D('PayRequest');  //流水

			//组装流水参数
			$payRequst=array();
			$payRequst['pay_request_id'] = '';
			$payRequst['pay_no'] = '';
			$payRequst['payment_type_id'] = $this->param['payment_type_id'];
			$payRequst['bill_id'] = $this->param['bill_id'];
			$payRequst['bill_type_id'] = $this->param['bill_type_id'];
			$payRequst['se_payment_code'] = $this->param['se_payment_code'];
			$payRequst['subject'] = (isset($this->param['subject']) && !empty($this->param['subject'])) ? $this->param['subject'] : '系统默认商户支付';
			$payRequst['description'] = $this->param['description'];
			//$payRequst['third_trade_no'] = ''; //第三方交易号, 提交支付类型时更新
			$payRequst['amount'] = $this->param['amount'];
			$payRequst['return_url'] = $this->param['return_url'];
			$payRequst['notify_url'] = $this->param['notify_url'];
			$payRequst['show_url'] = $this->param['show_url'];
			$payRequst['status_id'] = $m_status->get_status_id('10');	//初始状态 10
			$payRequst['currency_code'] = (isset($this->param['currency_code']) && !empty($this->param['notify_url'])) ? $this->param['currency_code'] : 'CNY';
			$payRequst['created_ts'] = date('Y-m-d H:i:s');
			$payRequst['modified_ts'] = date('Y-m-d H:i:s');

			//场景区别
			if(!isset($this->param['app_type']) || empty($this->param['app_type'])){
				$payRequst['scenary_id'] = (is_mobile()===TRUE )? '2' : '1';//判断应用使用场景
			}else {
				$payRequst['scenary_id'] = (strtoupper($this->param['app_type']) == 'IOS') ? '3' : '4';//判断应用使用场景
			}
			if($this->use_json){
				$payRequst['scenary_id'] = '2';
			}
			//如果是
			$payRequst['pay_client'] = checkScene(); //判断使用设备终端
			$payRequst['merchant_id'] = $this->param['merchant_id'];  //商户ID
			$payRequst['auth_app_id'] = $this->get_app_id($this->param['app_code'],$payRequst['merchant_id']);  //获取应用ID
			//尚龙sessionId
			$payRequst['sessionId'] = $this->param['sessionId'];
			
			if($m_request->save_data($payRequst))
			{
				$payRequst['pay_request_id'] = $m_request->getLastInsID();

				//组装交易号
				$payRequst['pay_no'] = $this->pay_no = $this->get_idno($payRequst['pay_request_id'],C('pay_no_prefix'));
				//更新流水表，插入交易号
				$result = $m_request->save_data(array('pay_request_id'=>$payRequst['pay_request_id'],'pay_no'=>$this->pay_no));

				if($result)
				{
					//缓存流水记录 生存时间30秒
//                    self::$redis->set("{$this->pay_no}_request",$payRequst,C('cache_expire'));
                    self::$redis->set("{$this->pay_no}_request",$payRequst);

					//插入流水状态表记录
					D('PayRequestFlow')->save_data(array('pay_request_id'=>$payRequst['pay_request_id'],'status_id'=>$payRequst['status_id'],'created_ts'=>date('Y-m-d H:i:s')));

					//如果是标准API返回形式
					if($this->use_json)
					{
					    $this->returnData['code'] = 200;
				        $this->returnData['message'] = 'success';   
				        $this->returnData['data']['pay_no'] = $this->pay_no;
				        exit(json_encode($this->returnData));
					}
					return $result;
				}
			}
		}
		return false;
    }   


	/**
     * 直接选择支付方式支付(接口)
     */      
    public function pay_api()
    {
    	$p =  $this->param;
		if($this->pay_no)
		{
			$payment_type = D('PaymentType')->get_data_by_id($this->payment_type_id);
			//判断获取支付方式是否存在
			if(!$payment_type)
			{
				$this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $payment_type);
				return FALSE;
			}
			$this->payment_type = $payment_type;

			if($this->has_err())
			{
				$this->errlog('verify params failed for first pay request');
			}
			//获取商户信息
			// $this->payment_data =  $this->mer->get_merchant_pay_data_by_pay_no($this->pay_no,$this->payment_type_id);
			$this->pay_merchant_data = $this->get_merchant_info($p['se_payment_code']);

			//中金支付必须参数 机构号码，付款者名称，短信验证码
			if($this->payment_type_id == 6)
			{
				if($p['institution_number']&&$p['PayerName']&&$p['message_code'])
				{
					$this->pay_merchant_data['institution_number'] = $p['institution_number'];
					$this->pay_merchant_data['PayerName'] = $p['PayerName'];
					$this->pay_merchant_data['message_code'] = $p['message_code'];
				}else{
					$this->success('中金支付参数错误');
				}
			}			

			//校验商户信息
			if(!$this->pay_merchant_data['se_private_key'] || !$p['se_payment_code'])
			{
				$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$p['se_payment_code']);
				return FALSE;
			}
			//校验支付方式是否合法
			$this->pay_type_data = D('PaymentType')->get_data_by_id($this->payment_type_id);

			if(!$this->pay_type_data)
			{
				$this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $this->pay_type_data);
				return FALSE;
			}
			//更新状态为  13, 14
			$r = $this->update_status('PayRequest', $this->pay_no, 21, 22, array('payment_type_id'=>$this->payment_type_id));

			if(!$r || $this->has_err())
			{
				$this->errlog('verify params failed for second pay request');
			}
			//发起第三方请求
			$this->request_third_pay();
			exit;
		}
    }
    /**
     * SDK返回商户应用的支付渠道列表(已经开通的支付渠道)
     * @return json
     */
    public function pay_sdk()
    {
    	if($this->payment_type_id == '')
    	{
    		//生成签名和交易参数
	    	$sign_data = array();
	    	$conf = C('pay');
	    	$pconf = $conf['merchat_to_se_payno'];

			$sign_data['app_code'] = $this->get_app_id($this->payment_data['auth_app_id'],$this->payment_data['merchant_id']);
			$sign_data['se_payment_code'] = $this->payment_data['se_payment_code'];
	    	$sign_data['institution_number'] = $this->payment_data['institution_number']; //提交中金支付必须数据（秉谦）
	    	$sign_data['PayerName'] = $this->payment_data['PayerName'];//提交中金支付必须数据（秉谦）
	    	$sign_data['pay_no'] = $this->pay_no;
	    	$sign_data['created_ts'] = time();
	    	$sign_data['se_sign'] = $this->build_sign($sign_data, $pconf, $this->payment_data['se_private_key']);

	    	//获取应用支持的支付渠道
			$payment_type = D('MerchantApp')->get_payment_by_appid_or_code($this->payment_data['auth_app_id'],$this->payment_data['scenary_id']);

			if($payment_type)
			{
	            $this->returnData['code'] = 200;
	            $this->returnData['message'] = 'success';   
	            $this->returnData['data']['list'] = $payment_type;
	            $this->returnData['data']['se_sign'] = $sign_data['se_sign'];
	            $this->returnData['data']['sign_time'] = $sign_data['created_ts'];
			}
            exit(json_encode($this->returnData));

    	}else{
			//校验支付方式是否合法
			$this->pay_type_data = D('PaymentType')->get_data_by_id($this->payment_type_id);

			if(!$this->pay_type_data)
			{
				$this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $this->pay_type_data);
				return FALSE;
			}

    		$this->pay_merchant_data = $this->get_merchant_info($this->param['se_payment_code']);

    		$this->request_third_pay();
    	}
    } 
/*=====================================================SDK支付start============================================================*/
	public function pay_app()
	{
		$this->pay_no = $this->param['pay_no'];		
		$this->pay_request_data = $this->get_pay_info($this->pay_no);

		$this->param['se_payment_code'] = $this->pay_request_data['se_payment_code'];   //获取商户编码
		//获取应用编码
		$this->param['app_code'] = $this->get_app_id(intval($this->pay_request_data['auth_app_id']),$this->pay_request_data['merchant_id']);  

		if($this->param['payment_type_id'])
		{
			$this->payment_type_id = $this->param['payment_type_id'];
			//校验支付方式是否合法
			$this->pay_type_data = D('PaymentType')->get_data_by_id($this->payment_type_id);
			if(!$this->pay_type_data)
			{
				$this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: ' . $this->pay_type_data);
				return FALSE;
			}		
			//更新流水状态
			$this->update_status('PayRequest', $this->pay_no, 21, 22, array('payment_type_id'=>$this->payment_type_id));

			$this->pay_merchant_data = $this->get_merchant_info($this->param['se_payment_code']);

			$this->request_third_pay();
		}
		else
		{		
			//返回商户应用的支付渠道列表(已经开通的支付渠道)
			$payment_type = D('MerchantApp')->get_payment_by_appid($this->pay_request_data['auth_app_id'],$this->pay_request_data['scenary_id']);
			if($payment_type)
			{

	            $this->returnData['code'] = 200;
	            $this->returnData['message'] = 'success';   
	           	if($this->use_json){
	           		$this->returnData['data'] = [
                    'pay_no' => $this->param['pay_no'],
                    'payment_type_list' => $payment_type
                	];
				}else{
					$this->returnData['data'] = $payment_type;
				}          
			}

			 exit(json_encode($this->returnData));			
		}

	}
	protected function check_app_params()
	{
		//赋值交易号给当前类
		$this->pay_no = $this->param['pay_no'];
	    //得到参数格式配置
		$pconf = C('pay')['merchat_to_se_payno'];
		//获取交易流水
		$pay_request_data = $this->get_pay_info($this->pay_no);
		
		//验证商户以及应用是否存在
		if($pay_request_data['merchant_id'] && $pay_request_data['auth_app_id'])
		{
			$this->param['app_code'] = $this->get_app_id(intval($pay_request_data['auth_app_id']),$pay_request_data['merchant_id']);
			$this->param['se_payment_code'] = $pay_request_data['se_payment_code'];

			//获取商户密钥
			$merchantInfo = $this->get_merchant_info($pay_request_data['se_payment_code']);
			$pay_request_data['se_private_key'] = $merchantInfo['se_private_key'];
		}

		//验证参数的合法性
		$r = $this->verify_all_params($this->param, $pconf);
		if($r === FALSE)
		{
			//如果验证不合法则报错				
			return FALSE;
		}

		//验证授权号
		if(!isset($pay_request_data['se_payment_code']) || !isset($pay_request_data['se_private_key']) || empty($pay_request_data['se_payment_code']))
		{
			//如果验证不合法则输入错误状态并报错
			$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for ' . $pay_request_data['se_payment_code'] . '(' . $this->pay_no . ')');
			return FALSE;			
		}	

		//验证签名
		$se_sign = $this->build_sign($this->param, $pconf, $pay_request_data['se_private_key']);

    	if(!$se_sign || $this->param['se_sign'] != $se_sign)
    	{
			$this->set_status('INVALID_SIGN', 'this is invalid sign for ' . $this->param['se_sign'] . '(' . $this->pay_no . ')');
    		return FALSE;
    	}
		//赋值支付数据
		$this->pay_request_data = $pay_request_data;	

		return TRUE;
	}	
/*=====================================================SDK支付end============================================================*/        
    /**
     * 请求第三方支付
     * @return void
     */
    protected function request_third_pay()
    {      
    	if($this->pay_merchant_data)
    	{
			//获取场景
			// $scene = checkScene();
			$merchant_app_id = $this->get_app_id($this->param['app_code'],$this->pay_merchant_data['merchant_id']);    

			//获取对应支付场景的支付渠道配置信息
			// $merchant_payment_info = D('ProcessPay')->get_merchant_payment_info($scene,$merchant_app_id,$this->payment_type_id);
			$merchant_payment_info = D('ProcessPay')->get_merchant_payment_info_with_scenary_id($this->pay_request_data['scenary_id'],$merchant_app_id,$this->payment_type_id);

			if($merchant_payment_info)
			{
				//处理场景
				// $scene = $this->get_scene_type($scene);
				$scene = $this->get_scene_type($this->pay_request_data['scenary_id']);
				//组装交易参数
				$payData = array();
				$payData['payment_type'] = $this->pay_type_data;  //支付渠道类型信息
				$payData['client_type'] = $scene;                   //支付场景
				$payData['pay_merchant_data'] = $this->pay_merchant_data;      //商户信息
				$payData['pay_request_data'] = $this->pay_request_data; //支付流水
				$payData['merchant_payment_info'] = $merchant_payment_info;  //商户支付配置信息

		        $att = [
		            'pay_account' => isset($merchant_payment_info['account']) ? $merchant_payment_info['account'] : '商户暂未配置该支付渠道下的account,'.$this->pay_request_data['scenary_id']
		        ];
				//加载指定第三方支付类
				$pay = load_pm_lib("payment/{$this->pay_type_data['code']}/{$scene}/{$this->pay_type_data['code']}", FALSE, $payData);

				$this->update_status('PayRequest', $this->pay_no, 30,32,$att);
				//调用第三方支付
				$pay->pay();
			}	

    	}
  
/*        $this->check_third_return_val($this->result);  
        //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
        //返回data值
        $pay_no = $this->result['pay_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('PayRequest', $pay_no, 31, 32, $update_data);	//得到成功的支付结果, 得到失败的支付结果
    
        //4. 如果有错误,则返回到错误页面
        if($this->has_err())
        {
            $pay_data = $this->mer->get_merchant_pay_data_by_pay_no($pay_no);
            //在SE支付平台显示错误信息
            if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
            {
                $this->errlog();
            }
            //把错误信息返回到第三方平台
            else
            {
                $this->payment_data = $pay_data;
                $return_result = $this->get_return_result();
                header('Location:'.$pay_data['return_url'].'?'.http_build_query($return_result));
            }
        }
    
        //5. 给回执到第三方平台(如果不需要则为空),并更新状态和结果
        $result = $cls->notify_result();
        $this->check_third_return_val($result);
        $this->update_status('PayRequest', $pay_no, 51, 52);
    
        //6. 回调商户的同步回调return_url
        //6.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
        $pay_data = $this->mer->get_merchant_pay_data_by_pay_no($pay_no);
    
        if(!isset($pay_data['return_url']) || empty($pay_data['return_url']))
        {
            $this->assign('pay_data', $pay_data);
            if(isset($this->result['institution_number'])){
            if(is_mobile()){
            	$this->display('Pay/wap_success');
            }else{
            	$this->display('Pay/web_success');
            }
            exit;
            }else{
            if(is_mobile()){
                $this->display('wap_success');
            }else{
                $this->display('web_success');
            }
            exit;
            }
        }*/
    
    }               
    /**
     * 得到返回结果
     * 
     * @return Array 
     */
    protected function get_return_result()
    {
    	$params = array(
    		'se_payment_code' => $this->payment_data['se_payment_code'],
    		'bill_id' =>$this->payment_data['bill_id'],
    		'third_trade_no' =>$this->payment_data['third_trade_no'],
			'pay_no'=> $this->payment_data['pay_no'],
			'amount'=> $this->payment_data['amount'],
			'payment_type_id' =>$this->payment_data['payment_type_id'],
			'created_ts' => time(),
			'result' => $this->status
		);
		$params['se_sign'] = md5(md5($params['se_payment_code'].$params['pay_no'].$params['bill_id'].$params['result'].$params['created_ts']).$this->payment_data['se_private_key']);
		unset($params['se_payment_code']);

    	//尚龙返回sessionId
    	$sessionId = html_entity_decode(trim($this->payment_data['sessionId']));
    	$sessionId = json_decode($sessionId,true);
	
		if($sessionId['sessionid'])
		{
			$params['mobile'] = $sessionId['mobile'];
			$params['fixfileids'] = $sessionId['fixfileids'];
			$params['spCmServicevouchers'] = $sessionId['spCmServicevouchers'];
			$params['paytype'] = $sessionId['paytype'];
			$params['sessionId'] = $sessionId['sessionid'];
			return json_encode($params);
		}
		return $params;
    }
    
    /**
     * 得到类型,用来给模板区分具体的动作
     * 
     * @return String
     */
    public function get_type()
    {
    	return 'pay';
    }    
    
	//支付结果
	public function pay_result($requestData = '')
	{
		$pay_no = current(explode('-',$requestData));
		$result = D('PayRequest')->get_by_pay_no($pay_no);
		$status_id = D('Status')->get_status_id('51'); //成功支付代码			
		if($result['status_id'] == $status_id){
			$re_data['msg'] = "success";
		}else{
			$re_data['msg'] = "fail";	
		}
		
		
		echo json_encode($re_data);
		exit;		
	}
	
	public function third_call_back($data =''){
			if(!empty($data)){
				$data = json_decode($data,true);	
			}
			// $cls = load_pm_lib($data['third_lib_path'].$data['payment_type']['code'], FALSE, $data);
			$cls = load_pm_lib("payment/{$data['payment_type']['code']}/{$data['client_type']}/{$data['payment_type']['code']}", FALSE, $data);
			$cls->toPay();
	}
    
}