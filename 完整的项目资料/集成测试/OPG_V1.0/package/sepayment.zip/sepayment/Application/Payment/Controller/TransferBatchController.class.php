<?php
namespace Payment\Controller;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team (tengyun)
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
use Think\Log;
class TransferBatchController extends PaymentController{
    // 请求参数
    protected $param = [];
    // 效验规则
    private $rule = [];
    // 分析后的数据
    private $transfer_param = [];
    // 转账详细
    private $transferInfo = [];
    // 转账总笔数
    private $batch_num = 0;
    // 转账总金额
    private $totle_amount = 0;
    // 暂存数据
    private $temp = [];
    public function __construct(){
        parent::__construct();
        $this->param = I('get.') ? I('get.') : I('post.');
        $this->rule = C('transfer');

    }
    // 批量转款入口
    public function index(){
        //// debug
//        if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//            var_dump($this);exit;
//        }
        /////
//        var_dump($this->param);exit;
        $transfer_no_arr = explode('|', $this->param['transfer_no']);
        $se_sign_arr = explode('|', $this->param['se_sign']);
        $arr = [];
        foreach($transfer_no_arr as $k =>$v){
            $arr[] = [
                'transfer_no' => $v,
                'se_payment_code' => $this->param['se_payment_code'],
                'app_code' => $this->param['app_code'],
                'payment_type_id' => $this->param['payment_type_id'],
                'created_ts' => $this->param['created_ts'],
                'se_sign' => $se_sign_arr[$k],
            ];
            $this->check_params($arr[$k]);
            if($this->has_err()){
                $this->errlog('verify params failed for request');
            }
        }
        $this->transfer_param = $arr;
        //// debug
//        if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//            var_dump($this->transfer_param);exit;
//        }
        /////
        $this->goPay();
    }

    // 统一参数检测
    private function check_params($param){
//        var_dump($param);exit;
        //得到参数格式配置
        $rule = $this->rule['merchat_to_se_pay'];

        //验证参数的合法性
        $r = $this->verify_all_params($param, $rule);
        if($r === false) return false;
        // 1.验证授权号
        $this->transferInfo = D('Merchant')->get_info_by_transfer_no($param['transfer_no']);
        //得到返回url,供返回使用
        //            $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';
        if(!isset($this->transferInfo['se_payment_code']) || !isset($this->transferInfo['se_private_key']) || empty($this->transferInfo['se_payment_code'])){
            //如果验证不合法则输入错误状态并报错
            $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$param['se_payment_code'].'('.$param['transfer_no'].')');
            return false;
        }
        // 2.验证签名
        $param['se_payment_code'] = $this->transferInfo['se_payment_code'];
        $se_sign = $this->build_sign($param, $rule, $this->transferInfo['se_private_key']);
        if(!$se_sign || $param['se_sign'] != $se_sign){
            $this->set_status('INVALID_SIGN', 'this is invalid sign for '.$param['se_sign'].'('.$this->transferInfo['transfer_no'].')');
            return false;
        }
        $this->temp[] = $this->transferInfo;
        $this->batch_num++;
        $this->totle_amount+=$this->transferInfo['amount'];
    }
    /**
     * 请求第三方支付
     */
    private function goPay(){
//        var_dump($this->transfer_param);exit;
        foreach($this->transfer_param as $k => $v){
            //1. 更新支付类型已经状态,并更新商户账号ID
            $d = [
                'payment_type_id' => $v['payment_type_id'],
//                'merchant_account_id' => $v['merchant_account_id'],
            ];
            $this->transferInfo['payment_type_id'] = $v['payment_type_id'];
//            $this->transferInfo['merchant_account_id'] = $v['merchant_account_id'];
            $this->update_status('TransferRequest', $v['transfer_no'], 21, 22, $d); //支付类型验证成功, 支付类型验证失败
            if($this->has_err()){
                $this->errlog('Invalid params for go pay action');
            }

        }
        $this->transferInfo['batch_num'] = $this->batch_num;
        $this->transferInfo['totle_amount'] = $this->totle_amount;
        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['transfer_data'] = $this->transferInfo;
        switch($data['transfer_data']['scenary_id']){
            case '1' :
                $data['client_type'] = 'web';
                break;
            case '2' :
                $data['client_type'] = 'wap';
                break;
            case '3' :
                $data['client_type'] = 'ios';
                break;
            case '4' :
                $data['client_type'] = 'android';
                break;
        }

        //        $data['payment_type'] = D('PaymentType')->checkPayment($this->transferInfo['auth_app_id'],$this->transferInfo['payment_type_id']);
        $data['payment_type'] = D('PaymentType')->checkPayment_is_tansfer($this->transferInfo['payment_type_id']);

        if(!$data['payment_type'])
            $this->errlog('Invalid payment_type for process pay controller');
        // 获取当前app,payment 下的商户配置参数
        $arr = D('PaymentParameterDefine')->getList(
            $data['payment_type']['payment_type_id'],
            $data['transfer_data']['scenary_id'],
            $data['transfer_data']['auth_app_id']
        );
        $data['payment_type'] = array_merge($data['payment_type'], $arr);

//        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'];
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/web';

        // 一个新的批量转账
        $transfer_batch_no = $this->new_transfer_batch($data);
        $data['transfer_data']['transfer_batch_no'] = $transfer_batch_no;
        $data['transfer_data']['detail_data'] = '';
        foreach($this->temp as $v){
            $data['transfer_data']['detail_data'] .='|'.$v['transfer_no'].'^';
            $data['transfer_data']['detail_data'] .=$v['rec_account_no'].'^';
            $data['transfer_data']['detail_data'] .=$v['rec_account_name'].'^';
            $data['transfer_data']['detail_data'] .=$v['amount'].'^';
            $data['transfer_data']['detail_data'] .=$v['description'];
        }
        $data['transfer_data']['detail_data'] = ltrim($data['transfer_data']['detail_data'] ,'|');
//        var_dump($data['transfer_data']['detail_data']);exit;
        //// debug
//                if($this->param['se_payment_code'] == 'af70891aa4b8cc068dfd2af60c655555'){
//                    var_dump($data);exit;
//                }
        /////
        $att = [
            'pay_account' => isset($arr['account']) ? $arr['account'] : '商户暂未配置该支付渠道下的account,'.$data['transfer_data']['scenary_id']
        ];
        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$data['payment_type']['code'].'/'.$data['client_type'].'/'.$data['payment_type']['code'], false, $data);
        //调用第三方支付,并得到结果
        foreach($this->transfer_param as  $v){
            $this->update_status('TransferRequest', $v['transfer_no'], 30,32,$att);
        }
        $this->result = $cls->transfer();
        /*
     $this->result = array(
           //SE支付网关交易号
           'transfer_no' => 'xxx',
           //第三方交易号
           'third_trade_no' => 'xxx',
           //SE支付网关的状态
           'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
           //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
           'status_msg' => '签名错误'
       );
       */
        //3. 如果是跳入第三方结果页面下面代码不会被执行 (如:支付宝),
        //   如果$cls->transfer()中只接受第三方值, 执行下面的代码 (如:微信 ).
        //返回data值
        $this->check_third_return_val($this->result);
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);    //得到成功的支付结果, 得到失败的支付结果

        // 执行异步回调
        $result = $cls->notify_result();
        if($result)
            $this->update_status('TransferRequest', $transfer_no, 51, 52);
        // 同步响应
        $this->return_url();
    }
    // 一个新的批量转账入库
    private function new_transfer_batch($olddata){
        $data = [
            'payment_type_id' => $olddata['transfer_data']['payment_type_id'],
            'scenary_id' => $olddata['transfer_data']['scenary_id'],
            'se_payment_code' => $olddata['transfer_data']['se_payment_code'],
            'merchant_id' => $olddata['transfer_data']['merchant_id'],
            'auth_app_id' => $olddata['transfer_data']['auth_app_id'],
            'subject' => $olddata['transfer_data']['subject'],
            'status_id' => 0,
            'num' => $olddata['transfer_data']['batch_num'],
            'amount' => $olddata['transfer_data']['totle_amount'],
            'created_ts' => date('Y-m-d H:i:s'),
        ];
        D('TransferRequestBatch')->startTrans();
        D('TransferRequestBatch')->add($data);
        $transfer_batch_no = D('TransferRequestBatch')->getLastInsID();
        if(!$transfer_batch_no) return false;
        foreach($this->transfer_param as $v){
            $re = D('TransferRequest')->where(['transfer_no'=>$v['transfer_no']])->save(['batch_no'=> $transfer_batch_no]);
            if(!$re) return false;
        }
        D('TransferRequestBatch')->commit();
        return $transfer_batch_no;
    }

    /**
     * 得到返回结果
     * @return Array
     */
    private function get_return_result(){
        $params = array('se_payment_code' => $this->transferInfo['se_payment_code'], 'transfer_no' => $this->transferInfo['transfer_no'], 'payment_type_id' => $this->transferInfo['payment_type_id'], 'created_ts' => time(), 'result' => $this->status, 'msg' =>  $this->status_msg);
        $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no'].$params['created_ts']).$this->transferInfo['se_private_key']);
        unset($params['se_payment_code']);
        return $params;
    }
}