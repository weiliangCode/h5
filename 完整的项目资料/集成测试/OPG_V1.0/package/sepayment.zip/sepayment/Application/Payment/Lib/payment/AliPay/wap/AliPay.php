<?php
/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */

/**
 * 商户表模型
 * 
 * 用来操作商户信息的表
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
require_once("lib/alipay_submit.class.php");

class AliPay {
	private $data = "";

	private $apiParas = array();
	// 表单提交字符集编码
	public $postCharset = "UTF-8";
	private $fileCharset = "UTF-8";
	//网关
	public $gatewayUrl = "https://openapi.alipay.com/gateway.do";
	//api版本
	public $apiVersion = "1.0";
	//返回数据格式
	public $format = "json";
	public $alipayPublicKey = null;
	//签名类型
	protected $signType = "RSA";
	protected $alipaySdkVersion = "alipay-sdk-php-20130320";
	private $terminalType;
	private $terminalInfo;
	private $prodCode;
    public $signSourceData = null;
    public $sign = null;	
	private $RESPONSE_SUFFIX = "_response";
	private $ERROR_RESPONSE = "error_response";
	private $SIGN_NODE_NAME = "sign";
	const FILE_APPEND = 8;

	public function __construct($data)
	{
		$this->data = $data;
        //获取配置信息
        $this->alipay_config = $this->config($this->data['merchant_payment_info']);
        //扫码配置信息
        $this->qrconfig = $this->qrconfig();
	}	
	/**
	 * 支付
	 */
	public function pay(){
        $payment_type = $this->data['payment_type']['code'];    //支付类型
        $client_type = $this->data['client_type'];               //设备场景
        $pay_merchant_data = $this->data['pay_merchant_data'];             //商户信息
        $pay_request_data = $this->data['pay_request_data'];     //流水数据
        $merchant_payment_info = $this->data['merchant_payment_info'];  //商户配置信息

		//查看该商户是否支持手机端的扫码支付,如果是，就到扫码支付方式
		$is_scode =  $pay_request_data['bill_type_id'];
		if($is_scode == '1'){
			$this->qrpay();
		}

		// $account_mer_id = $pay_merchant_data['merchant_id'];//商户ID
		$payment_type_id = $this->data['payment_type']['payment_type_id'];//支付类型ID
		$app_id = $this->data['pay_request_data']['auth_app_id'];//应用ID
		$scenary_id = $this->data['pay_request_data']['scenary_id'];//场景I
		$module_url = get_module_url();
		//如果是测试地址，就改为测试域名
		if(strstr($module_url,'172.16.30.13')){
			$module_url = 'http://opgdev.weilian.cn/payment';
		}
		if(strstr($module_url,'172.19.6.115')){
			$module_url = 'http://opgtest.weilian.cn/payment';
		}

		$return_url =  $module_url."/pay/return_url/se_val/$payment_type_id-$payment_type-$client_type-$app_id-$scenary_id";
		$notify_url =  $module_url."/pay/notify_url/se_val/$payment_type_id-$payment_type-$client_type-$app_id-$scenary_id";

		$parameter = array(
            "service" => "alipay.wap.create.direct.pay.by.user",
            "partner" => $this->alipay_config['partner'],
            "seller_id" => $this->alipay_config['seller_id'],
            "payment_type"	=> "1",
            "notify_url"	=> $notify_url,
            "return_url"	=> $return_url,
            "out_trade_no"	=> $pay_request_data['pay_no'],     //翌支付交易号，相当于支付宝的外部订单号
            "subject"	=> $pay_request_data['subject'],//订单名称
            "total_fee"	=> (float)$pay_request_data['amount'], //"0.01", 订单金额
            "show_url"	=> $pay_request_data['show_url'],//手机支付必填
            "body"	=> $pay_request_data['description'],
			// "it_b_pay"	=> $it_b_pay,
			// "extern_token"	=> $extern_token,            
            "_input_charset"	=> $this->alipay_config['input_charset']   //字符格式编码
		);	
		//建立请求
		$alipaySubmit = new AlipaySubmit($this->alipay_config);

		$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "确认");
		echo $html_text;
		exit;		
	}	
	
	/**
	 * 不支持退款, 所以暂时屏蔽掉
	 * 
	 * @return array
	 */
	public function disabled_refund()
	{
		$r = array('result'=>TRUE, 'text'=>'你好, 目前支付宝不能支持手机浏览器退款，请使用电脑浏览器进行退款!');
		return $r;
	}
	
	/**
	 * 退款
	 */	
	public function refund(){
		//服务器异步通知页面路径
		$payment_type = $this->data['payment_type']['code'];
		$client_type = $this->data['client_type'];
		$pay_merchant_data = $this->data['pay_merchant_data'];   //商户信息
		$refund_request_data = $this->data['refund_request_data']; //退款请求信息 
		$merchant_payment_info = $this->data['merchant_payment_info'];  //商户配置信息

		$payment_type_id = $this->data['payment_type']['payment_type_id'];//支付类型ID
		$app_id = $refund_request_data['auth_app_id'];//应用ID
		$scenary_id = $refund_request_data['scenary_id'];//场景I
		$module_url = get_module_url();
		//如果是测试地址，就改为测试域名
		if(strstr($module_url,'172.16.30.13')){
			$module_url = 'http://opgdev.weilian.cn/payment';
		}
		if(strstr($module_url,'172.19.6.115')){
			$module_url = 'http://opgtest.weilian.cn/payment';
		}
		$notify_url =  $module_url."/refund/notify_url/se_val/$payment_type_id-$payment_type-$client_type-$app_id-$scenary_id";

        $refund_date = date('Y-m-d H:i:s',time()); //必填，格式：如：2007-10-01 13:13:13
        $batch_no = $refund_request_data['batch_no'];//必填，格式：当天日期[8位]+序列号[3至24位]，如：201008010000001
		$detail_data = $refund_request_data['third_trade_no'].'^'.$refund_request_data['amount'].'^'.$refund_request_data['description'];

		$parameter = array(
				"service" => "refund_fastpay_by_platform_pwd",
				"partner" => trim($merchant_payment_info['alipay_partner']),
				"notify_url"	=> $notify_url,
				"seller_email"	=> trim($merchant_payment_info['alipay_seller']),
				"refund_date"	=> $refund_date,
				"batch_no"	=> $batch_no,
				"batch_num"	=> '1',//退款笔数,必填，参数detail_data的值中，“#”字符出现的数量加1，最大支持1000笔（即“#”字符出现的数量999个）
				"detail_data"	=> $detail_data,//退款格式：支付宝交易订单号^退款金额^退款描述#第二笔支付宝交易订单号^退款金额^退款描述
				"_input_charset"	=> strtolower('utf-8')
		);
		//建立请求
		$alipaySubmit = new AlipaySubmit($this->alipay_config);

		$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "确认");
		echo $html_text;	
		exit;		
	} 
	/**
	 * 扫码支付
	 */
	public function qrpay()
	{	
		$payment_type = $this->data['payment_type']['code'];
		$client_type = $this->data['client_type'];
		$pay_request_data = $this->data['pay_request_data']; 
		// $account_mer_id = $pay_data['account_mer_id'];

		$payment_type_id = $this->data['payment_type']['payment_type_id'];//支付类型ID
		$app_id = $this->data['pay_request_data']['auth_app_id'];//应用ID
		$scenary_id = $this->data['pay_request_data']['scenary_id'];//场景I
		$module_url = get_module_url();
		//如果是测试地址，就改为测试域名
		if(strstr($module_url,'172.16.30.13')){
			$module_url = 'http://opgdev.weilian.cn/payment';
		}
		if(strstr($module_url,'172.19.6.115')){
			$module_url = 'http://opgtest.weilian.cn/payment';
		}		

		$out_trade_no = trim($pay_request_data['pay_no']);
		$total_amount = trim($pay_request_data['amount']);
		$subject = trim($pay_request_data['subject']);
		//异步回调地址
		// $module_url = get_module_url();
		//$notify_url =  $module_url."/pay/qrpay_notify_url/se_val/$account_mer_id-$payment_type-$client_type";
		// $notify_url = "http://opg.weilian.cn/opg/payment/pay/qrpay_notify_url/se_val/$account_mer_id-$payment_type-$client_type";
		$notify_url =  $module_url."/pay/qrpay_notify_url/se_val/$payment_type_id-$payment_type-$client_type-$app_id-$scenary_id";

		$response = $this->qr_pay($out_trade_no,  $total_amount, $subject, $notify_url);

		$code = $response->alipay_trade_precreate_response->code;

		if($code == 10000){
/*			$returnResult['status'] = '1';	
			$returnResult['pay_no'] = $pay_request_data['pay_no'];	
			$returnResult['code_url'] = $response->alipay_trade_precreate_response->qr_code;	
			echo json_encode($returnResult);	*/
			$this->returnData['code'] = 200;
	        $this->returnData['message'] = 'success';   
	        $this->returnData['data']['pay_no'] = $pay_request_data['pay_no'];
	        $this->returnData['data']['code_url'] = $response->alipay_trade_precreate_response->qr_code;
		}
		exit(json_encode($this->returnData));
	}

    protected function config($merchant_payment_info)
    {
        $alipay_config = array();
		//合作身份者id，以2088开头的16位纯数字
        $alipay_config['partner'] = trim($merchant_payment_info['alipay_partner']);
        //收款支付宝账号
        $alipay_config['seller_id']	= trim($merchant_payment_info['alipay_partner']);
		//安全检验码，以数字和字母组成的32位字符
		//如果签名方式设置为“MD5”时，请设置该参数
		$alipay_config['key']	=  trim($merchant_payment_info['key']);
		//商户的私钥（后缀是.pen）文件相对路径
		$alipay_config['private_key_path']	= 'key/rsa_private_key.pem';
		//支付宝公钥（后缀是.pen）文件相对路径
		$alipay_config['ali_public_key_path']= 'key/alipay_public_key.pem';
        //签名方式 不需修改
        $alipay_config['sign_type']    = 'MD5';
        //字符编码格式 目前支持 gbk 或 utf-8
        $alipay_config['input_charset'] = strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = 'cacert.pem'; //getcwd().'\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';

        return $alipay_config;
    }
	
	public function display_result(){
		
	}
	/**
	 * 创建退款批次号
	 */
	public function create_refund_batch_no()
	{
		//该批次号是第三方支付需要的格式
		//必填，格式：当天日期[8位]+序列号[3至24位]，如：201008010000001
		//$d['batch_no'] = date('Ymd',time()).rand(10000,1000000);		
		$this->data['refund_data']['batch_no']= date('Ymd',time()).time().rand(10000, 1000000);
		return $this->data['refund_data']['batch_no'];

	}	

/*==========================扫码接口调用结果类start======================*/
    public function qr_pay($out_trade_no, $total_amount, $subject, $notify_url)
    {
        $biz_content = "{\"out_trade_no\":\"" . $out_trade_no . "\",";
        $biz_content .= "\"total_amount\":\"" . $total_amount . "\",\"discountable_amount\":\"0.00\",";
        $biz_content .= "\"subject\":\"" . $subject . "\",\"body\":\"test\",";
        $biz_content .= "\"goods_detail\":[{\"goods_id\":\"apple-01\",\"goods_name\":\"ipad\",\"goods_category\":\"7788230\",\"price\":\"88.00\",\"quantity\":\"1\"},{\"goods_id\":\"apple-02\",\"goods_name\":\"iphone\",\"goods_category\":\"7788231\",\"price\":\"88.00\",\"quantity\":\"1\"}],";
        $biz_content .= "\"operator_id\":\"op001\",\"store_id\":\"pudong001\",\"terminal_id\":\"t_001\",";
        $biz_content .= "\"timeout_express\":\"5m\"}"; 
        // echo $biz_content;    
/*        $request = new AlipayTradePrecreateRequest();
        $request->setBizContent($biz_content);
        $request->setNotifyUrl($notify_url);*/
        $request = array();
        $this->apiParas = $request['biz_content'] = $biz_content;
        $request['notify_url'] = $notify_url;
        $response = $this->aopclient_request_execute($request);
        
        return $response;
    }
	/**
	 * 使用SDK执行接口请求
	 * 
	 * @param unknown $request            
	 * @param string $token            
	 * @return Ambigous <boolean, mixed>
	 */
	public function aopclient_request_execute($request, $token = NULL)
	{
/*	    global $config;
	    require 'config.php';
	    $aop = new AopClient();
	    $aop->gatewayUrl = $config['gatewayUrl'];
	    $aop->appId = $config['app_id'];
	    $aop->rsaPrivateKeyFilePath = $config['merchant_private_key_file'];
	    $aop->apiVersion = "1.0";*/
	    $result = $this->execute($request, $token);
	    $this->writeLog("response: " . var_export($result, true));
	    return $result;
	}
	public function execute($request, $authToken = null, $appInfoAuthtoken=null) {

		if ($this->checkEmpty($this->postCharset)) {
			$this->postCharset = "UTF-8";
		}
		$this->fileCharset = mb_detect_encoding($this->qrconfig['app_id'], "UTF-8,GBK");
		//		//  如果两者编码不一致，会出现签名验签或者乱码
		if (strcasecmp($this->fileCharset, $this->postCharset)) {
			// writeLog("本地文件字符集编码与表单提交编码不一致，请务必设置成一样，属性名分别为postCharset!");
			throw new Exception("文件编码：[" . $this->fileCharset . "] 与表单提交编码：[" . $this->postCharset . "]两者不一致!");
		}

		$iv=null;
		if(!$this->checkEmpty($this->qrconfig['apiVersion'])){
			$iv=$this->qrconfig['apiVersion'];
		}else{
			$iv=$this->apiVersion;
		}
		//组装系统参数
		$sysParams["app_id"] = $this->qrconfig['app_id'];
		$sysParams["version"] = $iv;
		$sysParams["format"] = $this->format;
		$sysParams["sign_type"] = $this->signType;
		$sysParams["method"] = $this->getApiMethodName();
		$sysParams["timestamp"] = date("Y-m-d H:i:s");
		$sysParams["auth_token"] = $authToken;
		$sysParams["alipay_sdk"] = $this->alipaySdkVersion;
		$sysParams["terminal_type"] = $this->terminalType;
		$sysParams["terminal_info"] = $this->terminalInfo;
		$sysParams["prod_code"] = $this->prodCode;
		$sysParams["notify_url"] = $request['notify_url'];
		$sysParams["charset"] = $this->postCharset;
		$sysParams["app_auth_token"] = $appInfoAuthtoken;

		//获取业务参数
		// $apiParams = $request->getApiParas();
		$apiParams = $request;

		//签名
		$sysParams["sign"] = $this->generateSign(array_merge($apiParams, $sysParams));

		//系统参数放入GET请求串
		$requestUrl = $this->gatewayUrl . "?";
		foreach ($sysParams as $sysParamKey => $sysParamValue) {
			$requestUrl .= "$sysParamKey=" . urlencode($this->characet($sysParamValue, $this->postCharset)) . "&";
		}
		$requestUrl = substr($requestUrl, 0, -1);

		//发起HTTP请求
		try {
			$resp = $this->curl($requestUrl, $apiParams);
		} catch (Exception $e) {
			$this->logCommunicationError($sysParams["method"], $requestUrl, "HTTP_ERROR_" . $e->getCode(), $e->getMessage());
			return false;
		}
		//解析AOP返回结果
		$respWellFormed = false;

		// 将返回结果转换本地文件编码
		$r = iconv($this->postCharset, $this->fileCharset . "//IGNORE", $resp);

		$signData = null;

		if ("json" == $this->format) {
			$respObject = json_decode($r);
			if (null !== $respObject) {
				$respWellFormed = true;
				$signData = $this->parserJSONSignData($request, $resp, $respObject);
			}
		} else if ("xml" == $this->format) {
			$respObject = @ simplexml_load_string($resp);
			if (false !== $respObject) {
				$respWellFormed = true;
				$signData = $this->parserXMLSignData($request, $resp);
			}
		}
		//返回的HTTP文本不是标准JSON或者XML，记下错误日志
/*		if (false === $respWellFormed) {
			$this->logCommunicationError($sysParams["method"], $requestUrl, "HTTP_RESPONSE_NOT_WELL_FORMED", $resp);
			return false;
		}*/

		// 验签
		if (!$this->checkEmpty($this->qrconfig['merchant_public_key_file'])) {

			if ($signData == null || $this->checkEmpty($signData['sign']) || $this->checkEmpty($signData['signSourceData'])) {

				throw new Exception(" check sign Fail! The reason : signData is Empty");
			}
			// 获取结果sub_code
			$responseSubCode=$this->parserResponseSubCode($request,$resp,$respObject,$this->format);

			if (!$this->checkEmpty($responseSubCode) || ( $this->checkEmpty($responseSubCode) && !$this->checkEmpty($signData['sign']))) {

				$checkResult = $this->verify($signData['signSourceData'], $signData['sign'], $this->qrconfig['merchant_public_key_file']);
				print_r($checkResult);

				if (!$checkResult) {

					if (strpos($signData['signSourceData'], "\\/") > 0) {

						$signData['signSourceData'] = str_replace("\\/", "/", $signData['signSourceData']);

						$checkResult = $this->verify($signData['signSourceData'], $signData['sign'], $this->qrconfig['merchant_public_key_file']);

						if (!$checkResult) {
							throw new Exception("check sign Fail! [sign=" . $signData['sign'] . ", signSourceData=" . $signData['signSourceData'] . "]");
						}

					} else {

						throw new Exception("check sign Fail! [sign=" . $signData['sign'] . ", signSourceData=" . $signData['signSourceData'] . "]");
					}

				}
			}
		}
		return $respObject;
	}
	/**
	 * 校验$value是否非空
	 *  if not set ,return true;
	 *    if is null , return true;
	 **/
	protected function checkEmpty($value) {
		if (!isset($value))
			return true;
		if ($value === null)
			return true;
		if (trim($value) === "")
			return true;

		return false;
	}

	function writeLog($text)
	{
	    // $text=iconv("GBK", "UTF-8//IGNORE", $text);
	    $text = $this->characet($text);
	    file_put_contents(dirname(__FILE__) . "/qrpay/log/log.txt", date("Y-m-d H:i:s") . "  " . $text . "\r\n", FILE_APPEND);
	}

	protected function qrconfig()
	{
		$qrconfig = array();
		$qrconfig['alipay_public_key_file']    = dirname(__FILE__) . "/key/alipay_rsa_public_key.pem";
		$qrconfig['merchant_private_key_file'] = dirname(__FILE__) . "/qrpay/key/rsa_private_key.pem";
		// $qrconfig['merchant_public_key_file'] = dirname(__FILE__) . "/qrpay/key/rsa_public_key.pem";
		$qrconfig['charset'] = "GBK";
		$qrconfig['gatewayUrl'] = "https://openapi.alipay.com/gateway.do";
		$qrconfig['app_id'] = "2016022601165157";
		$qrconfig['apiVersion'] = "1.0";
		return $qrconfig;
	}  

	public function getApiMethodName()
	{
		return "alipay.trade.precreate";
	}

	public function generateSign($params) {
		return $this->sign($this->getSignContent($params));
	}

	protected function sign($data) {
		$priKey = file_get_contents($this->qrconfig['merchant_private_key_file']);
		$res = openssl_get_privatekey($priKey);
		openssl_sign($data, $sign, $res);
		openssl_free_key($res);
		$sign = base64_encode($sign);
		return $sign;
	}

	protected function getSignContent($params) {
		ksort($params);

		$stringToBeSigned = "";
		$i = 0;
		foreach ($params as $k => $v) {
			if (false === $this->checkEmpty($v) && "@" != substr($v, 0, 1)) {

				// 转换成目标字符集
				$v = $this->characet($v, $this->postCharset);

				if ($i == 0) {
					$stringToBeSigned .= "$k" . "=" . "$v";
				} else {
					$stringToBeSigned .= "&" . "$k" . "=" . "$v";
				}
				$i++;
			}
		}
		unset ($k, $v);

		return $stringToBeSigned;
	}
	/**
	 * 转换字符集编码
	 * @param $data
	 * @param $targetCharset
	 * @return string
	 */
	function characet($data, $targetCharset) {
		if (!empty($data)) {
			$fileType = $this->fileCharset;
			if (strcasecmp($fileType, $targetCharset) != 0) {

				$data = mb_convert_encoding($data, $targetCharset);
				//$data = iconv($fileType, $targetCharset.'//IGNORE', $data);
			}
		}
		return $data;
	}	

	function parserJSONSignData($request, $responseContent, $responseJSON) {
/*		$signData = new SignData();
		$signData->sign = $this->parserJSONSign($responseJSON);
		$signData->signSourceData = $this->parserJSONSignSource($request, $responseContent);*/
		$signData = array();
		$signData['sign'] = $responseJSON->sign;
		$signData['signSourceData'] = $this->parserJSONSignSource($request, $responseContent);

		return $signData;

	}

	function parserXMLSignData($request, $responseContent) {

		$signData = new SignData();
		$signData->sign = $this->parserXMLSign($responseContent);
		$signData->signSourceData = $this->parserXMLSignSource($request, $responseContent);

		return $signData;
	}

	function parserJSONSignSource($request, $responseContent) {

		$apiName = $this->getApiMethodName();
		$rootNodeName = str_replace(".", "_", $apiName) . $this->RESPONSE_SUFFIX;

		$rootIndex = strpos($responseContent, $rootNodeName);
		$errorIndex = strpos($responseContent, $this->ERROR_RESPONSE);


		if ($rootIndex > 0) {

			return $this->parserJSONSource($responseContent, $rootNodeName, $rootIndex);
		} else if ($errorIndex > 0) {

			return $this->parserJSONSource($responseContent, $this->ERROR_RESPONSE, $errorIndex);
		} else {

			return null;
		}
	}

	function parserJSONSource($responseContent, $nodeName, $nodeIndex) {
		$signDataStartIndex = $nodeIndex + strlen($nodeName) + 2;
		$signIndex = strpos($responseContent, "\"" . $this->SIGN_NODE_NAME . "\"");
		// 签名前-逗号
		$signDataEndIndex = $signIndex - 1;
		$indexLen = $signDataEndIndex - $signDataStartIndex;
		if ($indexLen < 0) {

			return null;
		}

		return substr($responseContent, $signDataStartIndex, $indexLen);

	}	

	protected function curl($url, $postFields = null) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FAILONERROR, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$postBodyString = "";
		$encodeArray = Array();
		$postMultipart = false;

		if (is_array($postFields) && 0 < count($postFields)) {


			foreach ($postFields as $k => $v) {
				if ("@" != substr($v, 0, 1)) //判断是不是文件上传
				{

					$postBodyString .= "$k=" . urlencode($this->characet($v, $this->postCharset)) . "&";
					$encodeArray[$k] = $this->characet($v, $this->postCharset);
				} else //文件上传用multipart/form-data，否则用www-form-urlencoded
				{
					$postMultipart = true;
					$encodeArray[$k] = new \CURLFile(substr($v,1));
				}

			}
			unset ($k, $v);
			curl_setopt($ch, CURLOPT_POST, true);
			if ($postMultipart) {
				curl_setopt($ch, CURLOPT_POSTFIELDS, $encodeArray);
			}else{
				curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString, 0, -1));
			}
		}

		if($postMultipart){

			$headers = array('content-type: multipart/form-data;charset=' . $this->postCharset.';boundary='.$this->getMillisecond());
		}else{

			$headers = array('content-type: application/x-www-form-urlencoded;charset=' . $this->postCharset);
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$reponse = curl_exec($ch);

		if (curl_errno($ch)) {
			throw new Exception(curl_error($ch), 0);
		} else {
			$httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if (200 !== $httpStatusCode) {
				throw new Exception($reponse, $httpStatusCode);
			}
		}
		curl_close($ch);
		return $reponse;
	}

}