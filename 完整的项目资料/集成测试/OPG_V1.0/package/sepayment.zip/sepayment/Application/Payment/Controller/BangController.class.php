<?php
namespace Payment\Controller;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package	suneee
 * @author	SunEEE PHP Team
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version	Version 1.0.0
 */
use Payment\Controller\PaymentController;
use Think\Log;
/**
 * 中金绑卡控制器
 * 
 * 这是中金绑卡的入口
 * 
 *
 * @author		SunEEE PHP Team(kevin.qin)
 * @created		2015-07-29
 * @modified    2015-07-29
*/
class BangController extends PaymentController {
	
	/**
	 * 构造类
	 */
    public function __construct()
    {
        parent::__construct(); 
    }
    
    /**
     * 绑卡的入口
     * 
     * a. 商户站点绑卡请求的入口
     * b. 请求到第三方绑卡接口
     */
    public function index()
    {
     
		//1. 检查绑卡参数合法性
		$this->check_params();
		
		if($this->has_err())
		{
			$this->errlog('verify params failed for first bang request');
		}
		$this->assign('bang_data', $this->bang_data);
		
		//2 .直接进入第三方绑卡
		$this->request_third_bang();
		
		
		exit;
    }
    
    /**
     * FLOW 校验参数 (该流程校验不会退出程序,只有记录入库后才根据状态去决定是否退出)
     * 
     * a. 如果验证失败则直接返回错误调用到商户站点回调页
     * b. 更新会话记录状态 '11/12 | 13/14', 新增支付请求流水记录状态为'11/12 | 13/14'
     * @and_check_tie  true 判断是否已经退款
     * @return boolean TRUE 继续执行, FALSE 回调告诉错误,并终止逻辑
     */
    protected function check_params()
    {
    	//得到需检查的参数
		// $p = I('get.');
		$p = I('get.')?I('get.'):I('post.');
		$bang_data=$p;
		//得到支付的配置
		$conf = C('bang');
 
		//定义配置
		$pconf = '';
		$merchant_info = '';
		
    	//得到返回url,供返回使用
    	$this->return_url = $p['return_url'];
    		
    	//得到参数格式配置
    	$pconf = $conf['merchat_to_se_payresult'];
       
		//验证参数的合法性
		$r = $this->verify_all_params($p, $pconf);
		
		if($r === FALSE)
		{
			//如果验证不合法则报错
			return FALSE;
		}   
			
		//验证授权号
		$m_mer = D('Merchant');
			
		$merchant_info = $m_mer->get_by_payment_code($p['se_payment_code']);
		
		if(!isset($merchant_info['se_payment_code']) || !isset($merchant_info['se_payment_key'])
			 || empty($merchant_info['se_payment_code']) || $merchant_info['se_payment_code']!=$p['se_payment_code']
		)
		{
			//如果验证不合法则输入错误状态并报错
			$this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code: ' . $p['se_payment_code']);
			return FALSE;

		}

			//$payment_type = D('PaymentType')->get_data_by_id($pay_data['payment_type_id']);
			
		//验证签名
		$se_sign = $this->build_sign($p, $pconf, $merchant_info['se_payment_key']);
	    if(!$se_sign || $p['se_sign'] != $se_sign)
	    {
		//如果验证不合法则输入错误状态并报错
			$this->set_status('INVALID_SIGN', 'this is invalid sign: ' . $p['se_sign']);
	    	return FALSE;
	    }
	    //赋值绑卡数据
	    $this->bang_data = $bang_data;
	    return TRUE;				
			
		}

        
    
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 ------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//    

    /**
     * 请求第三方绑卡验证
     * 
     * @return void
     */    
    protected function request_third_bang()
    { 
    	
		//1. 检查是否是wap/web请求
		$data['client_type'] = is_mobile()===TRUE ? 'wap' : 'web';

		//2. 实例化一个支付类并进行绑卡且得到结果状态
		$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/CmbankPay'.'/'.$data['client_type'].'/';
		$data['merchant_data_ctype_path']=MER_DATA_PATH.'2/CmbankPay/web/';
		$data= array_merge($this->bang_data,$data);
		//$data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$se_payment_type.'/'.$se_client_type.'/';
		$cls = load_pm_lib('payment/CmbankPay'.'/'.$data['client_type'].'/'.'CmbankPay', FALSE, $data);
		

		//2.1 检查回调参数并返回结果的状态联数组

		$this->result = $cls->bang();
		$this->check_third_return_val($this->result); 
		//4. 回调商户的同步回调return_url
		//4.1   检查是否有回调页面,如果没有直接显示当前SE的结果页面
		$bang_data = $this->result ;	
		if(!isset($tie_data['return_url']) || empty($tie_data['return_url']))
		{  
			if($bang_data['status']==1){
				$this->assign('bang_data', $bang_data);
				if(is_mobile()){
		            $this->display('wap_success');
		        }else{
		            $this->display('web_success');         
		        }
				exit;
			}else{
			    $this->assign('bang_data', $bang_data);
				if(is_mobile()){
					$this->display('wap_error');
				}else{
					$this->display('web_error');
				}
				exit;
			}
		}	
    }    
    

     /* public function test()
    {

		$cls = load_pm_lib('payment/WeChatPay/web/WeChatPay', FALSE, $data="");

		$cls->display_result($this);
		
    }   */

    
    /**
     * 得到类型,用来给模板区分具体的动作
     */
    public function get_type()
    {
    	return 'bang';
    }
    
}