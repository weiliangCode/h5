<?php
namespace Payment\Controller;
    /**
     * SunEEE
     * 象翌微链科技发展有限公司内部的PHP框架
     * Copyright (c) 2015 - 2016, SunEEE 技术
     * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
     * 授权后只能使用,不能修改里面的源代码.
     * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
     * @package    suneee
     * @author     SunEEE PHP Team
     * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
     * @version    Version 1.0.0
     */
/**
 * 支付控制器
 * 这是支付的入口
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class ProcessTransferController extends PaymentController{

    /**
     * 转账, 商户第二次回调请求会带转账号过来。
     * @type string
     */
    protected $transfer_no = '';

    /**
     * 转账请求id
     */
    protected $transfer_request_id = '';

    /**
     * 请求参数, 客户初始请求的参数
     * @type string
     */
    protected $req_params = '';

    /**
     * 转账的入口
     * a. 商户站点请求的入口
     * b. 得到转账号再次请求
     * c. 商户响应一个转账页面
     */
    public function index(){
        //1. 检查参数合法性, 第一次支付请求未入库, 第二次才入库
        $this->check_params();

        //2. 更新支付类型已经状态,并更新商户账号ID
        $d['payment_type_id'] = $this->payment_type_id;
        $d['merchant_account_id'] = $this->transfer_data['merchant_account_id'];
        $this->update_status('TransferRequest', $this->transfer_no, 21, 22, $d); //支付类型验证成功, 支付类型验证失败
        if($this->has_err()){
            $this->errlog('Invalid params for process pay controller');
        }

        //3. 请求支付网关
        $this->request_third_transfer();

        exit;
    }

    /**
     * FLOW 校验处理支付类型的参数
     * @return bool
     */
    protected function check_params(){
        //得到需检查的参数
        $p = I('post.');

        //验证第一次请求(检查没有包含支付号的请求)
        if(empty($p['transfer_no']) || empty($p['payment_type_id'])){
            $this->set_status('EMPTY_PARAMS', 'this is invalid pay_no or payment_type_id for process pay');
            return false;
        }
        $this->transfer_no = $p['transfer_no'];    //赋值交易号

        //得到支付的配置
        $conf = C('transfer');
        //得到参数格式配置
        $pconf = $conf['merchat_to_se_pay'];

        //验证参数的合法性
        $r = $this->verify_all_params($p, $pconf);
        if($r === false){
            return false;
        }

        //验证授权号
        $m_mer = D('Merchant');
//        $transfer_data = $m_mer->get_merchant_transfer_data_by_transfer_no($p['transfer_no'], $p['payment_type_id']);
        $transfer_data = $m_mer->get_info_by_transfer_no($p['transfer_no']);
//        var_dump($transfer_data);exit('wwwww');
        
        $transfer_data['OrderNo'] = $p['OrderNo'];
        $transfer_data['institution_number'] = $p['institution_number'];
        $transfer_data['AccountType'] = $p['AccountType'];
        $transfer_data['BankID'] = $p['BankID'];
        /* $transfer_data['AccountName'] = $p['AccountName'];
        $transfer_data['AccountNumber'] = $p['AccountNumber'];
        $transfer_data['BranchName'] = $p['BranchName'];
        $transfer_data['Province'] = $p['Province'];
        $transfer_data['City'] = $p['City']; */
        //得到返回url,供返回使用
        $this->return_url = isset($transfer_data['return_url']) ? $transfer_data['return_url'] : '';
//var_dump($transfer_data);
//exit(1111111);
        //如果没有账号则报错
        if(empty($transfer_data['se_private_key']) || empty($transfer_data['se_payment_code'])){
            $this->set_status('INVALID_MERCHANT', 'this is invalid se_payment_code for '.$p['se_payment_code']);
            return false;
        }
        $this->transfer_data = $transfer_data; //得到商家信息

        //验证支付类型是否合法
        $this->payment_type_id = $p['payment_type_id'];    //赋值支付类型
        $m_pm_type = D('PaymentType');
        $payment_type = $m_pm_type->checkPayment($transfer_data['auth_app_id'],$p['payment_type_id']);

        if(!$payment_type){
            $this->set_status('INVALID_PAYMENT_TYPE', 'this is invalid payment type: '.$payment_type);
            return false;
        }
        $this->payment_type = $payment_type;

        //验证签名
        $p['se_payment_code'] = $transfer_data['se_payment_code'];
        $se_sign = $this->build_sign($p, $pconf, $transfer_data['se_private_key']);
        if(!$se_sign || $p['se_sign'] != $se_sign){
            $this->set_status('INVALID_SIGN', 'this is invalid sign for '.$p['se_sign']);
            return false;
        }
        return true;
    }


    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------- 业务service层, 为了效率不分层和模块去封装,直接并到controller实现 -----------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//

    /**
     * 请求第三方支付
     * @return void
     */
    protected function request_third_transfer(){
        //2. 实例化一个支付类并进行支付且得到结果状态
        $data['payment_type'] = $this->payment_type;
        $data['transfer_data'] = $this->transfer_data;
        $data['third_lib_path'] = APP_PATH.MODULE_NAME.'/Lib/payment/'.$data['payment_type']['code'].'/'.$data['client_type'];

        // 获取当前app,payment 下的商户配置参数
        $arr = D('PaymentParameterDefine')->getList(
            $data['payment_type']['payment_type_id'],
            $data['transfer_data']['scenary_id'],
            $data['transfer_data']['auth_app_id']
            );
        $data['payment_type'] = array_merge($data['payment_type'], $arr);

        switch($data['transfer_data']['scenary_id']){
            case '1' :
                $data['client_type'] = 'web';
                break;
            case '2' :
                $data['client_type'] = 'wap';
                break;
            case '3' :
                $data['client_type'] = 'ios';
                break;
            case '4' :
                $data['client_type'] = 'android';
                break;
        }

        //2.3 载入第三方支付类
        $cls = load_pm_lib('payment/'.$this->payment_type['code'].'/'.$data['client_type'].'/'.$this->payment_type['code'], false, $data);
        //调用第三方支付,并得到结果
        $this->update_status('TransferRequest', $this->transfer_data['transfer_no'], 30,32);
        $this->result = $cls->transfer();
        /*
     $this->result = array(
           //SE支付网关交易号
           'transfer_no' => 'xxx',
           //第三方交易号
           'third_trade_no' => 'xxx',
           //SE支付网关的状态
           'status' => '1/bool(TRUE)/string(SUCCESS)/错误状态是第三方的错误状态'),
           //SE系统状态信息,描述状态的细节,比如错误状态的原因,成功不需要做描述
           'status_msg' => '签名错误'
       );
       */
        $this->check_third_return_val($this->result);
        //3. 如果是跳入第三方结果页面下面代码不会被执行, 如果$cls->pay()中只接受第三方值, 执行下面的代码.
        //返回data值
        $transfer_no = $this->result['transfer_no'];
        $update_data['third_trade_no'] = isset($this->result['third_trade_no']) ? $this->result['third_trade_no'] : '';
        $this->update_status('TransferRequest', $transfer_no, 31, 32, $update_data);    //得到成功的支付结果, 得到失败的支付结果

        // 执行异步回调
        $result = $cls->notify_result();
        if($result)
            $this->update_status('TransferRequest', $transfer_no, 51, 52);
        // 同步响应
        $this->return_url();
    }

    /**
     * 得到类型,用来给模板区分具体的动作
     */
    public function get_type(){
        return 'transfer';
    }
    // 同步响应
    private function return_url(){
        $params = $this->get_return_result();
        // 商户同步回调
        if(isset($this->transfer_data['return_url']) && !empty($this->transfer_data['return_url'])){
            $this->update_status('TransferRequest', $this->transfer_data['transfer_no'], 51, 52);
            header('Location:'.$this->transfer_data['return_url'].'?'.http_build_query($params));
        }else{
            // 平台展示结果
            if($this->has_err())
                    $this->errlog();
            else{
                $this->assign('transfer_data', $this->transfer_data);
                if(is_mobile()) $this->display('wap_success');
                else $this->display('web_success');
                exit;
            }
        }
    }

    /**
     * 得到返回结果
     * @return Array
     */
    private function get_return_result(){
        $params = array('se_payment_code' => $this->transfer_data['se_payment_code'], 'transfer_no' => $this->transfer_data['transfer_no'], 'payment_type_id' => $this->transfer_data['payment_type_id'], 'created_ts' => time(), 'result' => $this->status, 'msg' =>  $this->status_msg);
        $params['se_sign'] = md5(md5($params['se_payment_code'].$params['transfer_no'].$params['created_ts']).$this->transfer_data['se_private_key']);
        unset($params['se_payment_code']);
        return $params;
    }
}