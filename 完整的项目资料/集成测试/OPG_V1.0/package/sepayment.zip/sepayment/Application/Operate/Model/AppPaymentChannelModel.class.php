<?php
namespace Operate\Model;
/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */
/**
 * 应用支付渠道表模型
 * 用来操作支付类型数据模型
 * @author         SunEEE PHP Team(kevin.qin)
 * @created        2015-07-29
 * @modified       2015-07-29
 */
class AppPaymentChannelModel extends OperateModel{
    /**
     * 返回数据总数
     * @return int
     */
    public function getCount(array $where = array(), $whereStr=''){
        $re = $this->field('count(*) as a')
            ->join('merchant_app on app_payment_channel.merchant_app_id=merchant_app.merchant_app_id AND merchant_app.status_del=0')
            ->join('merchant_payment_channel ON merchant_payment_channel.merchant_id = merchant_app.merchant_id and merchant_payment_channel.payment_type_id = app_payment_channel.payment_type_id')
            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id')
            ->join('merchant on merchant_app.merchant_id=merchant.merchant_id')
            ->join('payment_scenary on payment_scenary.scenary_id=app_payment_channel.scenary_id')
            ->where($where)
            ->where($whereStr)
            ->select();
        return $re[0]['a'];
    }

    /**
     * 根据查询条件,返回2维数组,用于应用支付渠道
     *
     * @param array  $key
     * @param array  $where
     * @param string $order
     * @param string $limit
     *
     * @author binqian
     * @return mixed 2维数组
     */
    public function searchData(array $key = array(), array $where = array(), $order = '', $limit = '', $whereStr=''){
        $re = $this
            ->join('merchant_app on app_payment_channel.merchant_app_id=merchant_app.merchant_app_id AND merchant_app.status_del=0')
            ->join('merchant_payment_channel ON merchant_payment_channel.merchant_id = merchant_app.merchant_id and merchant_payment_channel.payment_type_id = app_payment_channel.payment_type_id')
            ->join('payment_type on app_payment_channel.payment_type_id=payment_type.payment_type_id')
            ->join('merchant on merchant_app.merchant_id=merchant.merchant_id')
            ->join('payment_scenary on payment_scenary.scenary_id=app_payment_channel.scenary_id')
            ->field($key)
            ->where($where)
            ->where($whereStr)
            ->limit($limit)
            ->order($order)
            ->select();
//        echo $this->getlastsql();
//        var_dump($re);exit;
        return $re;
    }

    /**
     * 根据更新条件,返回字符串值
     *
     * @param array  $key
     * @param array  $where
     * @param string $order
     * @param string $limit
     *
     * @author binqian
     * @return mixed 2维数组
     */
    public function setUpdateData(array $where = array(), array $update = array()){
        $up = $this
            ->where($where)
            ->data($update)
            ->save();
        //echo $this->getlastsql();
        return $up;
    }

    /**
     * 根据更新条件,返回字符串值
     *
     * @param array  $key
     * @param array  $where
     * @param string $order
     * @param string $limit
     *
     * @author binqian
     * @return mixed 2维数组
     */
//    public function setUpdateDataCompany(array $where = array(), array $update = array()){
//        $fileds = '';
//        foreach( $update as $f => $v ){
//            $fileds .= $fileds ? ",merchant_payment_channel.{$f}='{$v}'" : "merchant_payment_channel.{$f}='{$v}'";
//        }
//        $sql = 'UPDATE merchant_payment_channel inner join merchant_app on '.'merchant_app.merchant_app_id=merchant_payment_channel.merchant_app_id set '.$fileds.' where merchant_app.merchant_id="'.$where['merchant_app.merchant_id'].'" '.'and merchant_payment_channel.payment_type_id="'.$where['payment_type_id'].'"';
//        //		exit($sql);
//        return $this->execute($sql);
//    }

    /**
     * 根据查询条件,返回字符串值
     *
     * @param  $payment_id
     * @param  $app_id
     *
     * @author binqian
     * @return mixed 2维数组
     */
    public function getByMerchantAppId($payment_id = '', $app_id = '', $scenary_id = ''){
        if(empty($payment_id) || !is_numeric($payment_id)){
            return false;
        }
        if(empty($app_id) || !is_numeric($app_id)){
            return false;
        }
        if(empty($scenary_id) || !is_numeric($scenary_id)){
            return false;
        }

        /*$r['para_define_id'] = $this->getScenary($payment_id,$scenary_id);
        $scenary=$r['para_define_id'];*/
        $wmap['merchant_payment_channel.payment_type_id'] = $payment_id;
        $wmap['merchant_payment_channel.merchant_app_id'] = $app_id;
        $wmap['merchant_payment_channel.scenary_id'] = $scenary_id;

        //根据场景id与支付类型id和payment_parameter_define表进行联表查询
        $r = $this->join('payment_type on merchant_payment_channel.payment_type_id=payment_type.payment_type_id')->join('payment_parameter_define on merchant_payment_channel.scenary_id=payment_parameter_define.scenary_id')->join('merchant_payment_config on payment_parameter_define.para_define_id=merchant_payment_config.para_define_id')->field('payment_parameter_define.para_name,merchant_payment_config.para_value')->where($wmap)->select();
        //echo $this->getlastsql();
        return $r;
    }

    /**
     * 根据渠道ID返回渠道状态
     *
     * @param  $payment_id
     *
     * @author binqian
     * @return 字符串
     */
//    public function getAtive($payment_type_id){
//        if(empty($payment_type_id) || !is_numeric($payment_type_id)){
//            return false;
//        }
//        $PaymentType = D('PaymentType');
//        //查询条件
//        $wmap['payment_type.payment_type_id'] = $payment_type_id;
//        return $PaymentType->get($wmap);
//    }
}