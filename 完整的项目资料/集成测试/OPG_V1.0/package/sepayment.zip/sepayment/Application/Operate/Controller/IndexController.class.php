<?php
namespace Operate\Controller;
class IndexController extends OperateController{
    public function index(){
        $this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;}
        body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; }
        p{ line-height: 1.8em; font-size: 36px }</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎访问 <b>翌支付运营平台</b>！</p>
        <br/>[ 您现在访问的是运营平台,目前还在开发中!]
        <br/>[商户平台请访问 <a href="'.U("/home").'">商户平台</a>]
        <br/>[支付测试Demo请访问 <a href="'.U("/payment/demo").'">支付Demo</a>]
        </div><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>', 'utf-8');
    }
// {"act":"1","method":"Index","op":"testSysConfig","data":{},"sign":"456678wewqesa45d64sa56wqe45"}
    public function testSysConfig(){
        $this->sessionId->account = 'system';
//        $r = D('Operate/SysConfig')->PAYMENTSTATUS =  [
//            '处理中' => [1,2,4,6,7,9,12,13],
//            '失败' => [3,5,8,11,14,16],
//            '成功' => [10,15,17,18]
//        ];;
//        var_dump($r);exit;
        $r = D('Operate/SysConfig')->SMSCONTENT ;
        $arr = [
            'content' =>$r,
            'active' =>1,
        ];
        D('Operate/SysConfig')->SMS = $arr;
        var_dump(D('Operate/SysConfig')->SMS);exit;
//        $r['content'] = '<h2>欢迎加入翌支付</h2><br>
//							请点击以下按钮进行邮箱账号确认，24小时内确认均有效。<br>
//							<a href={#register_url}>确认账号</a><br>
//							如果按钮无效，请复制以下链接在浏览器中打开完成账号确认。<br>
//							<a href={#register_url}>{#register_url}</a><br>';
//        $r['active'] = 1;
//        $r = D('Operate/SysConfig')->REGISTER = $r;
//        var_dump($r);exit;
//        $this->rrr();
    }
    private function rrr(){
        $data= [
                    '处理中' => [1,2,4,6,7,9,10,12,13],
                    '失败' => [3,5,8,11,14,16],
                    '成功' => [15,17,18]
                ];
        D('Operate/SysConfig')->setSysConfig('PAYMENTSTATUS',$data);
//        D('Operate/SysConfig')->PAYMENTSTATUS=$data;
    }

}