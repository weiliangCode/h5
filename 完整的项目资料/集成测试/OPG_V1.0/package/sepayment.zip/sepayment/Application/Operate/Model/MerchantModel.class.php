<?php
namespace Operate\Model;

/**
 * SunEEE
 * 象翌微链科技发展有限公司内部的PHP框架
 * Copyright (c) 2015 - 2016, SunEEE 技术
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 * @package    suneee
 * @author     SunEEE PHP Team
 * @copyright  Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version    Version 1.0.0
 */

class MerchantModel extends OperateModel{
    /**
     * 获取商户列表
     * @params String
     * @return array/FALSE 当前1行数据
     */
    public function getMerchantList($search = array(), $order = '', $offset, $pageSize){
        $r = $this
            ->join('merchant_info ON merchant.merchant_id = merchant_info.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->field('merchant.merchant_id,merchant.name,merchant.memo,merchant_info.audit_status,reg_user.account')
            ->where($search)
            ->limit($offset, $pageSize)
            ->order($order)
            ->select();
//        echo $this->getLastSql();exit;
        return $r;
    }

    /**
     * 获取数据总数
     *
     * @params String
     *
     * @return array/FALSE 当前1行数据
     */
    public function getCount($search = array()){
        $count = $this
            ->join('merchant_info ON merchant.merchant_id = merchant_info.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->where($search)
            ->count();
        return $count;
    }

    /**
     * 通过商户id得到商户信息
     * @params String $mer_id 商户ID
     * @return array/FALSE 当前1行数据
     */
    public function getById($mer_id = ''){
        if(empty($mer_id) || !is_numeric($mer_id)){
            return false;
        }
        $wmap['merchant.merchant_id'] = $mer_id;
        // $wmap['merchant.active'] = 1;
        $r = $this
            ->join('merchant_info ON merchant.merchant_id = merchant_info.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->field('merchant.merchant_id, merchant.name, merchant_info.audit_status, merchant_info.reg_address, merchant_info.work_address, merchant_info.lisence_image, merchant_info.org_image, merchant_info.contact_name, merchant_info.contact_mail, merchant_info.contact_mobile,reg_user.account')
            ->where($wmap)
            ->find();
        $r['app_name'] = $this->getAppById($mer_id);
        $r['payment_channel'] = $this->getChannelByArray($r['app_name']);
        $r['app_name'] = array_values($r['app_name']);
        return $r;
    }

    /**
     * 通过商户id得到商户旗下应用
     * @params String $mer_id 商户ID
     * @return array/FALSE 当前1行数据
     */
    public function getAppById($mer_id = ''){
        if(empty($mer_id) || !is_numeric($mer_id)){
            return false;
        }
        $wmap['merchant.merchant_id'] = $mer_id;
        $wmap['merchant_app.status_flag'] = 2;  //已开通应用
        $wmap['merchant_app.status_del'] = 0;   //未删除

        $r = $this
            ->join('merchant_app ON merchant.merchant_id = merchant_app.merchant_id')
            ->field('merchant_app.app_name,merchant_app.merchant_app_id')
            ->where($wmap)
            ->order('merchant_app.status_ts desc')
            ->select();
        $data = [];
        foreach( $r as $key => $value ){
            $data[ $value['merchant_app_id'] ] = $value['app_name'];
        }
        return $data;
    }

    /**
     * 通过应用数组 得到商户已开通渠道
     * @param array $arr
     * @return array
     */
    public function getChannelByArray(array $arr){
        $obj = D('AppPaymentChannel');
        $str = 'app_payment_channel.merchant_app_id in (';
        foreach($arr as $k => $v){
            $str .= $k.',';
        }
        $str = rtrim($str,',');
        $str .=')';
        $res = $obj
            ->join('payment_type on payment_type.payment_type_id=app_payment_channel.payment_type_id')
            ->where($str)
            ->field('payment_type.name')
            ->distinct(true)
            ->select();
//        echo $obj->getlastsql();
        $a = [];
        foreach($res as $v){
            $a[] = $v['name'];
        }
        return $a;
    }

    /**
     * 申请签约商户信息
     * @params String $mer_id 商户ID
     * @return array/FALSE 当前1行数据
     */
    public function getApplyInfo($mer_id = ''){
        if(empty($mer_id) || !is_numeric($mer_id)){
            return false;
        }
        $wmap['merchant.merchant_id'] = $mer_id;

        $r = $this
            ->join('merchant_info ON merchant.merchant_id = merchant_info.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->field(
                'merchant.merchant_id, 
                merchant.name,
                reg_user.account,
                merchant_info.reg_address,
                merchant_info.work_address,
                merchant_info.lisence_image, 
                merchant_info.org_image, 
                merchant_info.contact_name, 
                merchant_info.contact_mail,
                merchant_info.contact_mobile,
                merchant_info.apply_ts'
            )
            ->where($wmap)
            ->find();
        return $r;
    }

    /**
     * 保存商户相关信息
     * @params array $data 商户请求数据
     * @return bool
     */
    public function saveData($data){
        if(isset($data['merchant_id']) && !empty($data['merchant_id'])){
            //更新
            return $this->where('merchant_id='.$data['merchant_id'])->save($data);
        }else{
            //创建
            return $this->add($data);
        }
    }

    // 生成 se_payment_code且 将active更改为 1
    public function create_Se_Code($merchant_id){
        return $this->execute('UPDATE merchant SET `se_payment_code`=md5(`name`),`active`="1" WHERE `merchant_id`="'.$merchant_id.'"');
    }

    /**
     * 检测所修改企业名称是否存在
     * 
     * @params array $data 编辑商户信息
     * 
     * @return bool
     */
    public function nameVerify($name)
    {   
        if(empty($name))
        {
            return FALSE;
        }
        
        $r = $this->where('name = \''.$name.'\'')->find();
        
        return $r;
    }
//------------------------------------------------------- 企业资料修改审核 ------------------------------------------------//
    /**
     * 获取商户列表q
     * @params String
     * @return array/FALSE 当前1行数据
     */
    public function getMerchantActionList($search = array(), $order = '', $offset, $pageSize){
        $r = $this
            ->join('merchant_info_action ON merchant.merchant_id = merchant_info_action.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->field([
                'merchant.merchant_id',
//                'merchant_info_action.merchant_name as name',
                'merchant.name',
                'merchant.memo',
                'merchant_info_action.audit_status',
                'reg_user.account',
                'merchant_info_action.admin_op'
            ])
            ->where($search)
            ->limit($offset, $pageSize)
            ->order($order)
            ->select();
        return $r;
    }

    /**
     * 获取数据总数
     * @params String
     * @return array/FALSE 当前1行数据
     */
    public function getActionCount($search = array()){
        $count = $this
            ->join('merchant_info_action ON merchant.merchant_id = merchant_info_action.merchant_id')
            ->join('reg_user ON merchant.merchant_id = reg_user.merchant_id')
            ->where($search)
            ->count();
        return $count;
    }
}