<?php
namespace Operate\Controller;

/**
 * SunEEE
 *
 * 象翌微链科技发展有限公司内部的PHP框架
 *
 * Copyright (c) 2015 - 2016, SunEEE 技术
 *
 * 这不是开源的框架, 只有通过象翌微链公司授权才能使用.
 * 授权后只能使用,不能修改里面的源代码.
 * 如果有发现非法篡改核心代码逻辑或者非法使用,则正当追究法律责任
 *
 * @package suneee
 * @author  SunEEE PHP Team ->zhuoer
 * @copyright Copyright (c) 2015 - 2016, SunEEE (http://www.suneee.com/)
 * @version Version 1.0.0
 */

class LoginController extends OperateController {
    /**
     * 登录
     * Enter description here ...
     *  {"act":"1","method":"login","op":"login","data":{"user":"admin","password":"123456"},"sign":"456678wewqesa45d64sa56wqe45"}
     * @param unknown_type $field
     * @param unknown_type $outarr
     */
    public function login(){
        //获取用户名和密码
        $d = array();
        $d['account'] = trim($this->param->user);
        $d['passwd'] = md5($this->param->password);

        $r = D('SysUser')->verifyUser($d);
        if($r){
            $time = date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
            D('SysUser')->where($d)->save(['login_ts'=>$time]);
            $r['login_ts'] = $time;
            $r['sessionId'] = $this->getSessionId($d['account'], $r);  //获取用户身份令牌
            unset($r['sys_user_id']);
//            print_r($this->checkSessionId($r['sessionId']));
            $this->returnData['code'] = 200 ;
            $this->returnData['message'] = 'success' ;
            $this->returnData['data']['list'] = $r;
        }
        echo json_encode($this->returnData);
    }
}